import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
    import { supabase } from '@/lib/supabase';
    import { useAuth } from '@/contexts/AuthContext';
    import { toast } from '@/components/ui/use-toast';
    
    const TokenContext = createContext();
    
    export const useTokens = () => {
      const context = useContext(TokenContext);
      if (!context) {
        throw new Error('useTokens debe usarse dentro de TokenProvider');
      }
      return context;
    };
    
    export const TokenProvider = ({ children }) => {
      const { user, profile, refreshProfile: refreshAuthProvider } = useAuth();
      const [tokens, setTokens] = useState(0);
      const [subscription, setSubscription] = useState(null);
      const [creditHistory, setCreditHistory] = useState([]);
      const [loading, setLoading] = useState(true);
    
      const fetchTokenData = useCallback(async () => {
        if (!profile) {
          setTokens(0);
          setSubscription(null);
          setCreditHistory([]);
          setLoading(false);
          return;
        }
    
        setLoading(true);
        try {
          const profileTokens = profile?.tokens || 0;
          setTokens(profileTokens);
    
          const { data: historyData, error: historyError } = await supabase
            .from('history')
            .select('*')
            .eq('user_id', profile.id)
            .order('created_at', { ascending: false })
            .limit(50);
          
          if (historyError) {
            console.warn('Error fetching history:', historyError);
            if (historyError.message?.includes('Failed to fetch')) {
              toast({
                title: "Error de Red",
                description: "No se pudo cargar tu historial. Revisa tu conexión.",
                variant: "destructive",
              });
            }
            setCreditHistory([]);
          } else {
            setCreditHistory(historyData || []);
          }
    
        } catch (error) {
          console.error('Critical error fetching token data:', error);
          if (error.message?.includes('Failed to fetch')) {
            toast({
              title: "Error de conexión",
              description: "No se pudieron cargar los datos de créditos. Verifica tu conexión a internet.",
              variant: "destructive"
            });
          }
          setTokens(0);
          setSubscription(null);
          setCreditHistory([]);
        } finally {
          setLoading(false);
        }
      }, [profile]);
    
      useEffect(() => {
        fetchTokenData();
    
        if (user) {
          const channel = supabase.channel(`realtime:profiles:${user.id}`)
            .on(
              'postgres_changes',
              { event: 'UPDATE', schema: 'public', table: 'profiles', filter: `id=eq.${user.id}` },
              (payload) => {
                console.log('Realtime profile update received!', payload.new);
                setTokens(payload.new.tokens);
                toast({
                  title: "¡Créditos actualizados!",
                  description: `Ahora tienes ${payload.new.tokens} créditos disponibles.`,
                  className: "bg-green-600 border-green-500 text-white"
                });
              }
            )
            .subscribe();
          
          return () => {
            supabase.removeChannel(channel);
          };
        }
      }, [user, fetchTokenData]);
    
      const spendTokens = async (amount, description = 'Uso de servicio', serviceType = 'general') => {
        if (!user) {
          toast({
            title: "Error de autenticación",
            description: "Debes iniciar sesión para usar este servicio.",
            variant: "destructive",
          });
          return false;
        }
    
        const freeServices = ['students', 'answer-key', 'scan-exam', 'results-analysis'];
        if (freeServices.includes(serviceType)) {
          return true;
        }
    
        const creditsToSpend = amount;
    
        try {
          if (tokens < creditsToSpend) {
            toast({
              title: "Créditos insuficientes",
              description: "⚠️ Necesita más créditos para continuar. ¡Adquiéralos aquí!",
              variant: "destructive",
              action: (
                <button 
                  onClick={() => window.location.href = '/#pricing'}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm"
                >
                  Adquirir Créditos
                </button>
              )
            });
            return false;
          }
          
          const { data, error } = await supabase.rpc('check_and_spend_credits', {
            p_user_id: user.id,
            p_service_type: serviceType,
            p_credits_required: creditsToSpend,
            p_input_summary: description
          });
    
          if (error) {
            let errorMessage = "Ocurrió un error al procesar la solicitud.";
            if (error.message?.includes('constraint') || error.message?.includes('history_type_check')) {
              errorMessage = "Error interno del sistema. El equipo técnico ha sido notificado.";
            } else if (error.message?.includes('Failed to fetch') || error.message?.includes('NetworkError')) {
              errorMessage = "Error de conexión. Verifica tu conexión a internet.";
            }
            toast({ title: "Error del sistema", description: errorMessage, variant: "destructive" });
            return false;
          }
    
          if (!data.success) {
            if (data.error === 'insufficient_credits') {
              toast({
                title: "Créditos insuficientes",
                description: data.message,
                variant: "destructive",
                action: (
                  <button 
                    onClick={() => window.location.href = '/#pricing'}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm"
                  >
                    Adquirir Créditos
                  </button>
                )
              });
            } else {
              toast({ title: "Error", description: data.message, variant: "destructive" });
            }
            return false;
          }
    
          fetchTokenData();
          return true;
    
        } catch (error) {
          let errorMessage = "Ocurrió un error al procesar la solicitud.";
          if (error.message?.includes('constraint') || error.message?.includes('history_type_check')) {
            errorMessage = "Error interno del sistema. El equipo técnico ha sido notificado.";
          } else if (error.message?.includes('Failed to fetch') || error.message?.includes('NetworkError')) {
            errorMessage = "Error de conexión. Verifica tu conexión a internet.";
          } else if (error.message){
            errorMessage = error.message;
          }
          toast({ title: "Error del sistema", description: errorMessage, variant: "destructive" });
          return false;
        }
      };
    
      const refreshTokenData = useCallback(async () => {
        setLoading(true);
        await refreshAuthProvider();
        await fetchTokenData();
        setLoading(false);
      }, [refreshAuthProvider, fetchTokenData]);
    
    
      const value = {
        tokens,
        subscription,
        creditHistory,
        loading,
        spendTokens,
        refreshTokenData,
        hasActiveSubscription: !!subscription,
        subscriptionPlan: subscription?.plan_name || 'Gratis'
      };
    
      return (
        <TokenContext.Provider value={value}>
          {children}
        </TokenContext.Provider>
      );
    };