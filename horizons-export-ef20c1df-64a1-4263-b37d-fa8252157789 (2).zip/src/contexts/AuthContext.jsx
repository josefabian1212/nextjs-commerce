import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth debe usarse dentro de AuthProvider');
  }
  return context;
};

const getRedirectUrl = (path = '/dashboard') => {
  const baseUrl = import.meta.env.PROD ? 'https://profe.io' : window.location.origin;
  return `${baseUrl}${path}`;
};

export const AuthProvider = ({ children }) => {
  const [session, setSession] = useState(null);
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = useCallback(async (userToFetch) => {
    if (!userToFetch) {
      setProfile(null);
      return null;
    }
    const { id: userId, user_metadata } = userToFetch;

    try {
      let { data: profileData, error } = await supabase
        .from('profiles')
        .select('*, is_onboarded')
        .eq('id', userId)
        .single();
      
      if (error && error.code === 'PGRST116') {
        console.warn('Profile not found for user, creating one.', userId);
        
        const { data: newProfile, error: insertError } = await supabase
          .from('profiles')
          .insert({
            id: userId,
            full_name: user_metadata?.full_name || 'Usuario',
            tokens: 10,
            is_onboarded: false
          })
          .select('*, is_onboarded')
          .single();

        if (insertError) throw insertError;
        
        console.log('Profile created successfully on-the-fly:', newProfile);
        profileData = newProfile;
      } else if (error) {
        throw error;
      }

      setProfile(profileData);
      return profileData;

    } catch (error) {
      console.error('Error fetching/creating profile:', error.message);
      toast({ title: "Error de Perfil", description: "No se pudo cargar o crear tu perfil.", variant: "destructive" });
      // Don't sign out here, to allow manual retry or contacting support
      setProfile(null);
      return null;
    }
  }, []);
  
  useEffect(() => {
    const { data: authListener } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        setLoading(true);
        setSession(session);
        const currentUser = session?.user ?? null;
        setUser(currentUser);

        if (currentUser) {
          await fetchProfile(currentUser);
        } else {
          setProfile(null);
        }
        setLoading(false);
      }
    );

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, [fetchProfile]);
    
  const login = async (email, password) => {
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      toast({ title: "Error de inicio de sesión", description: error.message, variant: "destructive" });
      setLoading(false);
      return { success: false, error };
    }
    setLoading(false);
    return { success: true };
  };
    
  const register = async (email, password, fullName) => {
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { 
        data: { full_name: fullName },
        emailRedirectTo: getRedirectUrl(),
      }
    });

    if (error) {
      toast({ title: "Error de registro", description: error.message, variant: "destructive" });
      setLoading(false);
      return { success: false, error };
    }

    if (data.user) {
      toast({
        title: "¡Bienvenido a Profe AI!",
        description: "Revisa tu correo para verificar tu cuenta.",
      });
    }
    
    setLoading(false);
    return { success: true, data };
  };
    
  const logout = async () => {
    setLoading(true);
    await supabase.auth.signOut();
    // onAuthStateChange will handle setting user/profile to null
    toast({ title: "Sesión cerrada", description: "Has cerrado sesión exitosamente" });
    setLoading(false);
    // Explicitly redirect to ensure clean state
    window.location.href = '/'; 
  };
  
  const signInWithGoogle = async () => {
    setLoading(true);
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: getRedirectUrl(),
      },
    });
    if (error) {
      toast({
        title: 'Error al iniciar sesión con Google',
        description: error.message,
        variant: 'destructive',
      });
      setLoading(false);
    }
  };
  
  const refreshProfile = useCallback(async () => {
    if (user) {
      setLoading(true);
      await fetchProfile(user);
      setLoading(false);
    }
  }, [user, fetchProfile]);

  const value = {
    session,
    user,
    profile,
    setProfile,
    loading,
    login,
    register,
    logout,
    signInWithGoogle,
    refreshProfile,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};