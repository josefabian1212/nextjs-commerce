import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { Toaster } from '@/components/ui/toaster';
import { AuthProvider } from '@/contexts/AuthContext';
import { TokenProvider } from '@/contexts/TokenContext';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ProtectedRoute from '@/components/ProtectedRoute';
import SocialProofPopup from '@/components/SocialProofPopup';
import Home from '@/pages/Home';
import Welcome from '@/pages/Welcome';

const Services = lazy(() => import('@/pages/Services'));
const AIOCRExams = lazy(() => import('@/pages/AIOCRExams'));
const Dashboard = lazy(() => import('@/pages/Dashboard'));
const Blog = lazy(() => import('@/pages/Blog'));
const Admin = lazy(() => import('@/pages/Admin'));
const Login = lazy(() => import('@/pages/Login'));
const Register = lazy(() => import('@/pages/Register'));
const PaymentPage = lazy(() => import('@/pages/PaymentPage'));
const PrivacyPolicy = lazy(() => import('@/pages/PrivacyPolicy'));
const TermsOfService = lazy(() => import('@/pages/TermsOfService'));
const AboutUs = lazy(() => import('@/pages/AboutUs'));
const Faq = lazy(() => import('@/pages/Faq'));
const UserProfile = lazy(() => import('@/pages/UserProfile'));
const BuyCredits = lazy(() => import('@/pages/BuyCredits'));
const PaymentStatus = lazy(() => import('@/pages/PaymentStatus'));
const AwaitingVerification = lazy(() => import('@/pages/AwaitingVerification'));
const Ofertas = lazy(() => import('@/pages/Ofertas'));

const LoadingSpinner = () => (
  <div className="flex h-screen w-full items-center justify-center bg-slate-900">
    <div className="h-16 w-16 animate-spin rounded-full border-4 border-solid border-sky-500 border-t-transparent"></div>
  </div>
);

function App() {
  return (
    <HelmetProvider>
      <AuthProvider>
        <TokenProvider>
          <Router>
            <div className="flex flex-col min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-gray-200">
              <Navbar />
              <main className="flex-grow">
                <Suspense fallback={<LoadingSpinner />}>
                  <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/inicio" element={<Home />} />
                    <Route path="/registro" element={<Register />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/privacy-policy" element={<PrivacyPolicy />} />
                    <Route path="/terms-of-service" element={<TermsOfService />} />
                    <Route path="/sobre-nosotros" element={<AboutUs />} />
                    <Route path="/faq" element={<Faq />} />
                    <Route path="/callback" element={<Home />} />
                    <Route path="/blog" element={<Blog />} />
                    <Route path="/awaiting-verification" element={<AwaitingVerification />} />
                    <Route path="/ofertas" element={<Ofertas />} />

                    <Route path="/welcome" element={<ProtectedRoute><Welcome /></ProtectedRoute>} />

                    <Route path="/servicios/:serviceSlug" element={<ProtectedRoute><Services /></ProtectedRoute>} />
                    <Route path="/servicios" element={<ProtectedRoute><Services /></ProtectedRoute>} />
                    <Route path="/services" element={<ProtectedRoute><Services /></ProtectedRoute>} />
                    
                    <Route path="/examenes-ai-ocr" element={<ProtectedRoute><AIOCRExams /></ProtectedRoute>} />
                    <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
                    <Route path="/usuario/:username" element={<ProtectedRoute><UserProfile /></ProtectedRoute>} />
                    <Route path="/admin" element={<ProtectedRoute adminOnly={true}><Admin /></ProtectedRoute>} />
                    <Route path="/admin-panel" element={<ProtectedRoute adminOnly={true}><Admin /></ProtectedRoute>} />
                    <Route path="/checkout" element={<ProtectedRoute><PaymentPage /></ProtectedRoute>} />
                    <Route path="/comprar-creditos" element={<ProtectedRoute><BuyCredits /></ProtectedRoute>} />
                    <Route path="/pago-exitoso" element={<ProtectedRoute><PaymentStatus status="success" /></ProtectedRoute>} />
                    <Route path="/pago-fallido" element={<ProtectedRoute><PaymentStatus status="failure" /></ProtectedRoute>} />
                    <Route path="/pago-pendiente" element={<ProtectedRoute><PaymentStatus status="pending" /></ProtectedRoute>} />
                  </Routes>
                </Suspense>
              </main>
              <Footer />
              <SocialProofPopup />
              <Toaster />
            </div>
          </Router>
        </TokenProvider>
      </AuthProvider>
    </HelmetProvider>
  );
}

export default App;