import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { Settings } from 'lucide-react';

const SettingsTab = () => {
  const handleSave = () => {
    toast({ title: "🚧 No implementado", description: "Esta función no está implementada todavía." });
  };
  
  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle className="text-white flex items-center"><Settings className="w-5 h-5 mr-2" />Configuración del Sistema</CardTitle>
        <CardDescription className="text-gray-300">Ajusta la configuración general de la plataforma</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-white font-medium">Precios de Tokens</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg"><span className="text-gray-300">Plan Básico (3,000 tokens)</span><span className="text-white">$10</span></div>
              <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg"><span className="text-gray-300">Plan Premium (12,000 tokens)</span><span className="text-white">$30</span></div>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-white font-medium">Costos por Servicio</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg"><span className="text-gray-300">Generador de Clases</span><span className="text-white">100 tokens</span></div>
              <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg"><span className="text-gray-300">Exámenes OCR</span><span className="text-white">150 tokens</span></div>
              <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg"><span className="text-gray-300">Generador de Imágenes</span><span className="text-white">50 tokens</span></div>
            </div>
          </div>
        </div>
        <div className="pt-6 border-t border-white/10">
          <Button className="glow-effect" onClick={handleSave}>Guardar Configuración</Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default SettingsTab;