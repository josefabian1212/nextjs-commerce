import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, DollarSign, Brain, Coins, TrendingUp, Activity } from 'lucide-react';

const OverviewTab = () => {
  const stats = [
    { title: 'Usuarios Totales', value: '1,234', change: '+12%', icon: Users, color: 'from-blue-500 to-cyan-500' },
    { title: 'Ingresos Mensuales', value: '$45,678', change: '+8%', icon: DollarSign, color: 'from-green-500 to-teal-500' },
    { title: 'Clases Generadas', value: '8,901', change: '+23%', icon: Brain, color: 'from-purple-500 to-blue-500' },
    { title: 'Tokens Consumidos', value: '2.3M', change: '+15%', icon: Coins, color: 'from-yellow-500 to-orange-500' }
  ];

  const recentUsers = [
    { name: 'María García', email: 'maria@email.com', tokens: 2500, status: 'Activo' },
    { name: 'Carlos López', email: 'carlos@email.com', tokens: 1200, status: 'Activo' },
    { name: 'Ana Martínez', email: 'ana@email.com', tokens: 800, status: 'Inactivo' },
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className="glass-effect card-hover">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm font-medium">{stat.title}</p>
                    <p className="text-2xl font-bold text-white">{stat.value}</p>
                    <p className="text-green-400 text-sm">{stat.change} vs mes anterior</p>
                  </div>
                  <div className={`w-12 h-12 bg-gradient-to-r ${stat.color} rounded-lg flex items-center justify-center`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="glass-effect">
          <CardHeader><CardTitle className="text-white flex items-center"><TrendingUp className="w-5 h-5 mr-2" />Actividad Reciente</CardTitle></CardHeader>
          <CardContent>
             <div className="space-y-4">
              <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg"><Activity className="w-5 h-5 text-green-400" /><div><p className="text-white text-sm">Nuevo usuario registrado</p><p className="text-gray-400 text-xs">Hace 5 minutos</p></div></div>
              <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg"><Brain className="w-5 h-5 text-purple-400" /><div><p className="text-white text-sm">Clase generada con IA</p><p className="text-gray-400 text-xs">Hace 12 minutos</p></div></div>
              <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg"><DollarSign className="w-5 h-5 text-yellow-400" /><div><p className="text-white text-sm">Compra de tokens</p><p className="text-gray-400 text-xs">Hace 1 hora</p></div></div>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-effect">
          <CardHeader><CardTitle className="text-white">Usuarios Recientes</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentUsers.map((user, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                  <div>
                    <p className="text-white text-sm font-medium">{user.name}</p>
                    <p className="text-gray-400 text-xs">{user.email}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-white text-sm">{user.tokens} tokens</p>
                    <span className={`text-xs px-2 py-1 rounded-full ${user.status === 'Activo' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{user.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default OverviewTab;