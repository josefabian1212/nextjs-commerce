import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { UserPlus, Users } from 'lucide-react';

const UsersTab = () => {
  const [newUserData, setNewUserData] = useState({ name: '', email: '', role: 'user', tokens: '' });
  
  const recentUsers = [
    { id: 1, name: 'María García', email: 'maria@email.com', tokens: 2500 },
    { id: 2, name: 'Carlos López', email: 'carlos@email.com', tokens: 1200 },
    { id: 3, name: 'Ana Martínez', email: 'ana@email.com', tokens: 800 },
  ];

  const handleInputChange = (e) => {
    setNewUserData({ ...newUserData, [e.target.name]: e.target.value });
  };

  const handleCreateUser = (e) => {
    e.preventDefault();
    toast({ title: "Usuario creado", description: `Usuario ${newUserData.name} creado.` });
    setNewUserData({ name: '', email: '', role: 'user', tokens: '' });
  };

  const handleActionClick = () => {
    toast({ title: "🚧 No implementado", description: "Esta función no está implementada todavía." });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <Card className="glass-effect">
        <CardHeader>
          <CardTitle className="text-white flex items-center"><UserPlus className="w-5 h-5 mr-2" />Crear Nuevo Usuario</CardTitle>
          <CardDescription className="text-gray-300">Agrega un nuevo usuario a la plataforma</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreateUser} className="space-y-4">
            <div className="space-y-2"><Label htmlFor="name" className="text-white">Nombre completo</Label><Input id="name" name="name" value={newUserData.name} onChange={handleInputChange} className="glass-effect border-white/20" required /></div>
            <div className="space-y-2"><Label htmlFor="email" className="text-white">Email</Label><Input id="email" name="email" type="email" value={newUserData.email} onChange={handleInputChange} className="glass-effect border-white/20" required /></div>
            <div className="space-y-2"><Label htmlFor="role" className="text-white">Rol</Label><Select name="role" value={newUserData.role} onChange={handleInputChange} className="glass-effect border-white/20"><option value="user">Usuario</option><option value="admin">Admin</option></Select></div>
            <div className="space-y-2"><Label htmlFor="tokens" className="text-white">Tokens iniciales</Label><Input id="tokens" name="tokens" type="number" value={newUserData.tokens} onChange={handleInputChange} className="glass-effect border-white/20" placeholder="1000" /></div>
            <Button type="submit" className="w-full glow-effect"><UserPlus className="w-4 h-4 mr-2" />Crear Usuario</Button>
          </form>
        </CardContent>
      </Card>

      <Card className="glass-effect">
        <CardHeader>
          <CardTitle className="text-white flex items-center"><Users className="w-5 h-5 mr-2" />Gestión de Usuarios</CardTitle>
          <CardDescription className="text-gray-300">Administra usuarios existentes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentUsers.map((user) => (
              <div key={user.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                <div>
                  <p className="text-white font-medium">{user.name}</p>
                  <p className="text-gray-400 text-sm">{user.email}</p>
                  <p className="text-gray-400 text-xs">{user.tokens} tokens</p>
                </div>
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline" onClick={handleActionClick}>Editar</Button>
                  <Button size="sm" variant="destructive" onClick={handleActionClick}>Eliminar</Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UsersTab;