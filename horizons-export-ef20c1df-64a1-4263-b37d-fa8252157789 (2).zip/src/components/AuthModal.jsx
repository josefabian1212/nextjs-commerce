import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';
import { X, Brain, Mail, Lock, User, ArrowRight, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import GoogleIcon from '@/components/GoogleIcon';

const servicesPromise = import('@/pages/Services');

const AuthModal = ({ isOpen, onClose }) => {
  const [isLoginView, setIsLoginView] = useState(true);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [loading, setLoading] = useState(false);
  const { login, register, signInWithGoogle } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    if (isLoginView) {
      const result = await login(formData.email, formData.password);
      if (result.success) {
        onClose();
        navigate('/servicios', { replace: true });
      }
    } else {
      if (formData.password !== formData.confirmPassword) {
        toast({ title: "Error", description: "Las contraseñas no coinciden", variant: "destructive" });
        setLoading(false);
        return;
      }
      const result = await register(formData.email, formData.password, formData.fullName);
      if (result.success) {
        onClose();
        navigate('/servicios', { replace: true });
      }
    }
    setLoading(false);
  };

  const handleGoogleSignIn = async () => {
    setLoading(true);
    await signInWithGoogle();
    onClose();
  };

  const handleMouseEnter = () => {
    servicesPromise.catch(err => console.error("Failed to prefetch Services component", err));
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="glass-effect w-full max-w-md rounded-xl shadow-2xl border border-blue-500/30 overflow-hidden bg-slate-900/80"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 md:p-8 relative">
              <Button variant="ghost" size="icon" className="absolute top-4 right-4 text-gray-400 hover:text-white" onClick={onClose}>
                <X className="h-5 w-5" />
              </Button>
              
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-600 via-sky-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <Brain className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-white">{isLoginView ? 'Iniciar Sesión' : 'Crear Cuenta'}</h2>
                <p className="text-gray-300 mt-1">{isLoginView ? 'Accede a Profe AI.' : 'Únete a la revolución educativa.'}</p>
                {!isLoginView && (
                    <div className="flex items-center justify-center gap-2 mt-3 bg-blue-600/20 px-3 py-2 rounded-full text-xs">
                        <Zap className="w-4 h-4 text-blue-400" />
                        <span className="text-blue-300 font-medium">¡Acceso inmediato y 10 créditos gratis!</span>
                    </div>
                )}
              </div>

              <Button variant="outline" className="w-full bg-white text-slate-700 hover:bg-slate-100 text-base py-6 mb-4" onClick={handleGoogleSignIn} disabled={loading}>
                <GoogleIcon className="mr-3 h-6 w-6" />
                {isLoginView ? 'Continuar con Google' : 'Registrarse con Google'}
              </Button>

              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-slate-600" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-slate-900/80 px-2 text-slate-400 backdrop-blur-sm">O</span>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4" onMouseEnter={handleMouseEnter}>
                {!isLoginView && (
                    <div className="space-y-1.5">
                      <Label htmlFor="fullNameModal" className="text-white">Nombre completo</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                        <Input id="fullNameModal" name="fullName" type="text" placeholder="Tu nombre completo" value={formData.fullName} onChange={handleChange} required className="pl-10 glass-input" disabled={loading} />
                      </div>
                    </div>
                )}
                <div className="space-y-1.5">
                  <Label htmlFor="emailModal" className="text-white">Correo electrónico</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input id="emailModal" name="email" type="email" placeholder="tu@email.com" value={formData.email} onChange={handleChange} required className="pl-10 glass-input" disabled={loading} />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="passwordModal" className="text-white">Contraseña</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input id="passwordModal" name="password" type="password" placeholder="••••••••" value={formData.password} onChange={handleChange} required className="pl-10 glass-input" disabled={loading} />
                  </div>
                </div>
                {!isLoginView && (
                  <div className="space-y-1.5">
                    <Label htmlFor="confirmPasswordModal" className="text-white">Confirmar contraseña</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input id="confirmPasswordModal" name="confirmPassword" type="password" placeholder="••••••••" value={formData.confirmPassword} onChange={handleChange} required className="pl-10 glass-input" disabled={loading} />
                    </div>
                  </div>
                )}
                <Button type="submit" className="w-full glow-effect bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-base py-2.5" disabled={loading}>
                  {loading ? <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div> : <ArrowRight className="w-5 h-5 mr-2" />}
                  {loading ? (isLoginView ? 'Iniciando...' : 'Registrando...') : (isLoginView ? 'Iniciar Sesión con Email' : 'Crear Cuenta con Email')}
                </Button>
              </form>

              <p className="text-center text-sm text-gray-400 mt-6">
                {isLoginView ? '¿No tienes cuenta?' : '¿Ya tienes una cuenta?'}
                <Button variant="link" className="text-sky-400 hover:text-sky-300 pl-1" onClick={() => setIsLoginView(!isLoginView)}>
                  {isLoginView ? 'Regístrate aquí' : 'Inicia sesión aquí'}
                </Button>
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AuthModal;