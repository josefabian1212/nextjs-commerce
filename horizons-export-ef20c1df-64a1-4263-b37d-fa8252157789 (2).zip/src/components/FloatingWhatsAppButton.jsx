import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle } from 'lucide-react';

const FloatingWhatsAppButton = () => {
  const whatsappUrl = `https://wa.me/573114123000`;

  const handleWhatsAppClick = () => {
    if (typeof window !== 'undefined') {
      window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
      
      if (window.gtag) {
        window.gtag('event', 'whatsapp_click', {
          event_category: 'engagement',
          event_label: 'floating_button'
        });
      }
      
      if (window.fbq) {
        window.fbq('track', 'Contact', {
          content_name: 'WhatsApp Contact',
          content_category: 'Support'
        });
      }
    }
  };

  return (
    <motion.button
      onClick={handleWhatsAppClick}
      className="fixed bottom-6 right-6 z-[90] w-16 h-16 bg-gradient-to-br from-green-500 via-green-600 to-green-700 rounded-full flex items-center justify-center shadow-2xl cursor-pointer hover:shadow-green-500/30 transition-all duration-300"
      whileHover={{ 
        scale: 1.1, 
        boxShadow: "0px 0px 25px rgba(34, 197, 94, 0.7)",
        rotate: [0, -10, 10, -10, 0]
      }}
      whileTap={{ scale: 0.95 }}
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 1 }}
      aria-label="Contactar por WhatsApp"
    >
      <MessageCircle className="w-8 h-8 text-white" />
      
      <motion.div
        className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full"
        animate={{ scale: [1, 1.2, 1] }}
        transition={{ duration: 2, repeat: Infinity }}
      />
    </motion.button>
  );
};

export default FloatingWhatsAppButton;