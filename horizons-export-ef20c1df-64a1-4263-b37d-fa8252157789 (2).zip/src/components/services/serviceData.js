import { Brain, FileText, Calculator, BookOpen, Zap, Palette, Mic, GraduationCap, FlaskConical, Newspaper, Option, SearchCheck, Activity, Podcast as PodcastIcon, MessageSquare as MessageSquareText, Smile, Accessibility, Users, Rocket, ClipboardCheck, Gamepad2, ClipboardList, Presentation, Map } from 'lucide-react';

const highlightedServices = [
  'class-preparer', 'unit-topics', 'generate-article', 'pedagogical-workshops',
  'atencion-diversidad', 'cooperative-learning', 'children-creativity',
  'presentation-generator', 'tutorial-generator', 'concept-maps', 'poems-songs',
  'educational-projects', 'podcast-generator', 'create-startup', 'gamificacion',
  'inteligencia-artificial', 'evaluacion-formativa', 'neuroeducation',
  'critical-thinking', 'multiple-intelligences', 'text-analysis',
  'cognitive-analysis', 'math-analysis', 'pqrs-generator'
];

const addHighlightFlag = (services) => services.map(service => ({
  ...service,
  isHighlighted: highlightedServices.includes(service.id)
}));

export const serviceData = {
  'Creación de Contenido': addHighlightFlag([
    { id: 'class-preparer', title: 'Preparador de Clases', icon: GraduationCap, color: 'from-blue-500 to-cyan-400', credits: 1 },
    { id: 'unit-topics', title: 'Temas por Unidad', icon: BookOpen, color: 'from-indigo-500 to-purple-500', credits: 1 },
    { id: 'generate-article', title: 'Generar Artículos', icon: Newspaper, color: 'from-sky-500 to-blue-500', credits: 1 },
    { id: 'pedagogical-workshops', title: 'Talleres Pedagógicos', icon: FlaskConical, color: 'from-orange-500 to-amber-500', credits: 1 },
    { id: 'atencion-diversidad', title: 'Atención a la Diversidad', icon: Accessibility, color: 'from-cyan-500 to-green-500', credits: 1 },
    { id: 'cooperative-learning', title: 'Aprendizaje Cooperativo', icon: Users, color: 'from-emerald-500 to-teal-500', credits: 1 },
    { id: 'children-creativity', title: 'Creatividad Infantil', icon: Smile, color: 'from-yellow-400 to-orange-500', credits: 1 },
    { id: 'presentation-generator', title: 'Presentaciones con IA', icon: Presentation, color: 'from-orange-500 to-red-500', credits: 1 },
    { id: 'tutorial-generator', title: 'Tutoriales Educativos', icon: Mic, color: 'from-yellow-500 to-amber-500', credits: 1 },
    { id: 'concept-maps', title: 'Mapas Conceptuales', icon: Map, color: 'from-pink-500 to-purple-500', credits: 1 },
    { id: 'poems-songs', title: 'Poemas y Canciones', icon: Palette, color: 'from-rose-400 to-red-500', credits: 1 },
    { id: 'educational-projects', title: 'Proyectos Educativos', icon: FlaskConical, color: 'from-lime-500 to-green-500', credits: 1 },
    { id: 'podcast-generator', title: 'Pódcasts con IA', icon: PodcastIcon, color: 'from-pink-500 to-rose-500', credits: 1 },
  ]),
  'Emprendimiento y Negocios': addHighlightFlag([
    { id: 'create-startup', title: 'Crea Startups', icon: Rocket, color: 'from-green-400 to-blue-500', credits: 1 }
  ]),
  'Análisis y Herramientas': addHighlightFlag([
    { id: 'gamificacion', title: 'Gamificación', icon: Gamepad2, color: 'from-purple-500 to-pink-500', credits: 1 },
    { id: 'inteligencia-artificial', title: 'Inteligencia Artificial', icon: Brain, color: 'from-indigo-500 to-purple-600', credits: 1 },
    { id: 'evaluacion-formativa', title: 'Evaluación Formativa', icon: ClipboardCheck, color: 'from-sky-500 to-indigo-500', credits: 1 },
    { id: 'neuroeducation', title: 'Neuroeducación', icon: Brain, color: 'from-pink-400 to-orange-500', credits: 1 },
    { id: 'critical-thinking', title: 'Pensamiento Crítico', icon: Brain, color: 'from-red-500 to-yellow-500', credits: 1 },
    { id: 'multiple-intelligences', title: 'Inteligencias Múltiples', icon: Zap, color: 'from-teal-400 to-blue-500', credits: 1 },
    { id: 'text-analysis', title: 'Análisis Textual', icon: SearchCheck, color: 'from-sky-500 to-indigo-500', credits: 1 },
    { id: 'cognitive-analysis', title: 'Análisis Cognitivo', icon: Activity, color: 'from-red-500 to-orange-500', credits: 1 },
    { id: 'math-analysis', title: 'Análisis Matemático', icon: Calculator, color: 'from-blue-500 to-cyan-500', credits: 1 },
  ]),
  'Comunicación y Gestión': addHighlightFlag([
    { id: 'pqrs-generator', title: 'Gestión de PQRS', icon: MessageSquareText, color: 'from-cyan-500 to-sky-500', credits: 1 },
  ]),
};

export const slugToIdMap = {
  'preparador-de-clases': 'class-preparer',
  'temas-por-unidad': 'unit-topics',
  'generar-articulos': 'generate-article',
  'talleres-pedagogicos': 'pedagogical-workshops',
  'atencion-a-la-diversidad': 'atencion-diversidad',
  'aprendizaje-cooperativo': 'cooperative-learning',
  'creatividad-infantil': 'children-creativity',
  'presentaciones-ia': 'presentation-generator',
  'tutoriales-educativos': 'tutorial-generator',
  'mapas-conceptuales': 'concept-maps',
  'poemas-canciones': 'poems-songs',
  'proyectos-educativos': 'educational-projects',
  'podcasts-ia': 'podcast-generator',
  'crear-startups': 'create-startup',
  'gamificacion': 'gamificacion',
  'inteligencia-artificial': 'inteligencia-artificial',
  'evaluacion-formativa': 'evaluacion-formativa',
  'neuroeducacion': 'neuroeducation',
  'pensamiento-critico': 'critical-thinking',
  'inteligencias-multiples': 'multiple-intelligences',
  'analisis-textual': 'text-analysis',
  'analisis-cognitivo': 'cognitive-analysis',
  'analisis-matematico': 'math-analysis',
  'gestion-pqrs': 'pqrs-generator',
};