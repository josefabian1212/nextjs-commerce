import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { BookOpen } from 'lucide-react';
import { motion } from 'framer-motion';

const UnitTopicsGeneratorForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const handleInputChange = (e) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'number' ? parseInt(value, 10) || 0 : value }));
  };

  const isSubmitDisabled = loading || !formData.grade || !formData.asignatura || !formData.topic || !formData.numero_clases || formData.numero_clases <= 0 || !formData.estandar;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="glass-effect border-indigo-500/20 shadow-2xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
              <activeService.icon className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-white text-2xl">{activeService.title}</CardTitle>
              <CardDescription className="text-gray-300">Genera un plan de trabajo detallado por clases.</CardDescription>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="grade" className="text-white font-medium">Grado</Label>
                <Input id="grade" name="grade" placeholder="Ej: 10° Secundaria" value={formData.grade || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="asignatura" className="text-white font-medium">Asignatura</Label>
                <Input id="asignatura" name="asignatura" placeholder="Ej: Matemáticas" value={formData.asignatura || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white" required />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="topic" className="text-white font-medium">Tema Principal de la Unidad</Label>
              <Input id="topic" name="topic" placeholder="Ej: Ecuaciones Lineales" value={formData.topic || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="numero_clases" className="text-white font-medium">Número de Clases</Label>
              <Input id="numero_clases" name="numero_clases" type="number" min="1" placeholder="Ej: 5" value={formData.numero_clases || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="estandar" className="text-white font-medium">Estándar Educativo</Label>
              <Textarea id="estandar" name="estandar" placeholder="Describe el estándar o competencia a desarrollar..." value={formData.estandar || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white min-h-[100px]" required />
            </div>
            
            <Button type="submit" className="w-full glow-effect bg-gradient-to-r from-indigo-500 to-purple-600 text-base py-3" disabled={isSubmitDisabled}>
              {loading ? (<> <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div> Generando Plan...</>) : (<> <BookOpen className="w-5 h-5 mr-2" />Generar Temas por Unidad</>)}
            </Button>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default UnitTopicsGeneratorForm;