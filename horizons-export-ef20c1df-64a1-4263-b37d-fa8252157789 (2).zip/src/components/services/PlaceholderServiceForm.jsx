import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

const PlaceholderServiceForm = ({ activeService }) => {
  if (!activeService) return null;

  return (
    <Card className="glass-effect border-gray-500/20 shadow-2xl">
      <CardHeader>
        <div className="flex items-center space-x-4">
          <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color || 'from-gray-500 to-gray-600'} rounded-lg flex items-center justify-center shadow-lg`}>
            <activeService.icon className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-white text-2xl">{activeService.title}</CardTitle>
            <CardDescription className="text-gray-300">Este servicio está en desarrollo.</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center justify-center text-center h-full p-8">
          <activeService.icon className="w-16 h-16 mb-4 text-purple-400" />
          <p className="text-gray-300">Este generador está en construcción y estará disponible muy pronto. ¡Gracias por tu paciencia! 🚀</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default PlaceholderServiceForm;