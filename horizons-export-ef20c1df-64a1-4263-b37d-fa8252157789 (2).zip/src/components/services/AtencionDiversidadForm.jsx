import React from 'react';
    import { motion } from 'framer-motion';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Zap } from 'lucide-react';
    import { atencionDiversidadSupportTypes } from '@/components/services/serviceUtils';
    
    const AtencionDiversidadForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
      const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
      };
      
      const handleSelectChange = (value) => {
        setFormData(prev => ({ ...prev, tipo_necesidad: value }));
      };
    
      const formFields = [
        { name: 'tema', label: 'Tema', placeholder: 'Ej: El ciclo del agua' },
        { name: 'grado', label: 'Grado', placeholder: 'Ej: 4º de Primaria' },
        { name: 'asignatura', label: 'Asignatura', placeholder: 'Ej: Ciencias Naturales' },
        { name: 'pais', label: 'País', placeholder: 'Ej: Colombia' },
        { name: 'duracion', label: 'Duración', placeholder: 'Ej: 45 minutos' },
        { name: 'unidad', label: 'Unidad', placeholder: 'Ej: Unidad 2: Ecosistemas' },
      ];
    
      return (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <Card className="glass-effect border-cyan-500/20 shadow-xl" role="form" aria-labelledby="form-title">
            <CardHeader>
              <div className="flex items-center space-x-4">
                <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
                  <activeService.icon className="w-6 h-6 text-white" aria-hidden="true" />
                </div>
                <div>
                  <CardTitle id="form-title" className="gradient-text text-2xl">{activeService.title}</CardTitle>
                  <CardDescription className="text-gray-400">Genera planes de clase inclusivos para necesidades diversas.</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <form onSubmit={onSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {formFields.map(field => (
                    <div key={field.name} className="space-y-2">
                      <Label htmlFor={field.name} className="text-purple-300">{field.label}</Label>
                      <Input
                        id={field.name}
                        name={field.name}
                        value={formData[field.name] || ''}
                        onChange={handleChange}
                        placeholder={field.placeholder}
                        className="glass-effect"
                        required
                        aria-required="true"
                      />
                    </div>
                  ))}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="objetivo" className="text-purple-300">Objetivo / Estándar de Aprendizaje</Label>
                  <Textarea
                    id="objetivo"
                    name="objetivo"
                    value={formData.objetivo || ''}
                    onChange={handleChange}
                    placeholder="Ej: Los estudiantes podrán describir las etapas del ciclo del agua y su importancia para la vida en la Tierra."
                    className="glass-effect"
                    rows={4}
                    required
                    aria-required="true"
                  />
                </div>
    
                <div className="space-y-2">
                  <Label htmlFor="tipo_necesidad" className="text-purple-300">Tipo de Necesidad</Label>
                  <Select onValueChange={handleSelectChange} value={formData.tipo_necesidad || ''} name="tipo_necesidad" required>
                    <SelectTrigger className="glass-effect w-full" aria-label="Seleccionar tipo de necesidad">
                      <SelectValue placeholder="Selecciona una necesidad..." />
                    </SelectTrigger>
                    <SelectContent>
                      {atencionDiversidadSupportTypes.map((type) => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
    
                <div className="flex justify-end pt-4">
                  <Button type="submit" disabled={loading} className="bg-gradient-to-r from-cyan-500 to-green-600 hover:from-cyan-600 hover:to-green-700 text-white font-bold py-3 px-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">
                    {loading ? 'Generando Plan...' : 'Generar Plan de Atención a la Diversidad'}
                    <Zap className="ml-2 h-5 w-5" aria-hidden="true" />
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      );
    };
    
    export default AtencionDiversidadForm;