import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Rocket } from 'lucide-react';
import { startupPassions, startupViabilityTools, startupMarketResearchTypes, startupCustomerProfiles, startupTemplates, startupMarketingStrategies } from '@/components/services/formData/businessForms';

const CreateStartupForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const isSubmitDisabled = loading || !formData.pasiones_intereses || !formData.problema_mercado || !formData.viabilidad_ia || !formData.tipo_estudio_mercado || !formData.competidores_directos || !formData.cliente_ideal || !formData.plantilla || !formData.estrategia_marketing || !formData.financiamiento;


  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card className="glass-effect border-green-500/20 shadow-xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
              <Rocket className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-white text-2xl">{activeService.title}</CardTitle>
              <CardDescription className="text-gray-300">Genera un plan de negocio para tu próxima gran idea.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-8">
            <div>
              <h3 className="text-lg font-semibold text-purple-300 mb-4 border-b border-purple-500/20 pb-2">IDENTIFICACIÓN DE IDEA</h3>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-purple-300">Mis pasiones/intereses principales</Label>
                  <Select onValueChange={(value) => handleSelectChange('pasiones_intereses', value)} value={formData.pasiones_intereses || ''} required>
                    <SelectTrigger className="glass-effect w-full bg-slate-800 border-white/20 text-white"><SelectValue placeholder="Selecciona una pasión..." /></SelectTrigger>
                    <SelectContent className="glass-effect border-purple-500/30 text-white bg-slate-800">{startupPassions.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="problema_mercado" className="text-purple-300">Problema del mercado a resolver</Label>
                  <Textarea id="problema_mercado" name="problema_mercado" value={formData.problema_mercado || ''} onChange={handleChange} placeholder="Describe un problema que te apasione solucionar..." className="glass-effect bg-slate-800 border-white/20 text-white" required />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-purple-300">Viabilidad (Herramientas IA de ayuda)</Label>
                    <Select onValueChange={(value) => handleSelectChange('viabilidad_ia', value)} value={formData.viabilidad_ia || ''} required>
                        <SelectTrigger className="glass-effect w-full bg-slate-800 border-white/20 text-white"><SelectValue placeholder="Elige una herramienta..." /></SelectTrigger>
                        <SelectContent className="glass-effect border-purple-500/30 text-white bg-slate-800">{startupViabilityTools.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-purple-300">Tipo de estudio de mercado</Label>
                    <Select onValueChange={(value) => handleSelectChange('tipo_estudio_mercado', value)} value={formData.tipo_estudio_mercado || ''} required>
                        <SelectTrigger className="glass-effect w-full bg-slate-800 border-white/20 text-white"><SelectValue placeholder="Elige un tipo de estudio..." /></SelectTrigger>
                        <SelectContent className="glass-effect border-purple-500/30 text-white bg-slate-800">{startupMarketResearchTypes.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="competidores_directos" className="text-purple-300">Competidores directos</Label>
                  <Textarea id="competidores_directos" name="competidores_directos" value={formData.competidores_directos || ''} onChange={handleChange} placeholder="Menciona 2 o 3 competidores principales y qué hacen." className="glass-effect bg-slate-800 border-white/20 text-white" required />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label className="text-purple-300">Cliente ideal</Label>
                         <Select onValueChange={(value) => handleSelectChange('cliente_ideal', value)} value={formData.cliente_ideal || ''} required>
                            <SelectTrigger className="glass-effect w-full bg-slate-800 border-white/20 text-white"><SelectValue placeholder="Selecciona tu cliente..." /></SelectTrigger>
                            <SelectContent className="glass-effect border-purple-500/30 text-white bg-slate-800">{startupCustomerProfiles.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label className="text-purple-300">Plantilla de plan de negocio</Label>
                         <Select onValueChange={(value) => handleSelectChange('plantilla', value)} value={formData.plantilla || ''} required>
                            <SelectTrigger className="glass-effect w-full bg-slate-800 border-white/20 text-white"><SelectValue placeholder="Elige una plantilla..." /></SelectTrigger>
                            <SelectContent className="glass-effect border-purple-500/30 text-white bg-slate-800">{startupTemplates.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                </div>
                <div className="space-y-2">
                    <Label className="text-purple-300">Estrategia de marketing inicial</Label>
                     <Select onValueChange={(value) => handleSelectChange('estrategia_marketing', value)} value={formData.estrategia_marketing || ''} required>
                        <SelectTrigger className="glass-effect w-full bg-slate-800 border-white/20 text-white"><SelectValue placeholder="Elige una estrategia..." /></SelectTrigger>
                        <SelectContent className="glass-effect border-purple-500/30 text-white bg-slate-800">{startupMarketingStrategies.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                    </Select>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-purple-300 mb-4 border-b border-purple-500/20 pb-2">FINANCIAMIENTO</h3>
              <div className="space-y-2">
                <Label htmlFor="financiamiento" className="text-purple-300">Necesidades de Financiamiento</Label>
                <Input id="financiamiento" name="financiamiento" value={formData.financiamiento || ''} onChange={handleChange} placeholder="Ej: $10,000 USD para desarrollo y marketing inicial" className="glass-effect bg-slate-800 border-white/20 text-white" required />
              </div>
            </div>
            
            <div className="flex justify-end">
              <Button type="submit" disabled={isSubmitDisabled} className="glow-effect bg-gradient-to-r from-green-400 to-blue-500 hover:from-green-500 hover:to-blue-600 text-white font-bold py-3 px-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300 disabled:opacity-50 disabled:cursor-not-allowed">
                {loading ? 'Generando Plan...' : 'Crear Plan de Startup'}
                <Rocket className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default CreateStartupForm;