import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { FlaskConical, PlusCircle, Trash2, Info } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const EducationalProjectForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleNestedChange = (index, field, value, section) => {
    const updatedSection = [...(formData[section] || [])];
    updatedSection[index] = { ...updatedSection[index], [field]: value };
    setFormData(prev => ({ ...prev, [section]: updatedSection }));
  };

  const addNestedItem = (section, newItem) => {
    const currentItems = formData[section] || [];
    if (currentItems.length < 3) {
      setFormData(prev => ({ ...prev, [section]: [...currentItems, newItem] }));
    }
  };

  const removeNestedItem = (index, section) => {
    setFormData(prev => ({ ...prev, [section]: (formData[section] || []).filter((_, i) => i !== index) }));
  };

  const handleCheckboxChange = (instrument) => {
    const currentInstruments = formData.instrumentos_evaluacion || [];
    const newInstruments = currentInstruments.includes(instrument)
      ? currentInstruments.filter(item => item !== instrument)
      : [...currentInstruments, instrument];
    setFormData(prev => ({ ...prev, instrumentos_evaluacion: newInstruments }));
  };

  const isSubmitDisabled = loading || !formData.nombre_proyecto || !formData.problema_detectado || !formData.justificacion || !formData.objetivo_general;

  const evaluationInstruments = ["Actas", "Encuestas", "Registro fotográfico", "Rúbricas"];
  
  const objetivos_especificos = formData.objetivos_especificos || [];
  const actividades = formData.actividades || [];

  return (
    <TooltipProvider>
      <Card className="glass-effect border-lime-500/20 shadow-2xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
              <activeService.icon className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-white text-2xl">{activeService.title}</CardTitle>
              <CardDescription className="text-gray-300">Genera proyectos educativos estructurados con IA.</CardDescription>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="nombre_proyecto" className="text-white font-medium flex items-center">Nombre del Proyecto
                <Tooltip>
                    <TooltipTrigger asChild><Info className="w-4 h-4 ml-2 text-gray-400 cursor-pointer"/></TooltipTrigger>
                    <TooltipContent><p>Sé específico y creativo. Ej: 'Lectura para Crecer – Primaria 2024'</p></TooltipContent>
                </Tooltip>
              </Label>
              <Input id="nombre_proyecto" name="nombre_proyecto" placeholder="Ej: Proyecto Aula Verde 2025" value={formData.nombre_proyecto || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="problema_detectado" className="text-white font-medium flex items-center">Problema o Necesidad Detectada
                 <Tooltip>
                    <TooltipTrigger asChild><Info className="w-4 h-4 ml-2 text-gray-400 cursor-pointer"/></TooltipTrigger>
                    <TooltipContent><p>¿Es un problema académico, social, de infraestructura?</p></TooltipContent>
                </Tooltip>
              </Label>
              <Textarea id="problema_detectado" name="problema_detectado" placeholder="Ej: Falta de conciencia ambiental en estudiantes de secundaria" value={formData.problema_detectado || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white min-h-[80px]" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="justificacion" className="text-white font-medium">Justificación</Label>
              <Select onValueChange={(value) => handleInputChange({target: {name: 'justificacion', value}})} value={formData.justificacion || ''}>
                  <SelectTrigger className="w-full glass-effect border-white/20 text-white"><SelectValue placeholder="Selecciona una justificación o escribe la tuya" /></SelectTrigger>
                  <SelectContent className="bg-slate-800 text-white border-slate-700">
                      <SelectItem value="Mejora de aprendizajes">Mejora de aprendizajes</SelectItem>
                      <SelectItem value="Inclusión">Inclusión</SelectItem>
                      <SelectItem value="Innovación pedagógica">Innovación pedagógica</SelectItem>
                  </SelectContent>
              </Select>
              <Textarea name="justificacion" placeholder="O escribe tu propia justificación aquí..." value={formData.justificacion || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white mt-2" required />
            </div>
            
            <div className="space-y-2">
                <Label htmlFor="delimitacion" className="text-white font-medium">Delimitación</Label>
                <Input id="delimitacion" name="delimitacion" placeholder="Ej: Estudiantes de 9° grado, sede principal, primer semestre" value={formData.delimitacion || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white" />
            </div>

            <div className="space-y-2">
                <Label htmlFor="objetivo_general" className="text-white font-medium">Objetivo General</Label>
                <div className="flex gap-2">
                    <Select onValueChange={(value) => setFormData(prev => ({...prev, verbo_objetivo_general: value}))} value={formData.verbo_objetivo_general || ''}>
                        <SelectTrigger className="w-1/3 glass-effect border-white/20 text-white"><SelectValue placeholder="Verbo" /></SelectTrigger>
                        <SelectContent className="bg-slate-800 text-white border-slate-700">
                            <SelectItem value="Fomentar">Fomentar</SelectItem>
                            <SelectItem value="Diseñar">Diseñar</SelectItem>
                            <SelectItem value="Reducir">Reducir</SelectItem>
                            <SelectItem value="Incrementar">Incrementar</SelectItem>
                        </SelectContent>
                    </Select>
                    <Input id="objetivo_general" name="objetivo_general" placeholder="... el resto de tu objetivo" value={formData.objetivo_general || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white" required/>
                </div>
            </div>

            <div className="space-y-2">
              <Label className="text-white font-medium">Objetivos Específicos (hasta 3)</Label>
              {objetivos_especificos.map((obj, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Input 
                    value={obj.texto || ''} 
                    onChange={(e) => handleNestedChange(index, 'texto', e.target.value, 'objetivos_especificos')} 
                    placeholder="Verbo + contenido + población + tiempo" 
                    className="glass-effect border-white/20 text-white"
                  />
                  <Button type="button" variant="ghost" size="icon" onClick={() => removeNestedItem(index, 'objetivos_especificos')}>
                    <Trash2 className="w-5 h-5 text-red-500"/>
                  </Button>
                </div>
              ))}
              {objetivos_especificos.length < 3 && (
                <Button type="button" variant="outline" className="w-full border-dashed border-gray-500 text-gray-400" onClick={() => addNestedItem('objetivos_especificos', { texto: '' })}>
                  <PlusCircle className="w-4 h-4 mr-2"/>Añadir Objetivo Específico
                </Button>
              )}
            </div>

            <div className="space-y-2">
              <Label className="text-white font-medium">Actividades Principales</Label>
              {actividades.map((act, index) => (
                  <div key={index} className="flex flex-col md:flex-row gap-2 p-2 border border-dashed border-gray-600 rounded-lg">
                      <Input value={act.nombre || ''} onChange={(e) => handleNestedChange(index, 'nombre', e.target.value, 'actividades')} placeholder="Nombre de la Actividad" className="glass-effect border-white/20 text-white"/>
                      <Input value={act.responsable || ''} onChange={(e) => handleNestedChange(index, 'responsable', e.target.value, 'actividades')} placeholder="Responsable" className="glass-effect border-white/20 text-white"/>
                      <Input value={act.duracion || ''} onChange={(e) => handleNestedChange(index, 'duracion', e.target.value, 'actividades')} placeholder="Duración (ej. 2 semanas)" className="glass-effect border-white/20 text-white"/>
                      <Button type="button" variant="ghost" size="icon" onClick={() => removeNestedItem(index, 'actividades')}><Trash2 className="w-5 h-5 text-red-500"/></Button>
                  </div>
              ))}
               <Button type="button" variant="outline" className="w-full border-dashed border-gray-500 text-gray-400" onClick={() => addNestedItem('actividades', { nombre: '', responsable: '', duracion: '' })}>
                  <PlusCircle className="w-4 h-4 mr-2"/>Añadir Actividad
                </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label htmlFor="presupuesto" className="text-white font-medium">Presupuesto Aproximado</Label>
                    <div className="flex gap-2">
                        <Input id="presupuesto" name="presupuesto" type="number" placeholder="Ej: 500" value={formData.presupuesto || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white"/>
                        <Select onValueChange={(value) => setFormData(prev => ({...prev, moneda: value}))} value={formData.moneda || ''}>
                            <SelectTrigger className="w-1/3 glass-effect border-white/20 text-white"><SelectValue placeholder="Moneda" /></SelectTrigger>
                            <SelectContent className="bg-slate-800 text-white border-slate-700">
                                <SelectItem value="USD">USD</SelectItem>
                                <SelectItem value="EUR">EUR</SelectItem>
                                <SelectItem value="COP">COP</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="fechas" className="text-white font-medium">Fechas (Inicio y Fin)</Label>
                    <div className="flex gap-2">
                      <Input type="date" name="fecha_inicio" value={formData.fecha_inicio || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white"/>
                      <Input type="date" name="fecha_fin" value={formData.fecha_fin || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white"/>
                    </div>
                </div>
            </div>

            <div className="space-y-2">
                <Label className="text-white font-medium">Instrumentos de Evaluación</Label>
                <div className="flex flex-wrap gap-4">
                    {evaluationInstruments.map(instrument => (
                        <div key={instrument} className="flex items-center space-x-2">
                            <Checkbox id={instrument} onCheckedChange={() => handleCheckboxChange(instrument)} checked={(formData.instrumentos_evaluacion || []).includes(instrument)} className="border-white/30" />
                            <Label htmlFor={instrument} className="text-white">{instrument}</Label>
                        </div>
                    ))}
                </div>
            </div>

            <Button type="submit" className="w-full glow-effect bg-gradient-to-r from-lime-500 to-green-600 text-base py-3" disabled={isSubmitDisabled}>
              {loading ? (<> <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div> Generando Proyecto...</>) : (<> <FlaskConical className="w-5 h-5 mr-2" />Generar Proyecto Educativo</>)}
            </Button>
          </form>
        </CardContent>
      </Card>
    </TooltipProvider>
  );
};

export default EducationalProjectForm;