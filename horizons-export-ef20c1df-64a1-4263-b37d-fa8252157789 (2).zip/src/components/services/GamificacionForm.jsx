import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Gamepad2, Zap } from 'lucide-react';
import { gamificationElements, gamificationInteractionTypes } from '@/components/services/serviceUtils';

const GamificacionForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const currentElements = formData.elementos_juego || [];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (element) => {
    const updatedElements = currentElements.includes(element)
      ? currentElements.filter(item => item !== element)
      : [...currentElements, element];
    setFormData(prev => ({ ...prev, elementos_juego: updatedElements }));
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card className="glass-effect border-purple-500/20 shadow-xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
              <Gamepad2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="gradient-text text-2xl">{activeService.title}</CardTitle>
              <CardDescription className="text-gray-400">Transforma tus lecciones en aventuras motivadoras.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="tema_contenido" className="text-purple-300">Tema/Contenido de la Lección</Label>
                <Input id="tema_contenido" name="tema_contenido" value={formData.tema_contenido || ''} onChange={handleChange} placeholder="Ej: La tabla periódica" className="glass-effect" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="grado_nivel" className="text-purple-300">Grado/Nivel Educativo</Label>
                <Input id="grado_nivel" name="grado_nivel" value={formData.grado_nivel || ''} onChange={handleChange} placeholder="Ej: 7mo Grado" className="glass-effect" required />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="duracion" className="text-purple-300">Duración de la Actividad Gamificada</Label>
              <Input id="duracion" name="duracion" value={formData.duracion || ''} onChange={handleChange} placeholder="Ej: Una sesión de 45 minutos" className="glass-effect" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="objetivo_aprendizaje" className="text-purple-300">Objetivo de Aprendizaje Principal</Label>
              <Textarea id="objetivo_aprendizaje" name="objetivo_aprendizaje" value={formData.objetivo_aprendizaje || ''} onChange={handleChange} placeholder="¿Qué quieres que los estudiantes logren con esta experiencia gamificada?" className="glass-effect" required />
            </div>

            <div className="space-y-3">
              <Label className="text-purple-300">Elementos de Juego a Incluir</Label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-3 rounded-md bg-slate-900/50 border border-purple-500/20">
                {gamificationElements.map(element => (
                  <div key={element} className="flex items-center space-x-2">
                    <Checkbox id={`element-${element}`} checked={currentElements.includes(element)} onCheckedChange={() => handleCheckboxChange(element)} />
                    <Label htmlFor={`element-${element}`} className="text-sm text-gray-300 cursor-pointer">{element}</Label>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="tipo_interaccion" className="text-purple-300">Tipo de Interacción Preferida</Label>
              <Select value={formData.tipo_interaccion || ''} onValueChange={(value) => handleSelectChange('tipo_interaccion', value)}>
                <SelectTrigger className="glass-effect">
                  <SelectValue placeholder="Selecciona el tipo de interacción" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 text-white border-purple-500/50">
                  {gamificationInteractionTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={loading} className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold py-3 px-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">
                {loading ? 'Generando Plan...' : 'Crear Aventura Gamificada'}
                <Zap className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default GamificacionForm;