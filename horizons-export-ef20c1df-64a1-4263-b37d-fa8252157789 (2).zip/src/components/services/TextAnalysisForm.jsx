import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';
import { Loader2, Wand2, SearchCheck } from 'lucide-react';
import { 
  textAnalysisContexts, 
  textAnalysisBasicProcessing, 
  textAnalysisDeepAnalysis, 
  textAnalysisImprovement, 
  textAnalysisGeneration 
} from '@/components/services/serviceUtils';


const AnalysisSection = ({ title, options, formData, handleCheckboxChange, fieldName }) => (
  <div>
    <h3 className="text-md font-semibold text-purple-300 mb-2">{title}</h3>
    <div className="space-y-2">
      {options.map((option) => (
        <div key={option} className="flex items-center space-x-2">
          <Checkbox
            id={`${fieldName}-${option}`}
            checked={(formData[fieldName] || []).includes(option)}
            onCheckedChange={() => handleCheckboxChange(fieldName, option)}
            className="border-purple-400 data-[state=checked]:bg-purple-500 data-[state=checked]:text-white"
          />
          <Label htmlFor={`${fieldName}-${option}`} className="text-gray-300 font-medium text-sm">
            {option}
          </Label>
        </div>
      ))}
    </div>
  </div>
);


const TextAnalysisForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const { user } = useAuth();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleCheckboxChange = (fieldName, value) => {
    setFormData(prev => {
      const currentValues = prev[fieldName] || [];
      const newValues = currentValues.includes(value)
        ? currentValues.filter(item => item !== value)
        : [...currentValues, value];
      return { ...prev, [fieldName]: newValues };
    });
  };
  
  const handleBooleanCheckboxChange = (name, checked) => {
    setFormData(prev => ({...prev, [name]: checked}));
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!user) {
      toast({ title: "Error", description: "Debes iniciar sesión para usar este servicio.", variant: "destructive" });
      return;
    }
    if (!formData.texto_a_analizar || formData.texto_a_analizar.trim().length < 10) {
      toast({ title: "Entrada Inválida", description: "El texto a analizar debe tener al menos 10 caracteres.", variant: "destructive" });
      return;
    }
    onSubmit(e);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="glass-effect border-purple-500/20 shadow-xl">
        <CardHeader>
          <div className="flex items-center space-x-3">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService?.color || 'from-sky-500 to-indigo-500'} rounded-lg flex items-center justify-center shadow-lg`}>
              <SearchCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="gradient-text text-2xl sm:text-3xl">{activeService?.title || 'Análisis Textual'}</CardTitle>
              <CardDescription className="text-gray-400">Desbloquea el poder de tus textos con IA.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="texto_a_analizar" className="text-lg font-semibold text-purple-300 mb-2 block">📝 Entrada Principal</Label>
              <Textarea
                id="texto_a_analizar"
                name="texto_a_analizar"
                value={formData.texto_a_analizar}
                onChange={handleChange}
                placeholder="Pega aquí el texto que deseas analizar..."
                maxLength={10000}
                rows={8}
                className="glass-effect border-white/20 focus:border-purple-500"
                required
              />
              <p className="text-xs text-gray-400 mt-1 text-right">{formData.texto_a_analizar?.length || 0}/10000 caracteres</p>
            </div>
            
            <div>
                <Label htmlFor="contexto_personalizado" className="text-lg font-semibold text-purple-300 mb-2 block">Contexto Personalizado</Label>
                <Select
                    name="contexto_personalizado"
                    value={formData.contexto_personalizado}
                    onValueChange={(value) => handleSelectChange('contexto_personalizado', value)}
                >
                    <SelectTrigger className="w-full glass-effect border-white/20">
                        <SelectValue placeholder="Define el tipo de texto y su finalidad..."/>
                    </SelectTrigger>
                    <SelectContent className="glass-effect border-purple-500/30">
                        {textAnalysisContexts.map(option => (
                            <SelectItem key={option} value={option} className="hover:bg-purple-500/20 focus:bg-purple-500/20">
                                {option}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <AnalysisSection 
                title="Procesamiento Básico"
                options={textAnalysisBasicProcessing}
                formData={formData}
                handleCheckboxChange={handleCheckboxChange}
                fieldName="procesamiento_basico"
              />
              <AnalysisSection 
                title="Análisis Profundo"
                options={textAnalysisDeepAnalysis}
                formData={formData}
                handleCheckboxChange={handleCheckboxChange}
                fieldName="analisis_profundo"
              />
              <AnalysisSection 
                title="Mejora del Texto"
                options={textAnalysisImprovement}
                formData={formData}
                handleCheckboxChange={handleCheckboxChange}
                fieldName="mejora_texto"
              />
              <AnalysisSection 
                title="Generación Contenida"
                options={textAnalysisGeneration}
                formData={formData}
                handleCheckboxChange={handleCheckboxChange}
                fieldName="generacion_contenida"
              />
              
              <div className="lg:col-span-2">
                <h3 className="text-md font-semibold text-purple-300 mb-2">Opciones Adicionales</h3>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="traduccion_inteligente"
                      checked={formData.traduccion_inteligente}
                      onCheckedChange={(checked) => handleBooleanCheckboxChange('traduccion_inteligente', checked)}
                      className="border-purple-400 data-[state=checked]:bg-purple-500 data-[state=checked]:text-white"
                    />
                    <Label htmlFor="traduccion_inteligente" className="text-gray-300 font-medium text-sm">Traducción inteligente (Inglés)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="mapa_conceptual"
                      checked={formData.mapa_conceptual}
                      onCheckedChange={(checked) => handleBooleanCheckboxChange('mapa_conceptual', checked)}
                      className="border-purple-400 data-[state=checked]:bg-purple-500 data-[state=checked]:text-white"
                    />
                    <Label htmlFor="mapa_conceptual" className="text-gray-300 font-medium text-sm">Ideas para mapa conceptual</Label>
                  </div>
                </div>
              </div>
            </div>

            <Button type="submit" className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-3 text-lg shadow-lg transform transition-all duration-150 ease-in-out hover:scale-105 active:scale-95" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Analizando...
                </>
              ) : (
                <>
                  <Wand2 className="mr-2 h-5 w-5" />
                  Analizar Texto
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default TextAnalysisForm;