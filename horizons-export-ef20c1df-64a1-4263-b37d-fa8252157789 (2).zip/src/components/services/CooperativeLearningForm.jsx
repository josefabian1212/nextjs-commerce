import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Zap, Users } from 'lucide-react';
import { cooperativeLearningActivityTypes } from '@/components/services/serviceUtils';

const CooperativeLearningForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (value) => {
    setFormData(prev => ({ ...prev, tipo_actividad: value }));
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card className="glass-effect border-teal-500/20 shadow-xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
              <Users className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="gradient-text text-2xl">{activeService.title}</CardTitle>
              <CardDescription className="text-gray-400">Genera planes de talleres colaborativos y lúdicos.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="tema" className="text-purple-300">Tema del Taller</Label>
              <Input id="tema" name="tema" value={formData.tema} onChange={handleChange} placeholder="Ej: Construyendo puentes de amistad" className="glass-effect" required />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="grado" className="text-purple-300">Grado</Label>
                <Input id="grado" name="grado" value={formData.grado} onChange={handleChange} placeholder="Ej: 4to de primaria" className="glass-effect" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="duracion" className="text-purple-300">Duración</Label>
                <Input id="duracion" name="duracion" value={formData.duracion} onChange={handleChange} placeholder="Ej: 45 minutos" className="glass-effect" required />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="objetivo_principal" className="text-purple-300">Objetivo Principal</Label>
              <Textarea id="objetivo_principal" name="objetivo_principal" value={formData.objetivo_principal} onChange={handleChange} placeholder="Describe el principal objetivo de aprendizaje del taller" className="glass-effect" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="tipo_actividad" className="text-purple-300">Tipo de Actividad</Label>
              <Select onValueChange={handleSelectChange} value={formData.tipo_actividad} required>
                <SelectTrigger className="glass-effect w-full">
                  <SelectValue placeholder="Selecciona un tipo de actividad..." />
                </SelectTrigger>
                <SelectContent>
                  {cooperativeLearningActivityTypes.map((type) => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex justify-end">
              <Button type="submit" disabled={loading} className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold py-3 px-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">
                {loading ? 'Generando...' : 'Generar Taller Cooperativo'}
                <Zap className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default CooperativeLearningForm;