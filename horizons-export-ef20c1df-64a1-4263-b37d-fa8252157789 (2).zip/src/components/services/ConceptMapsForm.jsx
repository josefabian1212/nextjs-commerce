import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Zap, Map } from 'lucide-react';

const mapStructures = ["Jerárquico (de arriba hacia abajo)", "Radial (centro y radios)", "Lineal (secuencial)", "Sistémico (con retroalimentación)"];
const mapComplexities = ["Básico (ideas principales)", "Intermedio (con sub-ideas)", "Detallado (con ejemplos y conexiones)"];

const ConceptMapsForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card className="glass-effect border-pink-500/20 shadow-xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
              <Map className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="gradient-text text-2xl">{activeService.title}</CardTitle>
              <CardDescription className="text-gray-400">Genera la estructura para mapas conceptuales claros.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="tema" className="text-purple-300">Concepto o Tema Central</Label>
              <Input id="tema" name="tema" value={formData.tema || ''} onChange={handleChange} placeholder="Ej: La Revolución Industrial" className="glass-effect" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="ideas_clave" className="text-purple-300">Ideas o Conceptos Clave a Incluir</Label>
              <Textarea id="ideas_clave" name="ideas_clave" value={formData.ideas_clave || ''} onChange={handleChange} placeholder="Separa las ideas con comas. Ej: Máquina de vapor, urbanización, clase obrera, capitalismo" className="glass-effect" required />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-purple-300">Estructura del Mapa</Label>
                <Select onValueChange={(value) => handleSelectChange('estructura', value)} value={formData.estructura || ''} required>
                  <SelectTrigger className="glass-effect w-full"><SelectValue placeholder="Selecciona una estructura..." /></SelectTrigger>
                  <SelectContent>{mapStructures.map(structure => <SelectItem key={structure} value={structure}>{structure}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-purple-300">Nivel de Complejidad</Label>
                <Select onValueChange={(value) => handleSelectChange('complejidad', value)} value={formData.complejidad || ''} required>
                  <SelectTrigger className="glass-effect w-full"><SelectValue placeholder="Selecciona la complejidad..." /></SelectTrigger>
                  <SelectContent>{mapComplexities.map(complexity => <SelectItem key={complexity} value={complexity}>{complexity}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={loading} className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold py-3 px-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">
                {loading ? 'Generando...' : 'Generar Estructura de Mapa'}
                <Zap className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ConceptMapsForm;