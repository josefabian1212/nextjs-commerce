import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Zap, Brain } from 'lucide-react';
import { criticalThinkingActivityTypes } from '@/components/services/serviceUtils';

const CriticalThinkingForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card className="glass-effect border-yellow-500/20 shadow-xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="gradient-text text-2xl">{activeService.title}</CardTitle>
              <CardDescription className="text-gray-400">Genera talleres para desarrollar el análisis y la argumentación.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="tema" className="text-purple-300">Tema del Taller</Label>
              <Input id="tema" name="tema" value={formData.tema} onChange={handleChange} placeholder="Ej: El impacto de las redes sociales en la opinión pública" className="glass-effect" required />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="grado" className="text-purple-300">Grado / Nivel</Label>
                <Input id="grado" name="grado" value={formData.grado} onChange={handleChange} placeholder="Ej: 10º Grado, Universidad" className="glass-effect" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="duracion" className="text-purple-300">Duración</Label>
                <Input id="duracion" name="duracion" value={formData.duracion} onChange={handleChange} placeholder="Ej: 45 minutos" className="glass-effect" required />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="objetivo_principal" className="text-purple-300">Objetivo Principal</Label>
              <Textarea id="objetivo_principal" name="objetivo_principal" value={formData.objetivo_principal} onChange={handleChange} placeholder="Describe qué habilidad específica de pensamiento crítico quieres desarrollar." className="glass-effect" required />
            </div>

            <div className="space-y-2">
              <Label className="text-purple-300">Tipo de Actividad Principal</Label>
              <Select onValueChange={(value) => handleSelectChange('tipo_actividad', value)} value={formData.tipo_actividad} required>
                <SelectTrigger className="glass-effect w-full">
                  <SelectValue placeholder="Selecciona una actividad..." />
                </SelectTrigger>
                <SelectContent>
                  {criticalThinkingActivityTypes.map(activity => (
                    <SelectItem key={activity} value={activity}>{activity}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={loading} className="bg-gradient-to-r from-red-500 via-yellow-500 to-orange-500 hover:from-red-600 hover:to-yellow-600 text-white font-bold py-3 px-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">
                {loading ? 'Generando Taller...' : 'Generar Taller de P. Crítico'}
                <Zap className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default CriticalThinkingForm;