import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Brain, Zap } from 'lucide-react';
import { neuroLearningStyles, neuroFrequentEmotions, neuroPillars } from '@/components/services/serviceUtils';

const NeuroeducacionForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card className="glass-effect border-pink-500/20 shadow-xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="gradient-text text-2xl">{activeService.title}</CardTitle>
              <CardDescription className="text-gray-400">Diseña clases basadas en cómo aprende el cerebro.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="tema" className="text-purple-300">Tema</Label>
                <Input id="tema" name="tema" value={formData.tema} onChange={handleChange} placeholder="Ej: La fotosíntesis" className="glass-effect" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="grado" className="text-purple-300">Grado</Label>
                <Input id="grado" name="grado" value={formData.grado} onChange={handleChange} placeholder="Ej: 5to Grado" className="glass-effect" required />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                    <Label htmlFor="duracion" className="text-purple-300">Duración</Label>
                    <Input id="duracion" name="duracion" value={formData.duracion} onChange={handleChange} placeholder="Ej: 60 minutos" className="glass-effect" required />
                </div>
                <div className="space-y-2">
                    <Label className="text-purple-300">Estilo de Aprendizaje</Label>
                    <Select onValueChange={(value) => handleSelectChange('estilo_aprendizaje', value)} value={formData.estilo_aprendizaje} required>
                    <SelectTrigger className="glass-effect w-full"><SelectValue placeholder="Selecciona un estilo..." /></SelectTrigger>
                    <SelectContent>{neuroLearningStyles.map(style => <SelectItem key={style} value={style}>{style}</SelectItem>)}</SelectContent>
                    </Select>
                </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="nivel_atencional" className="text-purple-300">Nivel Atencional (1-10)</Label>
                <Input id="nivel_atencional" name="nivel_atencional" type="number" min="1" max="10" value={formData.nivel_atencional} onChange={handleChange} placeholder="Ej: 7" className="glass-effect" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confianza" className="text-purple-300">Confianza (1-10)</Label>
                <Input id="confianza" name="confianza" type="number" min="1" max="10" value={formData.confianza} onChange={handleChange} placeholder="Ej: 8" className="glass-effect" required />
              </div>
            </div>

            <div className="space-y-3">
              <Label className="text-purple-300">Emociones Frecuentes (selecciona una)</Label>
                <Select onValueChange={(value) => handleSelectChange('emociones', value)} value={formData.emociones} required>
                <SelectTrigger className="glass-effect w-full"><SelectValue placeholder="Selecciona una emoción..." /></SelectTrigger>
                <SelectContent>{neuroFrequentEmotions.map(emotion => <SelectItem key={emotion} value={emotion}>{emotion}</SelectItem>)}</SelectContent>
                </Select>
            </div>

            <div className="space-y-3">
                <Label className="text-purple-300">Pilares a Trabajar (selecciona uno)</Label>
                <Select onValueChange={(value) => handleSelectChange('pilares_trabajar', value)} value={formData.pilares_trabajar} required>
                    <SelectTrigger className="glass-effect w-full"><SelectValue placeholder="Selecciona un pilar..." /></SelectTrigger>
                    <SelectContent>{neuroPillars.map(pillar => <SelectItem key={pillar} value={pillar}>{pillar}</SelectItem>)}</SelectContent>
                </Select>
            </div>

            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={loading} className="bg-gradient-to-r from-pink-500 via-orange-500 to-yellow-500 hover:from-pink-600 hover:to-orange-600 text-white font-bold py-3 px-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">
                {loading ? 'Generando Plan...' : 'Generar Plan de Neuroeducación'}
                <Zap className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default NeuroeducacionForm;