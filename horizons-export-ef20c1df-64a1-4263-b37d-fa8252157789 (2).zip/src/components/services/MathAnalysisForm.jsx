import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Calculator, Loader2 } from 'lucide-react';
import { mathDifficulties, mathFormats } from '@/components/services/serviceUtils';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';

const MathAnalysisForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const { user } = useAuth();
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!user) {
      toast({ title: "Error", description: "Debes iniciar sesión para usar este servicio.", variant: "destructive" });
      return;
    }
    onSubmit(e);
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="glass-effect border-blue-500/20 shadow-xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService?.color || 'from-blue-500 to-cyan-500'} rounded-lg flex items-center justify-center shadow-lg`}>
              <Calculator className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="gradient-text text-2xl">{activeService?.title || 'Análisis Matemático'}</CardTitle>
              <CardDescription className="text-gray-400">
                Genera problemas matemáticos adaptados a tus necesidades.
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <Label htmlFor="grado" className="text-purple-300">Grado</Label>
                <Input id="grado" name="grado" value={formData.grado} onChange={handleChange} placeholder="Ej: 8° de Secundaria" className="glass-effect" required />
              </div>
              <div>
                <Label htmlFor="asignatura" className="text-purple-300">Asignatura</Label>
                <Input id="asignatura" name="asignatura" value={formData.asignatura} onChange={handleChange} placeholder="Ej: Álgebra, Cálculo" className="glass-effect" required />
              </div>
              <div>
                <Label htmlFor="tema" className="text-purple-300">Tema</Label>
                <Input id="tema" name="tema" value={formData.tema} onChange={handleChange} placeholder="Ej: Ecuaciones lineales" className="glass-effect" required />
              </div>
            </div>

            <div>
              <Label htmlFor="problema_base" className="text-purple-300">Problema Base (Modelo)</Label>
              <Input
                id="problema_base"
                name="problema_base"
                value={formData.problema_base}
                onChange={handleChange}
                placeholder="Ej: Resuelve 3x - 5 = 16"
                className="glass-effect"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="dificultad" className="text-purple-300">Dificultad Seleccionada</Label>
                <Select name="dificultad" value={formData.dificultad} onValueChange={(value) => handleSelectChange('dificultad', value)} required>
                  <SelectTrigger className="w-full glass-effect">
                    <SelectValue placeholder="Selecciona una dificultad" />
                  </SelectTrigger>
                  <SelectContent className="glass-effect border-purple-500/30">
                    {mathDifficulties.map(option => (
                      <SelectItem key={option} value={option} className="capitalize hover:bg-purple-500/20 focus:bg-purple-500/30">{option}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="formato_salida" className="text-purple-300">Formato de Salida Deseado</Label>
                <Select name="formato_salida" value={formData.formato_salida} onValueChange={(value) => handleSelectChange('formato_salida', value)} required>
                  <SelectTrigger className="w-full glass-effect">
                    <SelectValue placeholder="Selecciona un formato" />
                  </SelectTrigger>
                  <SelectContent className="glass-effect border-purple-500/30">
                    {mathFormats.map(option => (
                      <SelectItem key={option} value={option} className="capitalize hover:bg-purple-500/20 focus:bg-purple-500/30">{option}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-bold py-3 px-6 rounded-lg shadow-lg transition-all duration-300 ease-in-out transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Generando Problema...
                </>
              ) : (
                <>
                  <Calculator className="mr-2 h-5 w-5" />
                  Generar Problema
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default MathAnalysisForm;