import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Zap } from 'lucide-react';
import { childrenCreativitySkills } from '@/components/services/serviceUtils';

const ChildrenCreativityForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (value) => {
    setFormData(prev => ({ ...prev, habilidades: value }));
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card className="glass-effect border-yellow-500/20 shadow-xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
              <activeService.icon className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="gradient-text text-2xl">{activeService.title}</CardTitle>
              <CardDescription className="text-gray-400">Diseña talleres lúdicos para despertar la imaginación.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="nombre_taller" className="text-purple-300">📌 Nombre del Taller</Label>
              <Input id="nombre_taller" name="nombre_taller" value={formData.nombre_taller || ''} onChange={handleChange} placeholder="Ej: Exploradores de Emociones" className="glass-effect" required />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="grado_edad" className="text-purple-300">🎓 Grado o Nivel</Label>
              <Input id="grado_edad" name="grado_edad" value={formData.grado_edad || ''} onChange={handleChange} placeholder="Ej: Preescolar (4-5 años)" className="glass-effect" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="descripcion" className="text-purple-300">📝 Descripción Breve</Label>
              <Textarea id="descripcion" name="descripcion" value={formData.descripcion || ''} onChange={handleChange} placeholder="Describe la idea principal del taller en una o dos frases." className="glass-effect" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="objetivos" className="text-purple-300">🎯 Objetivos Principales</Label>
              <Textarea id="objetivos" name="objetivos" value={formData.objetivos || ''} onChange={handleChange} placeholder="¿Qué quieres que los niños aprendan o logren con este taller?" className="glass-effect" required />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="duracion" className="text-purple-300">⏳ Duración Estimada</Label>
                <Input id="duracion" name="duracion" value={formData.duracion || ''} onChange={handleChange} placeholder="Ej: 45 minutos" className="glass-effect" required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="habilidades" className="text-purple-300">🧩 Habilidades a Desarrollar</Label>
                <Select onValueChange={handleSelectChange} value={formData.habilidades || ''} name="habilidades" required>
                  <SelectTrigger className="glass-effect w-full">
                    <SelectValue placeholder="Selecciona una habilidad..." />
                  </SelectTrigger>
                  <SelectContent>
                    {childrenCreativitySkills.map((skill) => (
                      <SelectItem key={skill} value={skill}>{skill}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex justify-end">
              <Button type="submit" disabled={loading} className="bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700 text-white font-bold py-3 px-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">
                {loading ? 'Generando Taller...' : 'Generar Taller con IA'}
                <Zap className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ChildrenCreativityForm;