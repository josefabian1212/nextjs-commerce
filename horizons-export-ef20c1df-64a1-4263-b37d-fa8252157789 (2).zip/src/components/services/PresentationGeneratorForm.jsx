import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Zap, Presentation } from 'lucide-react';

const presentationTones = ["Informativo", "Persuasivo", "Inspirador", "Entretenido", "Educativo"];
const presentationAudiences = ["Estudiantes (Primaria)", "Estudiantes (Secundaria)", "Estudiantes (Universidad)", "Profesionales", "Público General"];

const PresentationGeneratorForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card className="glass-effect border-orange-500/20 shadow-xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
              <Presentation className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="gradient-text text-2xl">{activeService.title}</CardTitle>
              <CardDescription className="text-gray-400">Crea esquemas de presentaciones impactantes.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="tema" className="text-purple-300">Tema de la Presentación</Label>
              <Input id="tema" name="tema" value={formData.tema || ''} onChange={handleChange} placeholder="Ej: El futuro de la energía renovable" className="glass-effect" required />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="numero_diapositivas" className="text-purple-300">Número de Diapositivas</Label>
                <Input id="numero_diapositivas" name="numero_diapositivas" type="number" min="3" max="20" value={formData.numero_diapositivas || ''} onChange={handleChange} placeholder="Ej: 10" className="glass-effect" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="duracion" className="text-purple-300">Duración (minutos)</Label>
                <Input id="duracion" name="duracion" type="number" min="1" value={formData.duracion || ''} onChange={handleChange} placeholder="Ej: 15" className="glass-effect" required />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="objetivo" className="text-purple-300">Objetivo Principal</Label>
              <Textarea id="objetivo" name="objetivo" value={formData.objetivo || ''} onChange={handleChange} placeholder="¿Qué quieres que la audiencia piense, sienta o haga después de tu presentación?" className="glass-effect" required />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-purple-300">Tono</Label>
                <Select onValueChange={(value) => handleSelectChange('tono', value)} value={formData.tono || ''} required>
                  <SelectTrigger className="glass-effect w-full"><SelectValue placeholder="Selecciona un tono..." /></SelectTrigger>
                  <SelectContent>{presentationTones.map(tone => <SelectItem key={tone} value={tone}>{tone}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-purple-300">Audiencia</Label>
                <Select onValueChange={(value) => handleSelectChange('audiencia', value)} value={formData.audiencia || ''} required>
                  <SelectTrigger className="glass-effect w-full"><SelectValue placeholder="Selecciona una audiencia..." /></SelectTrigger>
                  <SelectContent>{presentationAudiences.map(audience => <SelectItem key={audience} value={audience}>{audience}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={loading} className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-bold py-3 px-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">
                {loading ? 'Generando...' : 'Generar Esquema de Presentación'}
                <Zap className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default PresentationGeneratorForm;