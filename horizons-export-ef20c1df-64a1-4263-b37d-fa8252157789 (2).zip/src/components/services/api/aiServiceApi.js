import { supabase } from '@/lib/supabase';
    import { toast } from '@/components/ui/use-toast';
    
    export const handleAIServiceResponse = async ({
      user,
      serviceType,
      formData,
      creditsRequired = 1,
      successMessage = "¡Contenido generado exitosamente!",
      setLoading,
      setGeneratedContent,
      setParsedGeneratedData,
      spendTokens,
      onSuccess
    }) => {
      if (!user) {
        toast({
          title: "Error de autenticación",
          description: "Debes iniciar sesión para usar este servicio.",
          variant: "destructive"
        });
        return;
      }
    
      if (!serviceType || !formData) {
        toast({
          title: "Error Interno",
          description: "Falta información del servicio o del formulario. Por favor, recarga la página.",
          variant: "destructive"
        });
        return;
      }
    
      setLoading(true);
      setGeneratedContent('');
      if (setParsedGeneratedData) setParsedGeneratedData(null);
    
      const inputSummary = formData.tema || formData.topic || formData.titulo || formData.nombre_examen || `Generación de ${serviceType}`;
    
      try {
        const creditCheck = await spendTokens(creditsRequired, inputSummary, serviceType);
    
        if (!creditCheck) {
          setLoading(false);
          return;
        }
    
        const startTime = Date.now();
        
        const functionName = 'openai-proxy';
        const bodyPayload = { serviceType, formData: { ...formData, userId: user.id } };
    
        const { data, error } = await supabase.functions.invoke(functionName, {
          body: bodyPayload,
        });
    
        const processingTime = Date.now() - startTime;
    
        if (error) {
            if (error.message.includes('Failed to fetch')) {
                throw new Error("Error de red al contactar el servicio de IA. Por favor, revisa tu conexión.");
            }
            throw error;
        }
        if (data.error) throw new Error(data.error);
    
        if (!data.content) {
          throw new Error('No se recibió contenido en la respuesta de la IA.');
        }
        
        const responseText = data.content;
    
        const { data: dbEntry, error: dbError } = await supabase.from('ai_service_responses').insert({
          user_id: user.id,
          service_type: serviceType,
          input_data: formData,
          response_text: responseText,
          parsed_response: data.dbRecord || null,
          credits_used: creditsRequired,
          processing_time_ms: processingTime,
          status: 'completed'
        }).select().single();
    
        if (dbError) {
          console.warn("Error guardando la respuesta en la base de datos, pero el contenido fue generado:", dbError);
        }
    
        setGeneratedContent(responseText);
        if (setParsedGeneratedData) setParsedGeneratedData(data.dbRecord || null);
    
        toast({
          title: successMessage,
          description: `Procesado en ${(processingTime / 1000).toFixed(1)}s`,
        });
    
        if (onSuccess) {
          onSuccess({ content: responseText, dbRecord: data.dbRecord || dbEntry });
        }
    
      } catch (error) {
        console.error(`Error en ${serviceType}:`, error);
        
        await supabase.from('ai_service_responses').insert({
          user_id: user.id,
          service_type: serviceType,
          input_data: formData,
          credits_used: 0,
          status: 'failed',
          response_text: error.message
        }).catch(dbError => console.warn('Error guardando la respuesta fallida:', dbError));
    
        let errorMessage = "No se pudo generar el contenido solicitado.";
        if (error.message?.includes('Failed to fetch') || error.message?.includes('NetworkError')) {
          errorMessage = "Error de conexión. Verifica tu conexión e intenta de nuevo.";
        } else if (error.message) {
          errorMessage = error.message;
        }
    
        toast({
          title: "Error al generar contenido",
          description: errorMessage,
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };
    
    export const getUserAIHistory = async (userId, serviceType = null, limit = 10) => {
      try {
        let query = supabase
          .from('ai_service_responses')
          .select('*')
          .eq('user_id', userId)
          .order('created_at', { ascending: false })
          .limit(limit);
    
        if (serviceType) {
          query = query.eq('service_type', serviceType);
        }
    
        const { data, error } = await query;
    
        if (error) {
          if (error.message.includes('Failed to fetch')) {
            toast({ title: "Error de Red", description: "No se pudo cargar el historial.", variant: "destructive" });
          }
          throw error;
        }
        return data;
      } catch (error) {
        console.error('Error fetching AI history:', error);
        return [];
      }
    };
    
    export const getUserAIStats = async (userId) => {
      try {
        const { data, error } = await supabase.rpc('get_user_ai_stats', {
          p_user_id: userId
        });
    
        if (error) {
          if (error.message.includes('Failed to fetch')) {
            toast({ title: "Error de Red", description: "No se pudieron cargar las estadísticas.", variant: "destructive" });
          }
          throw error;
        }
        return data;
      } catch (error) {
        console.error('Error fetching AI stats:', error);
        return {
          total_services_used: 0,
          total_credits_spent: 0,
          most_used_service: null,
          last_activity: null,
          services_this_month: 0
        };
      }
    };
    
    export const checkSystemHealth = async () => {
      try {
        const { data, error } = await supabase.functions.invoke('test-openai-connection');
        
        if (error) {
          if (error.message.includes('Failed to fetch')) {
            return { status: 'error', message: 'Error de red al verificar el sistema.' };
          }
          throw error;
        }
        
        return {
          status: data.success ? 'healthy' : 'degraded',
          message: data.success ? 'Sistema funcionando correctamente' : 'Algunos servicios pueden estar limitados'
        };
      } catch (error) {
        console.error('Error checking system health:', error);
        return {
          status: 'error',
          message: 'Error al verificar el estado del sistema'
        };
      }
    };