export const initialClassPreparerFormData = {
  tema: '',
  grado: '',
  asignatura: '',
  pais: '',
  duracion: '',
  unidad: '',
  objetivo: '',
};

export const initialPedagogicalWorkshopFormData = {
  tema: '',
  grado: '',
  objetivo_principal: '',
  duracion: '',
  tipo_actividad: 'Didáctica',
};

export const initialCooperativeLearningFormData = {
  tema: '',
  grado: '',
  objetivo_principal: '',
  duracion: '',
  tipo_actividad: 'Juegos cooperativos',
};

export const initialChildrenCreativityFormData = {
  nombre_taller: '',
  grado_edad: '',
  descripcion: '',
  objetivos: '',
  duracion: '',
  habilidades: 'Competencias cognitivas',
};

export const initialPresentationGeneratorFormData = {
  tema: '',
  numero_diapositivas: 10,
  duracion: 15,
  objetivo: '',
  tono: 'Informativo',
  audiencia: 'Público General',
};

export const initialConceptMapsFormData = {
  tema: '',
  ideas_clave: '',
  estructura: 'Jerárquico (de arriba hacia abajo)',
  complejidad: 'Intermedio (con sub-ideas)',
};

export const initialGenerateArticleFormData = {
  tema_principal: '',
  tipo_articulo: 'Informativo',
  tono_articulo: 'Formal',
  audiencia_objetivo: 'Público general',
  longitud_aproximada: 'Corto (1000 palabras)',
};

export const initialGamificacionFormData = {
  tema_contenido: '',
  grado_nivel: '',
  duracion: '',
  objetivo_aprendizaje: '',
  elementos_juego: [],
  tipo_interaccion: 'Individual (auto-desafío)',
};

export const initialInteligenciaArtificialFormData = {
  tema_materia: '',
  grado_nivel: '',
  duracion: '',
  objetivo_pedagogico: '',
  area_aplicacion: [],
  tipo_herramienta: [],
};