export const initialClassPreparerFormData = {
  tema: '',
  grado: '',
  asignatura: '',
  duracion: '',
  unidad: '',
  pais: '',
  objetivo: '',
};

export const initialPedagogicalWorkshopFormData = {
  tema: '',
  grado: '',
  objetivo_principal: '',
  duracion: '',
  tipo_actividad: 'Didáctica',
};

export const initialAtencionDiversidadFormData = {
  tema: '',
  grado: '',
  asignatura: '',
  pais: '',
  duracion: '',
  unidad: '',
  objetivo: '',
  tipo_necesidad: 'TDAH (Atención e Hiperactividad)',
};

export const initialCooperativeLearningFormData = {
  tema_actividad: '',
  grado_nivel: '',
  objetivo_aprendizaje: '',
  duracion: '',
  tipo_actividad: 'Juegos cooperativos',
};

export const initialChildrenCreativityFormData = {
  nombre_taller: '',
  grado_edad: '',
  descripcion: '',
  objetivos: '',
  duracion: '',
  habilidades: ['Creativas'],
};

export const initialUnitTopicsFormData = {
  grade: '',
  asignatura: '',
  topic: '',
  numero_clases: 5,
  estandar: '',
};

export const initialEducationalProjectFormData = {
  tema: '',
  grado: '',
  asignatura: '',
  objetivo: '',
  duracion: '2 semanas',
  metodologia: 'Aprendizaje Basado en Proyectos (ABP)',
};

export const initialCriticalThinkingFormData = {
  tema_taller: '',
  grado_nivel: '',
  duracion: '45 minutos',
  objetivo_principal: '',
  tipo_actividad: 'Debates estructurados (sobre temas controvertidos)',
};

export const initialMultipleIntelligencesFormData = {
  tema_taller: '',
  grado_nivel: '',
  duracion: '60 minutos',
  objetivo_principal: '',
  inteligencia_enfocar: ['Lingüística (uso del lenguaje)'],
};

export const initialNeuroeducacionFormData = {
  tema: '',
  grado: '',
  duracion: '60 minutos',
  estilo_aprendizaje: 'Visual',
  nivel_atencional: '5',
  confianza: '5',
  emociones: 'Interés / Entusiasmo',
  pilares_trabajar: 'Atención',
};

export const initialGamificacionFormData = {
  tema_contenido: '',
  grado_nivel: '',
  duracion: '45 minutos',
  objetivo_aprendizaje: '',
  elementos_juego: ['Puntos'],
  tipo_interaccion: 'Individual (auto-desafío)',
};

export const initialInteligenciaArtificialFormData = {
  tema_materia: '',
  grado_nivel: '',
  duracion: '1 clase (45-60 min)',
  objetivo_pedagogico: '',
  area_aplicacion: ['Generación de Contenido'],
  tipo_herramienta: ['Generadores de Contenido/Lecciones (ej., ChatGPT, Eduaide.ai)'],
};

export const initialEvaluacionFormativaFormData = {
    tema_contenido: '',
    grado_nivel: '',
    duracion: '15 minutos',
    objetivo_aprendizaje: '',
    tipo_retroalimentacion: 'Inmediata y Directa',
    estrategia_evaluacion: 'Boletos de salida/Entrada',
};