// ✅ TAREA 5: Módulo separado para formularios de medios

// Tutoriales
export const initialTutorialFormData = {
  tema_tutorial: '',
  grade: '',
  difficulty: 'Intermedio',
  objective: '',
  format: [],
};

// Poemas y Canciones
export const initialPoemSongFormData = {
  topic: '',
  extension: 'Medio',
  type: [],
  tone: [],
};

export const poemTypes = [
  "Acróstico", "Balada", "Caligrama", "Copla", "Elegía", "Épico", "Epitafio", 
  "Haiku", "Himno", "Oda", "Quintilla cómica", "Romance", "Sátira", 
  "Sexto", "Soneto", "Verso en blanco", "Verso libre", "Villanelle"
];

export const poemTones = [
  "Formal", "Informal", "Sarcástico", "Romántico", "Triste", "Reflexivo", "Optimista"
];

export const poemExtensions = ["Corto", "Medio", "Largo"];

// Podcasts
export const initialPodcastFormData = {
  titulo: '',
  tema_central: '',
  objetivo: '🧠 Educar',
  duracion: '',
  publico: '',
  formato: '🎙️ Entrevista',
  tono: 'Inteligente',
  tipo: 'Informativo',
};