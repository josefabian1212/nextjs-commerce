// ✅ TAREA 5: Módulo separado para formularios de negocio

// Startups
export const initialStartupPlanFormData = {
  pasiones_intereses: '',
  problema_mercado: '',
  viabilidad_ia: '',
  tipo_estudio_mercado: '',
  competidores_directos: '',
  cliente_ideal: '',
  plantilla: '',
  estrategia_marketing: '',
  financiamiento: ''
};

export const startupPassions = ['Tecnología', 'Sostenibilidad', 'Salud', 'Educación', 'Arte', 'Emprendimiento social', 'Astronomía', 'Gastronomía', 'Turismo', 'Deportes', 'Innovación social'];
export const startupViabilityTools = ['Google Trends', 'ChatGPT', 'Perplexity AI'];
export const startupMarketResearchTypes = ['Encuestas online', 'Análisis de competencia', 'Entrevistas a clientes potenciales'];
export const startupCustomerProfiles = ['B2C', 'B2B', 'Híbrido'];
export const startupTemplates = ['Tradicional', 'Lean Startup'];
export const startupMarketingStrategies = ['Redes sociales', 'Email marketing', 'SEO'];

// PQRS
export const initialPqrsFormData = {
  fecha: new Date().toISOString().split('T')[0], 
  dirigido_a: '',
  tipo_pqrs: 'Petición',
  detalles_pqrs: '',
  enviado_por: '',
  incluir_ley: false,
  incluir_radicado: false,
};