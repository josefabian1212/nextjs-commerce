export const initialCognitiveAnalysisFormData = {
  tema_analizar: '',
  grado_nivel: '',
  nivel_profundidad: 'Analítico',
  tipo_razonamiento: 'Ninguno',
  tipo_analisis_especifico: 'Ninguno',
  tipo_creatividad_percepcion: 'Ninguno',
};

export const initialTextAnalysisFormData = {
  texto_a_analizar: '',
  contexto_personalizado: 'Académico',
  procesamiento_basico: [],
  analisis_profundo: [],
  mejora_texto: [],
  generacion_contenida: [],
  traduccion_inteligente: false,
  mapa_conceptual: false,
};

export const initialMathAnalysisFormData = {
  grado: '',
  asignatura: '',
  tema: '',
  problema_base: '',
  dificultad: 'Básica',
  formato_salida: 'Resolución paso a paso',
};