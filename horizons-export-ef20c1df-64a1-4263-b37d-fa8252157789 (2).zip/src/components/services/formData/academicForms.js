export const initialUnitTopicsFormData = {
  grade: '',
  asignatura: '',
  topic: '',
  numero_clases: 5,
  estandar: '',
};

export const initialEducationalProjectFormData = {
  nombre_proyecto: '',
  problema_detectado: '',
  justificacion: 'Mejora de aprendizajes',
  delimitacion: '',
  verbo_objetivo_general: 'Fomentar',
  objetivo_general: '',
  objetivos_especificos: [],
  actividades: [],
  presupuesto: '',
  moneda: 'USD',
  fecha_inicio: '',
  fecha_fin: '',
  instrumentos_evaluacion: [],
};

export const initialMathAnalysisFormData = {
  grado: '',
  asignatura: '',
  tema: '',
  problema_enunciado: '',
  dificultad: 'intermedia',
  formato: 'resolución paso a paso',
};

export const mathDifficulties = ['básica', 'intermedia', 'avanzada'];
export const mathFormats = ['opción múltiple', 'resolución paso a paso', 'problema verbal'];