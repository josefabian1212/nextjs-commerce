import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Zap } from 'lucide-react';
import { multipleIntelligencesActivityTypes } from '@/components/services/serviceUtils';

const MultipleIntelligencesForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (intelligence) => {
    setFormData(prev => {
      const currentIntelligences = prev.inteligencia_enfocar || [];
      const newIntelligences = currentIntelligences.includes(intelligence)
        ? currentIntelligences.filter(item => item !== intelligence)
        : [...currentIntelligences, intelligence];
      return { ...prev, inteligencia_enfocar: newIntelligences };
    });
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card className="glass-effect border-teal-500/20 shadow-xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="gradient-text text-2xl">{activeService.title}</CardTitle>
              <CardDescription className="text-gray-400">Diseña talleres para las diversas inteligencias de tus alumnos.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="tema_taller" className="text-purple-300">Tema del Taller</Label>
              <Input id="tema_taller" name="tema_taller" value={formData.tema_taller || ''} onChange={handleChange} placeholder="Ej: El ciclo del agua" className="glass-effect" required />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="grado_nivel" className="text-purple-300">Grado / Nivel</Label>
                <Input id="grado_nivel" name="grado_nivel" value={formData.grado_nivel || ''} onChange={handleChange} placeholder="Ej: 3er Grado de Primaria" className="glass-effect" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="duracion" className="text-purple-300">Duración</Label>
                <Input id="duracion" name="duracion" value={formData.duracion || ''} onChange={handleChange} placeholder="Ej: 60 minutos" className="glass-effect" required />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="objetivo_principal" className="text-purple-300">Objetivo Principal</Label>
              <Textarea id="objetivo_principal" name="objetivo_principal" value={formData.objetivo_principal || ''} onChange={handleChange} placeholder="Ej: Comprender el proceso del ciclo del agua y su importancia en la vida diaria." className="glass-effect" required />
            </div>

            <div className="space-y-4">
              <Label className="text-purple-300">Inteligencia a Enfocar</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {multipleIntelligencesActivityTypes.map((intelligence) => (
                  <div key={intelligence} className="flex items-center space-x-2">
                    <Checkbox
                      id={intelligence}
                      checked={(formData.inteligencia_enfocar || []).includes(intelligence)}
                      onCheckedChange={() => handleCheckboxChange(intelligence)}
                    />
                    <Label htmlFor={intelligence} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-gray-300">
                      {intelligence}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={loading} className="bg-gradient-to-r from-teal-400 to-blue-500 hover:from-teal-500 hover:to-blue-600 text-white font-bold py-3 px-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">
                {loading ? 'Generando Taller...' : 'Generar Taller de I. Múltiples'}
                <Zap className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default MultipleIntelligencesForm;