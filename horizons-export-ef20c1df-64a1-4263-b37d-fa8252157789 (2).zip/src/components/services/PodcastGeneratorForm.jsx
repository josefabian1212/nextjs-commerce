import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Mic, Loader2 } from 'lucide-react';

const podcastObjetivos = ["🧠 Educar", "😄 Entretener", "✨ Inspirar", "📢 Promocionar"];
const podcastFormatos = ["🎙️ Entrevista", "🎧 Monólogo", "💬 Conversacional", "📖 Narrativo"];
const podcastTonos = ["Persuasivo", "Emotivo", "Inteligente", "Racional"];
const podcastTipos = ["Informativo", "Educativo", "Comunitario", "Conversacional", "Político", "Social", "Religioso", "Argumentativo", "Poético", "Sarcástico", "Holístico"];

const PodcastGeneratorForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const serviceIcon = activeService?.icon || Mic;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <Card className="bg-slate-800/70 border-pink-500/30 shadow-xl">
        <CardHeader className="pb-4">
          <div className="flex items-center space-x-3">
            {React.createElement(serviceIcon, { className: `w-8 h-8 text-pink-400` })}
            <CardTitle className="text-2xl font-bold text-pink-300">{activeService?.title || 'Generador de Pódcasts'}</CardTitle>
          </div>
          <CardDescription className="text-gray-400">
            Crea guiones completos y esquemas para tus episodios de pódcast con IA.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div>
              <Label htmlFor="titulo" className="text-gray-300 mb-1 block">Título del Episodio</Label>
              <Input
                id="titulo"
                name="titulo"
                value={formData.titulo || ''}
                onChange={handleChange}
                placeholder="Nombre del episodio"
                className="bg-slate-700 border-slate-600 text-white placeholder-gray-500 focus:ring-pink-500 focus:border-pink-500"
                required
              />
            </div>

            <div>
              <Label htmlFor="tema_central" className="text-gray-300 mb-1 block">Tema Central</Label>
              <Input
                id="tema_central"
                name="tema_central"
                value={formData.tema_central || ''}
                onChange={handleChange}
                placeholder="Ej: Inteligencia Artificial en la educación"
                className="bg-slate-700 border-slate-600 text-white placeholder-gray-500 focus:ring-pink-500 focus:border-pink-500"
                required
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="objetivo" className="text-gray-300 mb-1 block">Objetivo</Label>
                <Select name="objetivo" value={formData.objetivo || ''} onValueChange={(value) => handleSelectChange('objetivo', value)} required>
                  <SelectTrigger className="w-full bg-slate-700 border-slate-600 text-white focus:ring-pink-500 focus:border-pink-500">
                    <SelectValue placeholder="Selecciona un objetivo" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-white">
                    {podcastObjetivos.map(option => (
                      <SelectItem key={option} value={option} className="hover:bg-pink-500/20 focus:bg-pink-500/30">{option}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="formato" className="text-gray-300 mb-1 block">Formato</Label>
                <Select name="formato" value={formData.formato || ''} onValueChange={(value) => handleSelectChange('formato', value)} required>
                  <SelectTrigger className="w-full bg-slate-700 border-slate-600 text-white focus:ring-pink-500 focus:border-pink-500">
                    <SelectValue placeholder="Selecciona un formato" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-white">
                    {podcastFormatos.map(option => (
                      <SelectItem key={option} value={option} className="hover:bg-pink-500/20 focus:bg-pink-500/30">{option}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="duracion" className="text-gray-300 mb-1 block">Duración Estimada</Label>
                <Input
                  id="duracion"
                  name="duracion"
                  value={formData.duracion || ''}
                  onChange={handleChange}
                  placeholder="Ej: 10 minutos, 20-30 min"
                  className="bg-slate-700 border-slate-600 text-white placeholder-gray-500 focus:ring-pink-500 focus:border-pink-500"
                  required
                />
              </div>
              <div>
                <Label htmlFor="publico" className="text-gray-300 mb-1 block">Público Objetivo</Label>
                <Input
                  id="publico"
                  name="publico"
                  value={formData.publico || ''}
                  onChange={handleChange}
                  placeholder="Ej: Estudiantes universitarios"
                  className="bg-slate-700 border-slate-600 text-white placeholder-gray-500 focus:ring-pink-500 focus:border-pink-500"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="tono" className="text-gray-300 mb-1 block">Tono</Label>
                <Select name="tono" value={formData.tono || ''} onValueChange={(value) => handleSelectChange('tono', value)} required>
                  <SelectTrigger className="w-full bg-slate-700 border-slate-600 text-white focus:ring-pink-500 focus:border-pink-500">
                    <SelectValue placeholder="Selecciona un tono" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-white">
                    {podcastTonos.map(option => (
                      <SelectItem key={option} value={option} className="hover:bg-pink-500/20 focus:bg-pink-500/30">{option}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="tipo" className="text-gray-300 mb-1 block">Tipo de Pódcast</Label>
                <Select name="tipo" value={formData.tipo || ''} onValueChange={(value) => handleSelectChange('tipo', value)} required>
                  <SelectTrigger className="w-full bg-slate-700 border-slate-600 text-white focus:ring-pink-500 focus:border-pink-500">
                    <SelectValue placeholder="Selecciona un tipo" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-white">
                    {podcastTipos.map(option => (
                      <SelectItem key={option} value={option} className="hover:bg-pink-500/20 focus:bg-pink-500/30">{option}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button 
              type="submit" 
              disabled={loading} 
              className="w-full bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white font-semibold py-3 px-6 rounded-lg shadow-lg transition-all duration-300 ease-in-out transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Generando Guión...
                </>
              ) : (
                <>
                  <Mic className="mr-2 h-5 w-5" />
                  Generar Guión de Pódcast
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default PodcastGeneratorForm;