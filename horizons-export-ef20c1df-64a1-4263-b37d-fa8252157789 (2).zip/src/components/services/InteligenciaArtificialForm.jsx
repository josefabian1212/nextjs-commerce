import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Brain, Zap } from 'lucide-react';
import { iaApplicationAreas, iaToolTypes } from '@/components/services/serviceUtils';

const InteligenciaArtificialForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const currentAreaAplicacion = formData.area_aplicacion || [];
  const currentTipoHerramienta = formData.tipo_herramienta || [];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (name, value) => {
    const currentValues = formData[name] || [];
    const newValues = currentValues.includes(value)
      ? currentValues.filter(item => item !== value)
      : [...currentValues, value];
    setFormData(prev => ({ ...prev, [name]: newValues }));
  };

  const isSubmitDisabled = loading || !formData.tema_materia || !formData.grado_nivel || currentAreaAplicacion.length === 0 || currentTipoHerramienta.length === 0;

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card className="glass-effect border-indigo-500/20 shadow-xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="gradient-text text-2xl">{activeService.title}</CardTitle>
              <CardDescription className="text-gray-400">Potencia tus clases con la IA.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="tema_materia" className="text-purple-300">Tema/Materia</Label>
                <Input id="tema_materia" name="tema_materia" value={formData.tema_materia || ''} onChange={handleChange} placeholder="Ej: Álgebra" className="glass-effect" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="grado_nivel" className="text-purple-300">Grado/Nivel Educativo</Label>
                <Input id="grado_nivel" name="grado_nivel" value={formData.grado_nivel || ''} onChange={handleChange} placeholder="Ej: 8vo Grado" className="glass-effect" required />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="duracion" className="text-purple-300">Duración de la Integración</Label>
              <Input id="duracion" name="duracion" value={formData.duracion || ''} onChange={handleChange} placeholder="Ej: Una actividad de 30 minutos" className="glass-effect" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="objetivo_pedagogico" className="text-purple-300">Objetivo Pedagógico Principal</Label>
              <Textarea id="objetivo_pedagogico" name="objetivo_pedagogico" value={formData.objetivo_pedagogico || ''} onChange={handleChange} placeholder="¿Qué quieres lograr con la IA en tu clase?" className="glass-effect" required />
            </div>

            <div className="space-y-3">
              <Label className="text-purple-300">Área de Aplicación de la IA</Label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-3 rounded-md bg-slate-900/50 border border-purple-500/20">
                {iaApplicationAreas.map(area => (
                  <div key={area} className="flex items-center space-x-2">
                    <Checkbox id={`area-${area}`} checked={currentAreaAplicacion.includes(area)} onCheckedChange={() => handleCheckboxChange('area_aplicacion', area)} />
                    <Label htmlFor={`area-${area}`} className="text-sm text-gray-300 cursor-pointer">{area}</Label>
                  </div>
                ))}
              </div>
              {currentAreaAplicacion.length === 0 && <p className="text-xs text-red-400 mt-1">Selecciona al menos un área.</p>}
            </div>

            <div className="space-y-3">
              <Label className="text-purple-300">Tipo de Herramienta de IA Deseada</Label>
               <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 rounded-md bg-slate-900/50 border border-purple-500/20">
                {iaToolTypes.map(tool => (
                  <div key={tool} className="flex items-center space-x-2">
                    <Checkbox id={`tool-${tool}`} checked={currentTipoHerramienta.includes(tool)} onCheckedChange={() => handleCheckboxChange('tipo_herramienta', tool)} />
                    <Label htmlFor={`tool-${tool}`} className="text-sm text-gray-300 cursor-pointer">{tool}</Label>
                  </div>
                ))}
              </div>
              {currentTipoHerramienta.length === 0 && <p className="text-xs text-red-400 mt-1">Selecciona al menos un tipo de herramienta.</p>}
            </div>

            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={isSubmitDisabled} className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-bold py-3 px-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">
                {loading ? 'Generando Plan...' : 'Generar Plan de IA'}
                <Zap className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default InteligenciaArtificialForm;