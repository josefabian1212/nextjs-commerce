import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Brain, Loader2, Activity } from 'lucide-react';
import {
  cognitiveAnalysisLevels,
  cognitiveReasoningTypes,
  cognitiveSpecificAnalysisTypes,
  cognitiveCreativityTypes,
} from '@/components/services/serviceUtils';

const CognitiveAnalysisForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const serviceIcon = activeService?.icon || Activity;
  
  const isSubmitDisabled = () => {
    if (loading) return true;
    if (!formData.tema_analizar || !formData.grado_nivel || !formData.nivel_profundidad) return true;
    const hasSelectedAnalysis = 
      (formData.tipo_razonamiento && formData.tipo_razonamiento !== "Ninguno") ||
      (formData.tipo_analisis_especifico && formData.tipo_analisis_especifico !== "Ninguno") ||
      (formData.tipo_creatividad_percepcion && formData.tipo_creatividad_percepcion !== "Ninguno");
    return !hasSelectedAnalysis;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="glass-effect border-red-500/20 shadow-xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
              {React.createElement(serviceIcon, { className: "w-6 h-6 text-white" })}
            </div>
            <div>
              <CardTitle className="gradient-text text-2xl">{activeService?.title || 'Análisis Cognitivo'}</CardTitle>
              <CardDescription className="text-gray-400">
                Explora temas complejos a través de múltiples enfoques cognitivos.
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div>
              <Label htmlFor="tema_analizar" className="text-purple-300">Tema a Analizar</Label>
              <Input
                id="tema_analizar"
                name="tema_analizar"
                value={formData.tema_analizar || ''}
                onChange={handleChange}
                placeholder="Ej. Impacto de la IA en la educación"
                className="glass-effect"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="grado_nivel" className="text-purple-300">Grado / Nivel Educativo o Contexto</Label>
                 <Input
                    id="grado_nivel"
                    name="grado_nivel"
                    value={formData.grado_nivel || ''}
                    onChange={handleChange}
                    placeholder="Ej: Universitario, 9° grado, Profesional"
                    className="glass-effect"
                    required
                />
              </div>
              <div>
                <Label htmlFor="nivel_profundidad" className="text-purple-300">Nivel de Profundidad del Análisis</Label>
                <Select name="nivel_profundidad" value={formData.nivel_profundidad || ''} onValueChange={(value) => handleSelectChange('nivel_profundidad', value)} required>
                  <SelectTrigger className="w-full glass-effect">
                    <SelectValue placeholder="Selecciona un nivel" />
                  </SelectTrigger>
                  <SelectContent className="glass-effect border-purple-500/30">
                    {cognitiveAnalysisLevels.map(option => (
                      <SelectItem key={option} value={option} className="hover:bg-purple-500/20 focus:bg-purple-500/30">{option}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-4">
              <Label className="text-purple-300">Tipos de Análisis Seleccionados (al menos uno)</Label>
              <div>
                <Label htmlFor="tipo_razonamiento" className="text-sm text-gray-400 mb-1 block">Categoría: Razonamiento</Label>
                <Select name="tipo_razonamiento" value={formData.tipo_razonamiento || 'Ninguno'} onValueChange={(value) => handleSelectChange('tipo_razonamiento', value)}>
                  <SelectTrigger className="w-full glass-effect">
                    <SelectValue placeholder="Selecciona un tipo de razonamiento" />
                  </SelectTrigger>
                  <SelectContent className="glass-effect border-purple-500/30">
                    {cognitiveReasoningTypes.map(option => (
                      <SelectItem key={option} value={option} className="hover:bg-purple-500/20 focus:bg-purple-500/30">{option}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="tipo_analisis_especifico" className="text-sm text-gray-400 mb-1 block">Categoría: Análisis Específico</Label>
                <Select name="tipo_analisis_especifico" value={formData.tipo_analisis_especifico || 'Ninguno'} onValueChange={(value) => handleSelectChange('tipo_analisis_especifico', value)}>
                  <SelectTrigger className="w-full glass-effect">
                    <SelectValue placeholder="Selecciona un análisis específico" />
                  </SelectTrigger>
                  <SelectContent className="glass-effect border-purple-500/30">
                    {cognitiveSpecificAnalysisTypes.map(option => (
                      <SelectItem key={option} value={option} className="hover:bg-purple-500/20 focus:bg-purple-500/30">{option}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="tipo_creatividad_percepcion" className="text-sm text-gray-400 mb-1 block">Categoría: Creatividad y Percepción</Label>
                <Select name="tipo_creatividad_percepcion" value={formData.tipo_creatividad_percepcion || 'Ninguno'} onValueChange={(value) => handleSelectChange('tipo_creatividad_percepcion', value)}>
                  <SelectTrigger className="w-full glass-effect">
                    <SelectValue placeholder="Selecciona creatividad o percepción" />
                  </SelectTrigger>
                  <SelectContent className="glass-effect border-purple-500/30">
                    {cognitiveCreativityTypes.map(option => (
                      <SelectItem key={option} value={option} className="hover:bg-purple-500/20 focus:bg-purple-500/30">{option}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {isSubmitDisabled() && !loading && (formData.tema_analizar && formData.grado_nivel && formData.nivel_profundidad) && (
                <p className="text-red-400 text-xs mt-1">Debes seleccionar al menos un tipo de análisis de las categorías.</p>
              )}
            </div>

            <Button 
              type="submit" 
              disabled={isSubmitDisabled()}
              className="w-full bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white font-bold py-3 px-6 rounded-lg shadow-lg transition-all duration-300 ease-in-out transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Analizando...
                </>
              ) : (
                <>
                  <Brain className="mr-2 h-5 w-5" />
                  Analizar Tema
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default CognitiveAnalysisForm;