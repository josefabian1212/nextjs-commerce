export * from './formData/contentForms';
export * from './formData/pedagogicalForms';
export * from './formData/evaluationForms';
export * from './formData/mediaForms';
export * from './formData/academicForms';
export * from './formData/businessForms';

export const initialGenerateArticleFormData = {
  tema_principal: '',
  tipo_articulo: 'Informativo',
  tono_articulo: 'Formal',
  audiencia_objetivo: 'Público general',
  longitud_aproximada: 'Corto (1000 palabras)',
};

export const articleTypes = ['Informativo', 'Opinión', 'Editorial', 'Noticias', 'Cartas a editor', 'Guía paso a paso', 'Reseña/Análisis'];
export const articleTones = ['Formal', 'Conversacional', 'Técnico', 'Amigable', 'Inspirador'];
export const articleAudiences = ['Público general', 'Profesionales', 'Académicos', 'Empresarios', 'Estudiantes'];
export const articleLengths = ['Corto (1000 palabras)', 'Medio (2000 palabras)', 'Largo (3000 palabras)', 'Muy largo (4000+ palabras)'];

export const initialGamificacionFormData = {
  tema_contenido: '',
  grado_nivel: '',
  duracion: '',
  objetivo_aprendizaje: '',
  elementos_juego: [],
  tipo_interaccion: '',
};

export const gamificationElements = [
  "Puntos",
  "Insignias/Badges",
  "Niveles",
  "Tablas de clasificación (Leaderboards)",
  "Misiones/Retos",
  "Avatares/Personalización",
  "Narrativa/Historia",
  "Recompensas/Premios",
  "Barras de progreso",
  "Desbloqueo de contenido",
];

export const gamificationInteractionTypes = [
  "Individual (auto-desafío)",
  "Cooperativa (trabajo en equipo)",
  "Competitiva (uno contra uno o equipos)",
  "Híbrida (individual y cooperativa/competitiva)",
];

export const initialInteligenciaArtificialFormData = {
  tema_materia: '',
  grado_nivel: '',
  duracion: '',
  objetivo_pedagogico: '',
  area_aplicacion: [],
  tipo_herramienta: [],
};

export const iaApplicationAreas = [
  "Generación de Contenido",
  "Personalización del Aprendizaje",
  "Evaluación y Retroalimentación",
  "Asistencia al Profesor",
  "Accesibilidad e Inclusión",
  "Interacción y Colaboración",
  "Análisis de Datos Educativos",
  "Gamificación",
];

export const iaToolTypes = [
  "Asistentes de Escritura/Parafraseo (ej., Grammarly)",
  "Generadores de Contenido/Lecciones (ej., ChatGPT, Eduaide.ai)",
  "Plataformas de Evaluación/Quizzes (ej., Kahoot!, Gradescope)",
  "Tutores Inteligentes/Adaptativos (ej., Khanmigo, Century Tech)",
  "Transcripción y Subtitulado (ej., Otter.ai)",
  "Diseño Visual/Presentaciones (ej., Canva Magic Studio)",
  "Herramientas de Investigación/Resumen (ej., Perplexity AI)",
  "Gestión del Aula/Comportamiento (ej., Classcraft)",
  "Monitoreo de Emociones/Bienestar (ej., Affectiva)",
];