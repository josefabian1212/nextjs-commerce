import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Send, Loader2, MessageSquare as MessageSquareText, PenSquare, CornerDownRight } from 'lucide-react';
import { Switch } from '@/components/ui/switch';

const pqrsTypes = ["Petición", "Queja", "Reclamo", "Sugerencia", "Felicitaciones", "Exhortación"];

const PqrsForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const [actionType, setActionType] = useState('create'); // 'create' or 'manage'

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSwitchChange = (name, checked) => {
    setFormData(prev => ({ ...prev, [name]: checked }));
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    const finalFormData = {
      ...formData,
      actionType: actionType,
    };
    onSubmit(e, finalFormData); 
  };
  
  const serviceIcon = activeService?.icon || MessageSquareText;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <Card className="bg-slate-800/70 border-cyan-500/30 shadow-xl">
        <CardHeader className="pb-4">
          <div className="flex items-center space-x-3">
             {React.createElement(serviceIcon, { className: `w-8 h-8 text-cyan-400` })}
            <CardTitle className="text-2xl font-bold text-cyan-300">{activeService?.title || 'Gestión de PQRS'}</CardTitle>
          </div>
          <CardDescription className="text-gray-400">
            Redacta o responde Peticiones, Quejas, Reclamos o Sugerencias de forma profesional.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6 flex justify-center items-center space-x-4 bg-slate-700/50 p-3 rounded-lg">
            <Button variant={actionType === 'create' ? 'default' : 'ghost'} onClick={() => setActionType('create')} className={`flex-1 transition-all duration-300 ${actionType === 'create' ? 'bg-cyan-600' : ''}`}>
              <PenSquare className="mr-2 h-4 w-4" />Redactar una PQRS
            </Button>
            <Button variant={actionType === 'manage' ? 'default' : 'ghost'} onClick={() => setActionType('manage')} className={`flex-1 transition-all duration-300 ${actionType === 'manage' ? 'bg-purple-600' : ''}`}>
              <CornerDownRight className="mr-2 h-4 w-4" />Gestionar/Responder
            </Button>
          </div>
          
          <form onSubmit={handleFormSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="fecha" className="text-gray-300 mb-1 block">
                  {actionType === 'create' ? 'Fecha de Creación' : 'Fecha de la PQRS'}
                </Label>
                <Input
                  id="fecha"
                  name="fecha"
                  type="date"
                  value={formData.fecha || ''}
                  onChange={handleChange}
                  className="bg-slate-700 border-slate-600 text-white placeholder-gray-500 focus:ring-cyan-500 focus:border-cyan-500"
                  required
                />
              </div>
              <div>
                <Label htmlFor="dirigido_a" className="text-gray-300 mb-1 block">
                  {actionType === 'create' ? '¿A Quién va Dirigida la PQRS?' : 'Entidad que Responde'}
                </Label>
                <Input
                  id="dirigido_a"
                  name="dirigido_a"
                  value={formData.dirigido_a || ''}
                  onChange={handleChange}
                  placeholder={actionType === 'create' ? "Ej. Secretaría de Educación" : "Ej. Equipo de Atención al Ciudadano"}
                  className="bg-slate-700 border-slate-600 text-white placeholder-gray-500 focus:ring-cyan-500 focus:border-cyan-500"
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="tipo_pqrs" className="text-gray-300 mb-1 block">Tipo de PQRS</Label>
              <Select name="tipo_pqrs" value={formData.tipo_pqrs || ''} onValueChange={(value) => handleSelectChange('tipo_pqrs', value)} required>
                <SelectTrigger className="w-full bg-slate-700 border-slate-600 text-white focus:ring-cyan-500 focus:border-cyan-500">
                  <SelectValue placeholder="Selecciona un tipo" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700 text-white">
                  {pqrsTypes.map(option => (
                    <SelectItem key={option} value={option} className="hover:bg-cyan-500/20 focus:bg-cyan-500/30">{option}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="detalles_pqrs" className="text-gray-300 mb-1 block">
                {actionType === 'create' ? 'Describe tu solicitud, queja o sugerencia' : 'Detalles de la PQRS a responder'}
              </Label>
              <Textarea
                id="detalles_pqrs"
                name="detalles_pqrs"
                value={formData.detalles_pqrs || ''}
                onChange={handleChange}
                placeholder="Describe el caso o situación..."
                className="bg-slate-700 border-slate-600 text-white placeholder-gray-500 focus:ring-cyan-500 focus:border-cyan-500 min-h-[120px]"
                maxLength={5000}
                required
              />
            </div>

            <div>
              <Label htmlFor="enviado_por" className="text-gray-300 mb-1 block">
                {actionType === 'create' ? 'Tu Nombre (Remitente)' : 'Nombre de quien recibió la PQRS'}
              </Label>
              <Input
                id="enviado_por"
                name="enviado_por"
                value={formData.enviado_por || ''}
                onChange={handleChange}
                placeholder="Tu nombre o el del remitente"
                className="bg-slate-700 border-slate-600 text-white placeholder-gray-500 focus:ring-cyan-500 focus:border-cyan-500"
                required
              />
            </div>

            <motion.div 
              key={actionType}
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              transition={{ duration: 0.3 }}
              className="space-y-4"
            >
              <div className="flex items-center space-x-2 pt-2">
                <Switch id="incluir_ley" name="incluir_ley" checked={formData.incluir_ley || false} onCheckedChange={(checked) => handleSwitchChange('incluir_ley', checked)} />
                <Label htmlFor="incluir_ley">¿Incluir referencia a la ley del país?</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="incluir_radicado" name="incluir_radicado" checked={formData.incluir_radicado || false} onCheckedChange={(checked) => handleSwitchChange('incluir_radicado', checked)} />
                <Label htmlFor="incluir_radicado">¿Incluir un número de radicado automático?</Label>
              </div>
            </motion.div>

            <Button 
              type="submit" 
              disabled={loading} 
              className={`w-full text-white font-semibold py-3 px-6 rounded-lg shadow-lg transition-all duration-300 ease-in-out transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center ${actionType === 'create' ? 'bg-gradient-to-r from-cyan-600 to-sky-600 hover:from-cyan-700 hover:to-sky-700' : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700'}`}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Generando...
                </>
              ) : (
                <>
                  <Send className="mr-2 h-5 w-5" />
                  {actionType === 'create' ? 'Redactar y Enviar' : 'Generar Respuesta'}
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default PqrsForm;