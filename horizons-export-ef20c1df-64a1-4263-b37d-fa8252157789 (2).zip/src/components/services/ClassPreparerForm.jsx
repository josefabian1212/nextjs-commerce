import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Zap } from 'lucide-react';

const ClassPreparerForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const formFields = [
    { name: 'tema', label: 'Tema', placeholder: 'Ej: El ciclo del agua' },
    { name: 'grado', label: 'Grado', placeholder: 'Ej: 4º de Primaria' },
    { name: 'asignatura', label: 'Asignatura', placeholder: 'Ej: Ciencias Naturales' },
    { name: 'pais', label: 'País', placeholder: 'Ej: Colombia' },
    { name: 'duracion', label: 'Duración', placeholder: 'Ej: 45 minutos' },
    { name: 'unidad', label: 'Unidad', placeholder: 'Ej: Unidad 2: Ecosistemas' },
  ];

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
      <Card className="glass-effect border-purple-500/30 shadow-lg">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center bg-gradient-to-br ${activeService.color}`}>
              <activeService.icon className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-2xl font-bold gradient-text">{activeService.title}</CardTitle>
              <CardDescription className="text-gray-400">Genera planes de clase completos y detallados al instante.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {formFields.map(field => (
                <div key={field.name} className="space-y-2">
                  <Label htmlFor={field.name} className="text-gray-300">{field.label}</Label>
                  <Input
                    id={field.name}
                    name={field.name}
                    value={formData[field.name] || ''}
                    onChange={handleChange}
                    placeholder={field.placeholder}
                    className="glass-effect-input"
                    required
                  />
                </div>
              ))}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="objetivo" className="text-gray-300">Objetivo / Estándar de Aprendizaje</Label>
              <Textarea
                id="objetivo"
                name="objetivo"
                value={formData.objetivo || ''}
                onChange={handleChange}
                placeholder="Ej: Los estudiantes podrán describir las etapas del ciclo del agua y su importancia para la vida en la Tierra."
                className="glass-effect-input"
                rows={4}
                required
              />
            </div>

            <div className="flex justify-end">
              <Button type="submit" disabled={loading} className="glow-on-hover bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold py-3 px-6 rounded-lg shadow-lg hover:scale-105 transition-transform">
                {loading ? (
                  <div className="flex items-center">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                    Generando...
                  </div>
                ) : (
                  <div className="flex items-center">
                    <Zap className="mr-2 h-5 w-5" />
                    Generar Preparador
                  </div>
                )}
              </Button>
            </div>
            <p className="text-xs text-center text-gray-500 pt-2">
              Consumirá {activeService.credits || 1} crédito por generación.
            </p>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ClassPreparerForm;