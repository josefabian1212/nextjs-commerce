import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Zap } from 'lucide-react';
import { motion } from 'framer-motion';

const difficultyLevels = ['Principiante', 'Intermedio', 'Avanzado'];
const formatOptions = [
  { id: 'multiple-formats', label: 'Múltiples formatos' },
  { id: 'structured-content', label: 'Contenido estructurado' },
  { id: 'include-images', label: 'Opción de incluir imágenes' },
];

const TutorialGeneratorForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const currentFormat = formData.format || [];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (formatId) => {
    const newFormats = (formData.format || []).includes(formatId)
      ? (formData.format || []).filter(f => f !== formatId)
      : [...(formData.format || []), formatId];
    setFormData(prev => ({ ...prev, format: newFormats }));
  };

  const isSubmitDisabled = loading || !formData.tema_tutorial || !formData.grade || !formData.objective || currentFormat.length === 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="glass-effect border-yellow-500/20 shadow-2xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
              <activeService.icon className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="text-white text-2xl">{activeService.title}</CardTitle>
              <CardDescription className="text-gray-300">Crea tutoriales educativos detallados.</CardDescription>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="tema_tutorial" className="text-white font-medium">Tema del Tutorial</Label>
              <Input id="tema_tutorial" name="tema_tutorial" placeholder="Ej: Cómo usar la fotosíntesis en proyectos escolares" value={formData.tema_tutorial || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white" required />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="grade" className="text-white font-medium">Grado</Label>
                <Input id="grade" name="grade" placeholder="Ej: 3° Primaria, Universitario" value={formData.grade || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="difficulty" className="text-white font-medium">Nivel de Dificultad</Label>
                <Select name="difficulty" value={formData.difficulty || ''} onValueChange={(value) => handleSelectChange('difficulty', value)}>
                  <SelectTrigger className="w-full glass-effect border-white/20 text-white bg-slate-800">
                    <SelectValue placeholder="Selecciona el nivel" />
                  </SelectTrigger>
                  <SelectContent className="glass-effect border-purple-500/30 text-white bg-slate-800">
                    {difficultyLevels.map(level => <SelectItem key={level} value={level}>{level}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="objective" className="text-white font-medium">Objetivo del Tutorial</Label>
              <Textarea id="objective" name="objective" placeholder="Describe qué aprenderá el usuario con este tutorial..." value={formData.objective || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white" rows={3} required />
            </div>

            <div className="space-y-2">
              <Label className="text-white font-medium">Formato Solicitado</Label>
              <div className="space-y-2 p-3 glass-effect border-white/20 rounded-md">
                {formatOptions.map(opt => (
                  <div key={opt.id} className="flex items-center space-x-2">
                    <Checkbox 
                      id={opt.id} 
                      checked={currentFormat.includes(opt.id)} 
                      onCheckedChange={() => handleCheckboxChange(opt.id)}
                      className="border-purple-400 data-[state=checked]:bg-purple-500"
                    />
                    <Label htmlFor={opt.id} className="text-gray-300 font-normal">{opt.label}</Label>
                  </div>
                ))}
              </div>
               {currentFormat.length === 0 && <p className="text-xs text-red-400 mt-1">Debes seleccionar al menos un formato.</p>}
            </div>
            
            <Button type="submit" className="w-full glow-effect bg-gradient-to-r from-yellow-500 to-amber-600 text-base py-3" disabled={isSubmitDisabled}>
              {loading ? (<> <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div> Procesando...</>) : (<> <Zap className="w-5 h-5 mr-2" />Generar Tutorial</>)}
            </Button>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default TutorialGeneratorForm;