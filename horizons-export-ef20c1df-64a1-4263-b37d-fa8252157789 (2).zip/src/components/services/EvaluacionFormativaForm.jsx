import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ClipboardCheck, Zap } from 'lucide-react';
import { evaluacionFeedbackTypes, evaluacionStrategies } from '@/components/services/serviceUtils';

const EvaluacionFormativaForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <Card className="glass-effect border-sky-500/20 shadow-xl">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
              <ClipboardCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <CardTitle className="gradient-text text-2xl">{activeService.title}</CardTitle>
              <CardDescription className="text-gray-400">Implementa estrategias de evaluación continua.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="tema_contenido" className="text-purple-300">Tema/Contenido a Evaluar</Label>
              <Input id="tema_contenido" name="tema_contenido" value={formData.tema_contenido} onChange={handleChange} placeholder="Ej: Suma de fracciones" className="glass-effect" required />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="grado_nivel" className="text-purple-300">Grado/Nivel Educativo</Label>
                <Input id="grado_nivel" name="grado_nivel" value={formData.grado_nivel} onChange={handleChange} placeholder="Ej: 4to de Primaria" className="glass-effect" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="duracion" className="text-purple-300">Duración de la Actividad</Label>
                <Input id="duracion" name="duracion" value={formData.duracion} onChange={handleChange} placeholder="Ej: 15 minutos" className="glass-effect" required />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="objetivo_aprendizaje" className="text-purple-300">Objetivo de Aprendizaje a Evaluar</Label>
              <Textarea id="objetivo_aprendizaje" name="objetivo_aprendizaje" value={formData.objetivo_aprendizaje} onChange={handleChange} placeholder="¿Qué habilidad o conocimiento específico quieres evaluar?" className="glass-effect" required />
            </div>

            <div className="space-y-2">
              <Label className="text-purple-300">Tipo de Retroalimentación Deseada</Label>
              <Select onValueChange={(value) => handleSelectChange('tipo_retroalimentacion', value)} value={formData.tipo_retroalimentacion} required>
                <SelectTrigger className="glass-effect w-full"><SelectValue placeholder="Selecciona un tipo de feedback..." /></SelectTrigger>
                <SelectContent>{evaluacionFeedbackTypes.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}</SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-purple-300">Estrategia de Evaluación Formativa</Label>
              <Select onValueChange={(value) => handleSelectChange('estrategia_evaluacion', value)} value={formData.estrategia_evaluacion} required>
                <SelectTrigger className="glass-effect w-full"><SelectValue placeholder="Selecciona una estrategia..." /></SelectTrigger>
                <SelectContent>{evaluacionStrategies.map(strategy => <SelectItem key={strategy} value={strategy}>{strategy}</SelectItem>)}</SelectContent>
              </Select>
            </div>

            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={loading} className="bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-600 hover:to-indigo-700 text-white font-bold py-3 px-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">
                {loading ? 'Generando Plan...' : 'Generar Evaluación Formativa'}
                <Zap className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default EvaluacionFormativaForm;