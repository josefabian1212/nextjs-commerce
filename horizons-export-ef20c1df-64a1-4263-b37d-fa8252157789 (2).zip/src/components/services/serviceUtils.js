export const articleTypes = ['Informativo', 'Opinión', 'Editorial', 'Noticias', 'Cartas a editor', 'Guía paso a paso', 'Reseña/Análisis'];
export const articleTones = ['Formal', 'Conversacional', 'Técnico', 'Amigable', 'Inspirador'];
export const articleAudiences = ['Público general', 'Profesionales', 'Académicos', 'Empresarios', 'Estudiantes'];
export const articleLengths = ['Corto (1000 palabras)', 'Medio (2000 palabras)', 'Largo (3000 palabras)', 'Muy largo (4000+ palabras)'];

export const gamificationElements = [
  "Puntos",
  "Insignias/Badges",
  "Niveles",
  "Tablas de clasificación (Leaderboards)",
  "Misiones/Retos",
  "Avatares/Personalización",
  "Narrativa/Historia",
  "Recompensas/Premios",
  "Barras de progreso",
  "Desbloqueo de contenido",
];

export const gamificationInteractionTypes = [
  "Individual (auto-desafío)",
  "Cooperativa (trabajo en equipo)",
  "Competitiva (uno contra uno o equipos)",
  "Híbrida (individual y cooperativa/competitiva)",
];

export const iaApplicationAreas = [
  "Generación de Contenido",
  "Personalización del Aprendizaje",
  "Evaluación y Retroalimentación",
  "Asistencia al Profesor",
  "Accesibilidad e Inclusión",
  "Interacción y Colaboración",
  "Análisis de Datos Educativos",
  "Gamificación",
];

export const iaToolTypes = [
  "Asistentes de Escritura/Parafraseo (ej., Grammarly)",
  "Generadores de Contenido/Lecciones (ej., ChatGPT, Eduaide.ai)",
  "Plataformas de Evaluación/Quizzes (ej., Kahoot!, Gradescope)",
  "Tutores Inteligentes/Adaptativos (ej., Khanmigo, Century Tech)",
  "Transcripción y Subtitulado (ej., Otter.ai)",
  "Diseño Visual/Presentaciones (ej., Canva Magic Studio)",
  "Herramientas de Investigación/Resumen (ej., Perplexity AI)",
  "Gestión del Aula/Comportamiento (ej., Classcraft)",
  "Monitoreo de Emociones/Bienestar (ej., Affectiva)",
];

export const pedagogicalWorkshopActivityTypes = [
  "Didáctica",
  "Lúdica",
  "Artística",
  "Tecnológica",
  "Colaborativa",
  "Educación Inicial",
  "Primaria",
  "Secundaria",
  "Educación Superior",
  "Adultos",
];

export const cooperativeLearningActivityTypes = [
  "Juegos cooperativos",
  "Juegos competitivos",
  "Dinámicas de integración",
  "Actividades con música",
  "Talleres creativos",
];

export const childrenCreativitySkills = [
  "Cognitivas",
  "Sociales",
  "Motoras",
  "Emocionales",
  "Creativas",
  "Lingüísticas",
  "Sensoriales",
  "Planificación y organización",
  "Autoexpresión",
];

export const neuroLearningStyles = ["Visual", "Auditivo", "Kinestésico", "Lector/Escritor"];
export const neuroFrequentEmotions = ["Alegría", "Sorpresa", "Interés/Entusiasmo", "Tristeza", "Miedo", "Ira/Enojo", "Ansiedad", "Aburrimiento", "Frustración", "Vergüenza", "Simpatía", "Rechazo", "Molestia"];
export const neuroPillars = ["Atención", "Emoción", "Memoria", "Metacognición"];

export const multipleIntelligencesActivityTypes = [
  "Lingüística (uso del lenguaje)",
  "Lógico-Matemática (razonamiento, números)",
  "Espacial (visual, imágenes, formas)",
  "Musical (ritmo, melodía, armonía)",
  "Corporal-Kinestésica (movimiento, expresión física)",
  "Interpersonal (interacción social, empatía)",
  "Intrapersonal (autoconocimiento, reflexión)",
  "Naturalista (naturaleza, entorno)",
  "Existencial (reflexión sobre la vida y el propósito)",
];

export const criticalThinkingActivityTypes = [
  "Debates estructurados (sobre temas controvertidos)",
  "Análisis de falacias lógicas en discursos públicos",
  "Resolución de dilemas éticos (casos reales o hipotéticos)",
  "Evaluación de fuentes (credibilidad, sesgos y evidencias)",
  "Comparación de perspectivas (tablas de pros y contras)",
  "Juegos de rol (simulaciones de toma de decisiones)",
  "Desmontar argumentos (identificar premisas y conclusiones)",
  "Proyectos de investigación guiada (con preguntas desafiantes)",
  "Análisis de noticias falsas vs. verificadas",
  "Creación de mapas conceptuales para problemas complejos",
  "Discusión socrática (preguntas abiertas en círculo)",
  "Refutación escrita de artículos o ensayos",
  "Tormenta de ideas con criterios de validación",
  "Análisis de datos estadísticos (interpretación y limitaciones)",
  "Simulaciones de juicios (argumentación basada en evidencias)",
];

export const evaluacionFeedbackTypes = [
  "Inmediata y Directa",
  "Detallada y Constructiva",
  "Autoevaluación Guiada",
  "Coevaluación entre Pares",
  "Cuantitativa (simple)",
  "Cualitativa (descriptiva)",
];

export const evaluacionStrategies = [
  "Boletos de salida/Entrada",
  "Preguntas rápidas/Encuestas en clase",
  "Observación estructurada",
  "Mapas mentales/Conceptuales",
  "Debates/Discusiones guiadas",
  "Portafolios de evidencias",
  "Diarios reflexivos/Bitácoras",
  "Semáforo de comprensión",
  "Piensa-Comparte-Discute",
  "La Pregunta Esencial",
  "Presentaciones/Demostraciones cortas",
];

export const poemTypes = [
  "Acróstico", "Balada", "Caligrama", "Copla", "Elegía", "Épico", "Epitafio", 
  "Haiku", "Himno", "Oda", "Quintilla cómica", "Romance", "Sátira", 
  "Sexto", "Soneto", "Verso en blanco", "Verso libre", "Villanelle"
];
export const poemTones = [
  "Formal", "Informal", "Sarcástico", "Romántico", "Triste", "Reflexivo", "Optimista"
];
export const poemExtensions = ["Corto", "Medio", "Largo"];

export const mathDifficulties = ['básica', 'intermedia', 'avanzada'];
export const mathFormats = ['opción múltiple', 'resolución paso a paso', 'problema verbal'];

export const atencionDiversidadSupportTypes = [
  "TDAH (Atención e Hiperactividad)",
  "Dislexia (Dificultad de Lectura)",
  "Discalculia (Dificultad Matemática)",
  "Disgrafía (Dificultad de Escritura)",
  "TEA (Trastorno del Espectro Autista)",
  "Altas Capacidades Intelectuales",
  "Discapacidad Auditiva",
  "Discapacidad Visual",
  "Discapacidad Motriz",
  "Dificultades de Aprendizaje Generales",
];

export const textAnalysisContexts = ["Académico", "Comercial", "Creativo", "Técnico", "Legal", "Personal"];
export const textAnalysisBasicProcessing = ["Resumen conciso (100 palabras)", "Análisis estructural", "Sinopsis narrativa (si aplica)"];
export const textAnalysisDeepAnalysis = ["Extracción de palabras clave (top 10)", "Análisis de sentimiento", "Detección de temas principales (top 3)", "Ventajas, desventajas y sugerencias", "Análisis FODA (Fortalezas, Oportunidades, Debilidades, Amenazas)"];
export const textAnalysisImprovement = ["Reescritura profesional", "Corrección de estilo y gramática", "Sugerencias de vocabulario"];
export const textAnalysisGeneration = ["Preguntas derivadas del texto", "Ideas relacionadas para expandir", "Estructuras alternativas"];

export const cognitiveAnalysisLevels = ["Descriptivo", "Crítico", "Prospectivo", "Analítico"];
export const cognitiveReasoningTypes = ["Ninguno", "Razonamiento lógico", "Razonamiento abstracto", "Razonamiento de sentido común", "Razonamiento matemático", "Razonamiento formal (IA)", "Razonamiento filosófico", "Razonamiento informático"];
export const cognitiveSpecificAnalysisTypes = ["Ninguno", "Resolución de problemas", "Análisis textual", "Análisis lingüístico", "Análisis axiológico", "Análisis etimológico", "Argumentación verbal"];
export const cognitiveCreativityTypes = ["Ninguno", "Despertar la creatividad textual", "Despertar la creatividad artística", "Despertar la creatividad filosófica"];