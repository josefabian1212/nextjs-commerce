import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, ChevronDown } from 'lucide-react';

const Accordion = ({ category, children, isOpen, onToggle }) => {
  return (
    <div>
      <motion.header
        initial={false}
        onClick={onToggle}
        className="flex items-center justify-between w-full p-2 rounded-lg cursor-pointer hover:bg-white/5 transition-colors"
      >
        <h2 className="text-sm font-semibold text-purple-300 uppercase tracking-wider">{category}</h2>
        <motion.div
            animate={{ rotate: isOpen ? 90 : 0 }}
            transition={{ duration: 0.2 }}
        >
            <ChevronRight className="w-5 h-5 text-purple-300" />
        </motion.div>
      </motion.header>
      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.section
            key="content"
            initial="collapsed"
            animate="open"
            exit="collapsed"
            variants={{
              open: { opacity: 1, height: "auto" },
              collapsed: { opacity: 0, height: 0 }
            }}
            transition={{ duration: 0.4, ease: [0.04, 0.62, 0.23, 0.98] }}
            className="overflow-hidden"
          >
            <div className="space-y-1 pl-2 pt-2">
                {children}
            </div>
          </motion.section>
        )}
      </AnimatePresence>
    </div>
  );
};

const ServiceSidebar = ({ serviceData, activeService, handleServiceSelect, isSidebarOpen, children }) => {
  const [hoveredService, setHoveredService] = useState(null);
  const [openCategory, setOpenCategory] = useState(Object.keys(serviceData)[0]);

  const toggleCategory = (category) => {
    setOpenCategory(openCategory === category ? null : category);
  };

  return (
    <motion.aside 
      initial={{ x: isSidebarOpen ? 0 : -300 }}
      animate={{ x: isSidebarOpen ? 0 : -300 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className={`fixed top-20 left-0 h-[calc(100vh-5rem)] w-72 bg-slate-900/80 backdrop-blur-md shadow-2xl z-40 border-r border-purple-500/20 p-4 flex flex-col overflow-y-auto scrollbar-hide md:sticky md:top-20 md:block transition-transform duration-300 ease-in-out ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0`}
    >
      <div className="space-y-2 flex-grow">
        {Object.entries(serviceData).map(([category, services]) => (
          <Accordion 
            key={category} 
            category={category} 
            isOpen={openCategory === category} 
            onToggle={() => toggleCategory(category)}
          >
            {services.map((service) => (
              <motion.button 
                key={service.id} 
                onClick={() => handleServiceSelect(service)} 
                onMouseEnter={() => setHoveredService(service.id)}
                onMouseLeave={() => setHoveredService(null)}
                className={`w-full text-left p-3 rounded-lg transition-all duration-200 flex items-center space-x-3 ${activeService?.id === service.id ? 'glass-effect glow-effect border-purple-500/50 bg-purple-500/20' : 'hover:bg-white/10'}`} 
                whileHover={{ scale: 1.02 }} 
                whileTap={{ scale: 0.98 }}
              >
                <div className={`w-8 h-8 bg-gradient-to-r ${service.color} rounded-md flex items-center justify-center flex-shrink-0 shadow-md`}>
                    <service.icon className="w-4 h-4 text-white" />
                </div>
                <span className={`text-white font-medium text-sm flex-grow ${service.isHighlighted ? 'highlight-title' : ''}`}>{service.title}</span>
                <AnimatePresence>
                {hoveredService === service.id && (
                    <motion.div
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                    >
                      <ChevronRight className="w-4 h-4 text-purple-400" />
                    </motion.div>
                )}
                </AnimatePresence>
              </motion.button>
            ))}
          </Accordion>
        ))}
      </div>
      {children}
    </motion.aside>
  );
};

export default ServiceSidebar;