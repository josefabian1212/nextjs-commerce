import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Newspaper } from 'lucide-react';
import { academicArticleTypes } from './serviceUtils';

const AcademicArticleForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const isSubmitDisabled = loading || !formData.tipo_articulo || !formData.tema;

  return (
    <Card className="glass-effect border-teal-500/20 shadow-2xl">
      <CardHeader>
        <div className="flex items-center space-x-4">
          <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
            <activeService.icon className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-white text-2xl">{activeService.title}</CardTitle>
            <CardDescription className="text-gray-300">Genera artículos académicos estructurados.</CardDescription>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={onSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="tipo_articulo" className="text-white font-medium">Tipo de Artículo</Label>
            <Select name="tipo_articulo" value={formData.tipo_articulo} onValueChange={(value) => handleSelectChange('tipo_articulo', value)}>
              <SelectTrigger className="w-full glass-effect border-white/20 text-white bg-slate-800">
                <SelectValue placeholder="Selecciona el tipo de artículo" />
              </SelectTrigger>
              <SelectContent className="glass-effect border-purple-500/30 text-white bg-slate-800">
                {academicArticleTypes.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="tema" className="text-white font-medium">Tema del Artículo</Label>
            <Input id="tema" name="tema" placeholder="Ej: Impacto de la IA en la educación secundaria" value={formData.tema} onChange={handleInputChange} className="glass-effect border-white/20 text-white" required />
          </div>
          
          <Button type="submit" className="w-full glow-effect bg-gradient-to-r from-teal-500 to-cyan-600 text-base py-3" disabled={isSubmitDisabled}>
            {loading ? (<> <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div> Generando Artículo...</>) : (<> <Newspaper className="w-5 h-5 mr-2" />Generar Artículo Académico</>)}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default AcademicArticleForm;