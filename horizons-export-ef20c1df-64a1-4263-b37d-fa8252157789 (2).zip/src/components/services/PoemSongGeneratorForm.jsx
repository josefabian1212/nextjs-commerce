import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Zap } from 'lucide-react';
import { poemTypes, poemTones, poemExtensions } from '@/components/services/serviceUtils';

const PoemSongGeneratorForm = ({ formData, setFormData, onSubmit, loading, activeService }) => {
  const currentType = formData.type || [];
  const currentTone = formData.tone || [];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (category, value) => {
    const currentValues = formData[category] || [];
    const newValues = currentValues.includes(value)
      ? currentValues.filter(item => item !== value)
      : [...currentValues, value];
    setFormData(prev => ({ ...prev, [category]: newValues }));
  };

  const isSubmitDisabled = loading || !formData.topic || currentType.length === 0 || currentTone.length === 0;

  return (
    <Card className="glass-effect border-rose-500/20 shadow-2xl">
      <CardHeader>
        <div className="flex items-center space-x-4">
          <div className={`w-12 h-12 bg-gradient-to-r ${activeService.color} rounded-lg flex items-center justify-center shadow-lg`}>
            <activeService.icon className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-white text-2xl">{activeService.title}</CardTitle>
            <CardDescription className="text-gray-300">Crea poemas y canciones originales con IA.</CardDescription>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={onSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="topic" className="text-white font-medium">Tema Principal</Label>
            <Input id="topic" name="topic" placeholder="Ej: La belleza de un atardecer, la amistad perdida..." value={formData.topic || ''} onChange={handleInputChange} className="glass-effect border-white/20 text-white" required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="extension" className="text-white font-medium">Extensión</Label>
            <Select value={formData.extension || 'Medio'} onValueChange={(value) => handleSelectChange('extension', value)} name="extension">
              <SelectTrigger className="w-full glass-effect border-white/20 text-white bg-slate-800">
                <SelectValue placeholder="Selecciona la extensión" />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 text-white border-purple-500/50">
                {poemExtensions.map(ext => <SelectItem key={ext} value={ext}>{ext}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label className="text-white font-medium">Tipo o Estilo Poético/Musical</Label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 p-3 glass-effect border-white/20 rounded-md max-h-48 overflow-y-auto scrollbar-thin scrollbar-thumb-purple-500 scrollbar-track-slate-700">
              {poemTypes.map(type => (
                <div key={type} className="flex items-center space-x-2">
                  <Checkbox 
                    id={`type-${type}`} 
                    checked={currentType.includes(type)} 
                    onCheckedChange={() => handleCheckboxChange('type', type)}
                    className="border-rose-400 data-[state=checked]:bg-rose-500"
                  />
                  <Label htmlFor={`type-${type}`} className="text-gray-300 font-normal text-sm">{type}</Label>
                </div>
              ))}
            </div>
            {currentType.length === 0 && <p className="text-xs text-red-400 mt-1">Selecciona al menos un tipo.</p>}
          </div>

          <div className="space-y-2">
            <Label className="text-white font-medium">Tono</Label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 p-3 glass-effect border-white/20 rounded-md">
              {poemTones.map(tone => (
                <div key={tone} className="flex items-center space-x-2">
                  <Checkbox 
                    id={`tone-${tone}`} 
                    checked={currentTone.includes(tone)} 
                    onCheckedChange={() => handleCheckboxChange('tone', tone)}
                    className="border-rose-400 data-[state=checked]:bg-rose-500"
                  />
                  <Label htmlFor={`tone-${tone}`} className="text-gray-300 font-normal text-sm">{tone}</Label>
                </div>
              ))}
            </div>
            {currentTone.length === 0 && <p className="text-xs text-red-400 mt-1">Selecciona al menos un tono.</p>}
          </div>
          
          <Button type="submit" className="w-full glow-effect bg-gradient-to-r from-rose-500 to-pink-600 text-base py-3" disabled={isSubmitDisabled}>
            {loading ? (<> <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div> Creando...</>) : (<> <Zap className="w-5 h-5 mr-2" />Generar Poema/Canción</>)}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default PoemSongGeneratorForm;