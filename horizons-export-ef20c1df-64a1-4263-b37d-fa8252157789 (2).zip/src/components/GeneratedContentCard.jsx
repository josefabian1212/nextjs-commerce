import React, { useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Copy, FileText as WordIcon, FileType2 as PdfIcon } from 'lucide-react';
import { Document, Packer, Paragraph, TextRun, HeadingLevel } from 'docx';
import { saveAs } from 'file-saver';
import html2pdf from 'html2pdf.js';

const GeneratedContentCard = ({ content, title, onDownloadComplete }) => {
  const { toast } = useToast();
  const contentRef = useRef(null);
  const downloadTriggered = useRef(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    toast({
      title: "¡Copiado!",
      description: "El contenido ha sido copiado a tu portapapeles.",
    });
  };

  const triggerDownloadComplete = () => {
    if (onDownloadComplete && !downloadTriggered.current) {
      onDownloadComplete();
      downloadTriggered.current = true;
    }
  };
  
  const generateDocxChildrenFromMarkdown = (markdownText) => {
    const children = [];
    const lines = markdownText.split('\n');

    lines.forEach(line => {
      line = line.trim();
      if (line.startsWith('### ')) {
        children.push(new Paragraph({ text: line.substring(4), heading: HeadingLevel.HEADING_3, spacing: { after: 160 }}));
      } else if (line.startsWith('## ')) {
        children.push(new Paragraph({ text: line.substring(3), heading: HeadingLevel.HEADING_2, spacing: { after: 180 }}));
      } else if (line.startsWith('# ')) {
        children.push(new Paragraph({ text: line.substring(2), heading: HeadingLevel.HEADING_1, spacing: { after: 200 }}));
      } else if (line.startsWith('**') && line.endsWith('**')) {
          children.push(new Paragraph({
              children: [new TextRun({ text: line.replace(/\*\*/g, ''), bold: true, size: 24 })],
              spacing: { before: 200, after: 100 },
          }));
      } else if (line.trim() !== '') {
          children.push(new Paragraph({
              children: [new TextRun({ text: line, size: 22 })],
              spacing: { after: 80 }
          }));
      } else {
        children.push(new Paragraph({ text: '' }));
      }
    });

    return [
        new Paragraph({
            children: [new TextRun({ text: title, bold: true, size: 32 })],
            heading: HeadingLevel.TITLE,
            spacing: { after: 240 }
        }),
        ...children
    ];
};


  const handleDownloadWord = () => {
    try {
        const docChildren = generateDocxChildrenFromMarkdown(content);

        const doc = new Document({
          creator: "Profe IA",
          title: title,
          description: `Contenido generado por IA para: ${title}`,
          sections: [{ properties: {}, children: docChildren }],
        });

        Packer.toBlob(doc).then(blob => {
          saveAs(blob, `${title.replace(/\s+/g, '_').toLowerCase()}_profe_ia.docx`);
          toast({ title: "¡Descarga completa!", description: "Tu archivo Word ha sido generado." });
          triggerDownloadComplete();
        }).catch(error => {
          console.error("Error generating DOCX:", error);
          toast({ title: "Error", description: "No se pudo generar el archivo Word.", variant: "destructive" });
        });
    } catch (error) {
        console.error("Error in handleDownloadWord:", error);
        toast({ title: "Error", description: "Ocurrió un error inesperado al generar el Word.", variant: "destructive" });
    }
  };
  
  const handleDownloadPdf = () => {
    const element = contentRef.current;
    if (!element) {
      toast({ title: "Error", description: "No hay contenido para generar el PDF.", variant: "destructive" });
      return;
    }

    const opt = {
      margin: [0.5, 0.5, 0.5, 0.5],
      filename: `${title.replace(/\s+/g, '_').toLowerCase()}_profe_ia.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true, letterRendering: true, backgroundColor: '#0f172a' },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    html2pdf().from(element).set(opt).save().then(() => {
      toast({ title: "¡Descarga completa!", description: "Tu archivo PDF ha sido generado." });
      triggerDownloadComplete();
    }).catch(err => {
      console.error("Error generating PDF:", err);
      toast({ title: "Error", description: "No se pudo generar el archivo PDF.", variant: "destructive" });
    });
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }}>
      <Card className="glass-effect mt-8 border-purple-500/20 shadow-xl">
        <CardHeader>
          <div className='flex flex-col sm:flex-row justify-between items-start sm:items-center'>
            <div className="mb-4 sm:mb-0">
              <CardTitle className="gradient-text text-2xl">{title}</CardTitle>
              <CardDescription className="text-gray-400">Tu resultado está listo. ¡Copia o descarga!</CardDescription>
            </div>
            <div className='flex flex-wrap gap-1 sm:gap-2'>
              <Button variant="ghost" size="icon" onClick={handleCopy} title="Copiar texto">
                <Copy className="h-5 w-5 text-sky-400" />
              </Button>
              <Button variant="ghost" size="icon" onClick={handleDownloadWord} title="Descargar como Word (.docx)">
                <WordIcon className="h-5 w-5 text-blue-400" />
              </Button>
              <Button variant="ghost" size="icon" onClick={handleDownloadPdf} title="Descargar como PDF">
                <PdfIcon className="h-5 w-5 text-red-400" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
           <div ref={contentRef} className="bg-slate-800/50 p-6 rounded-md prose prose-invert prose-sm sm:prose-base max-w-none prose-headings:text-purple-300 prose-strong:text-purple-300 max-h-[60vh] overflow-y-auto">
              <ReactMarkdown>{content}</ReactMarkdown>
            </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default GeneratedContentCard;