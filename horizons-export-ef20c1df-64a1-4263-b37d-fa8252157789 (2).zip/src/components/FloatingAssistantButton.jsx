import React from 'react';
import { motion } from 'framer-motion';
import { MessageSquare } from 'lucide-react';

const FloatingAssistantButton = () => {
  const assistantLink = "https://goo.su/Vai3SiV";

  return (
    <motion.a
      href={assistantLink}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-[90] w-16 h-16 bg-gradient-to-br from-sky-500 via-blue-600 to-indigo-700 rounded-full flex items-center justify-center shadow-2xl cursor-pointer"
      whileHover={{ scale: 1.1, boxShadow: "0px 0px 25px rgba(59, 130, 246, 0.7)" }}
      whileTap={{ scale: 0.95 }}
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 1 }}
      aria-label="Asistente Virtual Profe IA"
    >
      <MessageSquare className="w-8 h-8 text-white" />
    </motion.a>
  );
};

export default FloatingAssistantButton;