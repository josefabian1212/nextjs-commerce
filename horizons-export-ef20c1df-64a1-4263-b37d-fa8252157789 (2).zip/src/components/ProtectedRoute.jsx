import React, { useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';

const ProtectedRoute = ({ children, adminOnly = false, paidOnly = false }) => {
  const { user, isAdmin, profile, loading, setProfile } = useAuth();
  const location = useLocation();

  useEffect(() => {
    if (user && profile && !profile.is_onboarded && location.pathname !== '/servicios/class-preparer') {
      const updateUserOnboarded = async () => {
        const { data, error } = await supabase
          .from('profiles')
          .update({ is_onboarded: true })
          .eq('id', user.id)
          .select()
          .single();
        
        if (error) {
          console.error('Failed to update onboarding status', error);
        } else if (data) {
          console.log('User onboarded status updated.');
          setProfile(data); // Update profile in context
        }
      };
      updateUserOnboarded();
    }
  }, [user, profile, location.pathname, setProfile]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950">
        <div className="animate-spin rounded-full h-32 w-32 border-b-4 border-t-4 border-sky-500"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/" state={{ from: location, showAuthModal: true }} replace />;
  }

  if (profile && !profile.is_onboarded && location.pathname !== '/servicios/class-preparer') {
    return <Navigate to="/servicios/class-preparer" replace />;
  }

  if (adminOnly && !isAdmin) {
    toast({ title: "Acceso Denegado", description: "No tienes permisos de administrador.", variant: "destructive" });
    return <Navigate to="/dashboard" replace />;
  }

  if (paidOnly) {
    const userPlan = profile?.plan?.toLowerCase();
    if (!userPlan || userPlan === 'gratuito' || userPlan === 'free') {
      toast({
        title: "Acceso Exclusivo",
        description: "Esta función requiere un plan de pago. ¡Actualiza tu plan para acceder!",
        variant: "destructive",
      });
      return <Navigate to="/#pricing" replace />;
    }
  }

  return children;
};

export default ProtectedRoute;