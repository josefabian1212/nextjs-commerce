import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

const MercadoPagoButton = ({ product, quantity, currency, userId }) => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleCheckout = async () => {
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        throw new Error("Debes iniciar sesión para comprar.");
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/mercadopago-integration/create-preference`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.access_token}`
          },
          body: JSON.stringify({
            items: [
              {
                title: product.name,
                description: product.description,
                quantity: 1,
                unit_price: product.price,
                currency_id: currency,
              }
            ],
            external_reference: JSON.stringify({ userId, credits: quantity })
          })
        }
      );
      
      const responseData = await response.json();

      if (!response.ok) {
        throw new Error(responseData.error || 'Error al crear la preferencia de pago');
      }
      
      if (responseData.init_point) {
        window.location.href = responseData.init_point;
      } else {
        throw new Error('No se recibió el punto de inicio de pago de Mercado Pago.');
      }
      
    } catch (err) {
      console.error('Error:', err);
      toast({
        variant: "destructive",
        title: "Error en el pago",
        description: err.message,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button 
      onClick={handleCheckout} 
      disabled={loading}
      className="w-full bg-sky-500 hover:bg-sky-600 text-white font-bold"
    >
      {loading ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Procesando...
        </>
      ) : `Pagar ${product.price} ${currency} con MercadoPago`}
    </Button>
  );
};

export default MercadoPagoButton;