import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';
import { BarChart2, Download, Zap, Edit, Save, Loader2, FileText, FileType as PdfIcon, Sheet as ExcelIcon } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useTokens } from '@/contexts/TokenContext';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { saveAs } from 'file-saver';

const GradeAndResultsForm = ({ exams, selectedExamId, setSelectedExamId }) => {
  const { user } = useAuth();
  const { spendTokens } = useTokens();
  const [loading, setLoading] = useState(false);
  const [isGrading, setIsGrading] = useState(false);
  const [qualifications, setQualifications] = useState([]);
  const [editingRowId, setEditingRowId] = useState(null);
  const [editedScore, setEditedScore] = useState('');

  const fetchQualifications = async () => {
    if (selectedExamId) {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('calificaciones_ia')
          .select(`
            id,
            nota,
            observaciones,
            created_at,
            estudiantes_ia (id, nombre, identificacion)
          `)
          .eq('examen_id', selectedExamId)
          .eq('creado_por', user.id)
          .order('created_at', { ascending: false });
        
        if (error) {
          if (error.message.includes('Failed to fetch')) {
               toast({ title: "Error de Red", description: "No se pudieron cargar las calificaciones.", variant: "destructive" });
          } else {
               toast({ title: "Error", description: "No se pudieron cargar las calificaciones.", variant: "destructive" });
          }
          setQualifications([]);
        } else {
          setQualifications(data);
        }
      } catch (error) {
        toast({ title: "Error Crítico", description: "Ocurrió un error inesperado al cargar las calificaciones.", variant: "destructive" });
      } finally {
        setLoading(false);
      }
    }
  };

  useEffect(() => {
    if(selectedExamId) {
      fetchQualifications();
    } else {
      setQualifications([]);
    }
  }, [selectedExamId, user.id]);

  const handleGradeExam = async () => {
    if (!selectedExamId) {
      toast({ title: "Error", description: "Selecciona un examen para calificar.", variant: "destructive" });
      return;
    }
    if (!await spendTokens(0, `Calificar examen completo`, 'results-analysis')) return;

    setIsGrading(true);
    try {
      const { data, error } = await supabase.functions.invoke('openai-proxy', {
        body: { serviceType: 'batch-grade', examen_id: selectedExamId },
      });
      if (error) {
          if (error.message.includes('Failed to fetch')) {
              throw new Error("Error de red al calificar. Revisa tu conexión.");
          }
          throw error;
      }
      if (data.error) throw new Error(data.error);

      toast({ title: "¡Calificación Completa!", description: data.message || "Todos los exámenes escaneados han sido calificados." });
      fetchQualifications();
    } catch (error) {
      toast({ title: "Error de Calificación", description: error.message, variant: "destructive" });
    } finally {
      setIsGrading(false);
    }
  };

  const handleEdit = (qualification) => {
    setEditingRowId(qualification.id);
    setEditedScore(qualification.nota);
  };

  const handleSave = async (id) => {
    const newScore = parseFloat(editedScore);
    if (isNaN(newScore) || newScore < 0 || newScore > 100) {
      toast({ title: "Error", description: "La nota debe ser un número entre 0 y 100.", variant: "destructive" });
      return;
    }

    setLoading(true);
    const { error } = await supabase
      .from('calificaciones_ia')
      .update({ nota: newScore, observaciones: 'Nota actualizada manualmente.' })
      .eq('id', id);

    if (error) {
      toast({ title: "Error", description: "No se pudo actualizar la calificación.", variant: "destructive" });
    } else {
      toast({ title: "¡Guardado!", description: "La calificación ha sido actualizada." });
      setQualifications(prev => prev.map(q => q.id === id ? { ...q, nota: newScore, observaciones: 'Nota actualizada manualmente.' } : q));
      setEditingRowId(null);
    }
    setLoading(false);
  };

  const getExportData = () => {
    return qualifications.map(q => ({
      'Nombre Estudiante': q.estudiantes_ia?.nombre || 'N/A',
      'Identificación': q.estudiantes_ia?.identificacion || 'N/A',
      'Nota': q.nota,
      'Observaciones': q.observaciones,
      'Fecha': new Date(q.created_at).toLocaleString(),
    }));
  };

  const handleExport = (format) => {
    if (qualifications.length === 0) {
      toast({ title: "Sin datos", description: "No hay calificaciones para exportar.", variant: "destructive" });
      return;
    }
    const dataToExport = getExportData();
    const examName = exams.find(e => e.id === selectedExamId)?.nombre || 'examen';
    const fileName = `calificaciones_${examName.replace(/\s+/g, '_')}`;

    if (format === 'excel') {
      const worksheet = XLSX.utils.json_to_sheet(dataToExport);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Calificaciones");
      XLSX.writeFile(workbook, `${fileName}.xlsx`);
    } else if (format === 'csv') {
      const worksheet = XLSX.utils.json_to_sheet(dataToExport);
      const csvOutput = XLSX.utils.sheet_to_csv(worksheet);
      const blob = new Blob([csvOutput], { type: 'text/csv;charset=utf-8;' });
      saveAs(blob, `${fileName}.csv`);
    } else if (format === 'pdf') {
      const doc = new jsPDF();
      doc.text(`Calificaciones - ${examName}`, 14, 16);
      doc.autoTable({
        head: [['Nombre', 'ID', 'Nota', 'Observaciones', 'Fecha']],
        body: dataToExport.map(item => Object.values(item)),
      });
      doc.save(`${fileName}.pdf`);
    }
    toast({ title: "¡Exportación Exitosa!", description: `Se ha generado el archivo ${format.toUpperCase()}.` });
  };

  return (
    <Card className="glass-effect glow-effect w-full max-w-5xl mx-auto">
      <CardHeader>
        <CardTitle className="text-white flex items-center"><BarChart2 className="w-6 h-6 mr-3 text-purple-400" />Paso 5: Calificar y Ver Resultados</CardTitle>
        <CardDescription className="text-gray-300">Califica todos los exámenes escaneados, edita notas y exporta los resultados finales.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="examen-resultados" className="text-white">Examen</Label>
            <Select value={selectedExamId} onValueChange={setSelectedExamId}>
              <SelectTrigger id="examen-resultados" className="glass-effect"><SelectValue placeholder="Elige un examen..." /></SelectTrigger>
              <SelectContent className="glass-effect">
                {exams.map(exam => <SelectItem key={exam.id} value={exam.id}>{exam.nombre}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleGradeExam} className="w-full bg-gradient-to-r from-purple-500 to-indigo-600" disabled={isGrading || !selectedExamId}>
            {isGrading ? <Loader2 className="animate-spin mr-2" /> : <Zap className="w-4 h-4 mr-2" />}
            Calificar Examen
          </Button>
        </div>

        <div className="flex justify-end gap-2">
          <Button onClick={() => handleExport('csv')} variant="outline" className="text-cyan-300 border-cyan-400 hover:bg-cyan-500/20 hover:text-white" disabled={qualifications.length === 0}><FileText className="w-4 h-4 mr-2" />CSV</Button>
          <Button onClick={() => handleExport('excel')} variant="outline" className="text-green-300 border-green-400 hover:bg-green-500/20 hover:text-white" disabled={qualifications.length === 0}><ExcelIcon className="w-4 h-4 mr-2" />Excel</Button>
          <Button onClick={() => handleExport('pdf')} variant="outline" className="text-red-300 border-red-400 hover:bg-red-500/20 hover:text-white" disabled={qualifications.length === 0}><PdfIcon className="w-4 h-4 mr-2" />PDF</Button>
        </div>

        <div className="border border-white/10 rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent border-b-white/20">
                <TableHead className="text-white">Estudiante</TableHead>
                <TableHead className="text-white text-center">Nota</TableHead>
                <TableHead className="text-white">Observaciones</TableHead>
                <TableHead className="text-white text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={4} className="text-center text-gray-400 py-8"><Loader2 className="mx-auto animate-spin" /></TableCell></TableRow>
              ) : qualifications.length > 0 ? (
                qualifications.map((q) => (
                  <TableRow key={q.id} className="border-white/10">
                    <TableCell className="font-medium text-white">{q.estudiantes_ia?.nombre || 'N/A'}</TableCell>
                    <TableCell className="text-center">
                      {editingRowId === q.id ? (
                        <Input type="number" value={editedScore} onChange={(e) => setEditedScore(e.target.value)} className="w-20 mx-auto text-center glass-effect" />
                      ) : (
                        <span className={`font-bold text-lg ${q.nota >= 60 ? 'text-green-400' : 'text-red-400'}`}>{q.nota}</span>
                      )}
                    </TableCell>
                    <TableCell className="text-gray-400 text-xs max-w-xs truncate">{q.observaciones}</TableCell>
                    <TableCell className="text-right">
                      {editingRowId === q.id ? (
                        <Button size="sm" onClick={() => handleSave(q.id)} disabled={loading}><Save className="w-4 h-4 mr-2" />Guardar</Button>
                      ) : (
                        <Button variant="ghost" size="sm" onClick={() => handleEdit(q)}><Edit className="w-4 h-4 mr-2" />Editar</Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow><TableCell colSpan={4} className="text-center text-gray-400 py-8">No hay calificaciones para mostrar. Escanea y califica exámenes primero.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default GradeAndResultsForm;