import React, { useState } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
    import { useTokens } from '@/contexts/TokenContext';
    import { toast } from '@/components/ui/use-toast';
    import { FileText, Zap } from 'lucide-react';
    import GeneratedContentCard from '@/components/GeneratedContentCard';
    import { useAuth } from '@/contexts/AuthContext';
    import { supabase } from '@/lib/supabase';

    const CreateExamIAForm = ({ onExamCreated }) => {
      const { user } = useAuth();
      const { tokens, spendTokens } = useTokens();
      const [loading, setLoading] = useState(false);
      const [generatedContent, setGeneratedContent] = useState('');
      const [formData, setFormData] = useState({
        nombre_examen: '',
        asignatura: '',
        grado: '',
        num_preguntas: 10,
        dificultad: 'Medio',
        tipo_pregunta: 'Mixto',
        tema_especifico: '',
        contenido_base: '',
      });

      const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
      };

      const handleSelectChange = (name, value) => {
        setFormData(prev => ({ ...prev, [name]: value }));
      };

      const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!user) {
          toast({ title: "Error", description: "Debes iniciar sesión.", variant: "destructive" });
          return;
        }

        setLoading(true);
        setGeneratedContent('');

        try {
          const creditCheck = await spendTokens(1, `Generar examen: ${formData.nombre_examen}`, 'exam-generator-ia');
          if (!creditCheck) {
            setLoading(false);
            return;
          }

          const { data, error } = await supabase.functions.invoke('generar-examen-ia-v2', {
            body: { formData: { ...formData, userId: user.id } },
          });

          if (error) throw error;
          if (data.error) throw new Error(data.error);

          const { content, dbRecord } = data;

          setGeneratedContent(content);

          if (onExamCreated) {
            onExamCreated(dbRecord);
          }

          toast({
            title: "¡Examen generado con éxito!",
            description: "Tu examen está listo para ser usado.",
          });

        } catch (error) {
          console.error("Error generando examen:", error);
          toast({
            title: "Error al generar examen",
            description: error.message || "No se pudo conectar con el servicio de IA.",
            variant: "destructive",
          });
        } finally {
          setLoading(false);
        }
      };

      return (
        <>
          <Card className="glass-effect glow-effect w-full max-w-3xl mx-auto">
            <CardHeader>
              <CardTitle className="text-white flex items-center"><FileText className="w-6 h-6 mr-3 text-sky-400" />Paso 1: Crear Examen con IA</CardTitle>
              <CardDescription className="text-gray-300">Define los parámetros y genera un examen completo al instante. Puedes copiarlo, descargarlo y usarlo de forma independiente.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nombre_examen" className="text-white">Nombre del Examen</Label>
                    <Input id="nombre_examen" name="nombre_examen" placeholder="Ej. Parcial 1 de Biología" value={formData.nombre_examen} onChange={handleInputChange} className="glass-effect" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="asignatura" className="text-white">Asignatura</Label>
                    <Input id="asignatura" name="asignatura" placeholder="Ej. Biología" value={formData.asignatura} onChange={handleInputChange} className="glass-effect" required />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="grado" className="text-white">Nivel/Grado</Label>
                    <Input id="grado" name="grado" placeholder="Ej. 9º Grado" value={formData.grado} onChange={handleInputChange} className="glass-effect" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="num_preguntas" className="text-white">Nº de Preguntas</Label>
                    <Input id="num_preguntas" name="num_preguntas" type="number" value={formData.num_preguntas} onChange={handleInputChange} className="glass-effect" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dificultad" className="text-white">Dificultad</Label>
                    <Select name="dificultad" value={formData.dificultad} onValueChange={(v) => handleSelectChange('dificultad', v)}>
                      <SelectTrigger className="glass-effect"><SelectValue /></SelectTrigger>
                      <SelectContent className="glass-effect"><SelectItem value="Básico">Básico</SelectItem><SelectItem value="Medio">Medio</SelectItem><SelectItem value="Avanzado">Avanzado</SelectItem></SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tipo_pregunta" className="text-white">Tipo de Pregunta Principal</Label>
                  <Select name="tipo_pregunta" value={formData.tipo_pregunta} onValueChange={(v) => handleSelectChange('tipo_pregunta', v)}>
                    <SelectTrigger className="glass-effect"><SelectValue /></SelectTrigger>
                    <SelectContent className="glass-effect">
                      <SelectItem value="Opción múltiple">Opción Múltiple</SelectItem>
                      <SelectItem value="Falso / Verdadero">Falso / Verdadero</SelectItem>
                      <SelectItem value="Respuesta abierta">Respuesta Abierta</SelectItem>
                      <SelectItem value="Mixto">Mixto</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tema_especifico" className="text-white">Tema Específico (Opcional)</Label>
                  <Input id="tema_especifico" name="tema_especifico" placeholder="Ej. La Célula y sus Partes" value={formData.tema_especifico} onChange={handleInputChange} className="glass-effect" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contenido_base" className="text-white">Contenido Base (Opcional)</Label>
                  <Textarea id="contenido_base" name="contenido_base" placeholder="Pega aquí un texto o resumen para que la IA base el examen en él..." value={formData.contenido_base} onChange={handleInputChange} className="glass-effect" rows={4} />
                </div>
                <Button type="submit" className="w-full glow-effect bg-gradient-to-r from-sky-500 to-blue-600" disabled={loading || tokens < 1}>
                  {loading ? (<><div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>Generando Examen...</>) : <><Zap className="w-4 h-4 mr-2" />Generar Examen (1 Crédito)</>}
                </Button>
                {tokens < 1 && !loading && <p className="text-red-400 text-sm text-center">Créditos insuficientes.</p>}
              </form>
            </CardContent>
          </Card>
          {generatedContent && (
            <div className="mt-8">
              <GeneratedContentCard 
                title={formData.nombre_examen || "Examen Generado"} 
                content={generatedContent}
              />
            </div>
          )}
        </>
      );
    };

    export default CreateExamIAForm;