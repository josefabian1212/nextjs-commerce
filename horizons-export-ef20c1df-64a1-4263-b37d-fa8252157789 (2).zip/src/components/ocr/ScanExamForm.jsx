import React, { useState, useEffect, useRef, useCallback } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
    import { Textarea } from '@/components/ui/textarea';
    import { Progress } from '@/components/ui/progress';
    import { useTokens } from '@/contexts/TokenContext';
    import { toast } from '@/components/ui/use-toast';
    import { ScanLine, Upload, Loader2, CheckCircle, XCircle, FileText as WordIcon, FileType as PdfIcon, Sheet as ExcelIcon, FileText, Save } from 'lucide-react';
    import { supabase } from '@/lib/supabase';
    import { useAuth } from '@/contexts/AuthContext';
    import { createWorker } from 'tesseract.js';
    import { Document, Packer, Paragraph, Table, TableRow, TableCell, WidthType, AlignmentType } from 'docx';
    import { saveAs } from 'file-saver';
    import jsPDF from 'jspdf';
    import 'jspdf-autotable';
    import * as XLSX from 'xlsx';
    
    const ScanExamForm = ({ exams, selectedExamId, setSelectedExamId }) => {
      const { user } = useAuth();
      const { spendTokens } = useTokens();
      const [students, setStudents] = useState([]);
      const [selectedStudentId, setSelectedStudentId] = useState('');
      const [examFile, setExamFile] = useState(null);
      const [fileName, setFileName] = useState('');
      const fileInputRef = useRef(null);
    
      const [ocrProgress, setOcrProgress] = useState(0);
      const [isOcrRunning, setIsOcrRunning] = useState(false);
      const [extractedText, setExtractedText] = useState('');
    
      const [gradeResult, setGradeResult] = useState(null);
      const [isGrading, setIsGrading] = useState(false);
      const [editableAnswers, setEditableAnswers] = useState({});
    
      const resetStateForNewSelection = useCallback(() => {
        setStudents([]);
        setSelectedStudentId('');
        setExamFile(null);
        setFileName('');
        setExtractedText('');
        setOcrProgress(0);
        setGradeResult(null);
        setEditableAnswers({});
      }, []);
    
      const fetchStudents = useCallback(async () => {
        if (selectedExamId) {
          const { data, error } = await supabase.from('estudiantes_ia').select('id, nombre').eq('examen_id', selectedExamId).eq('creado_por', user.id);
          if (error) {
            toast({ title: "Error", description: "No se pudieron cargar los estudiantes.", variant: "destructive" });
            setStudents([]);
          } else {
            setStudents(data);
          }
        }
      }, [selectedExamId, user.id]);
    
      useEffect(() => {
        resetStateForNewSelection();
        if (selectedExamId) {
          fetchStudents();
        }
      }, [selectedExamId, resetStateForNewSelection, fetchStudents]);
    
      const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
          setExamFile(file);
          setFileName(file.name);
          setExtractedText('');
          setOcrProgress(0);
          setGradeResult(null);
          handleOcrScan(file);
        }
      };
    
      const handleOcrScan = async (fileToScan) => {
        if (!fileToScan) return;
        setIsOcrRunning(true);
        setOcrProgress(0);
        setExtractedText('');
    
        const worker = await createWorker({ logger: m => {
            if (m.status === 'recognizing text') setOcrProgress(Math.round(m.progress * 100));
        }});
        await worker.loadLanguage('spa');
        await worker.initialize('spa');
        const { data: { text } } = await worker.recognize(fileToScan);
        await worker.terminate();
        
        setExtractedText(text);
        setIsOcrRunning(false);
        toast({ title: "OCR Completado", description: "El texto ha sido extraído. Revisa y califica." });
      };
      
      const handleGrade = async (isRecalculation = false) => {
        const description = isRecalculation ? 'Recalcular nota' : 'Escanear y calificar examen';
        
        if (!selectedExamId || !selectedStudentId) {
            toast({ title: "Error", description: "Selecciona un examen y un estudiante.", variant: "destructive" });
            return;
        }
        if (!isRecalculation && !extractedText) {
            toast({ title: "Error", description: "No hay texto extraído para calificar.", variant: "destructive" });
            return;
        }
        if (isRecalculation && !Object.keys(editableAnswers).length) {
            toast({ title: "Error", description: "No hay respuestas editadas para recalcular.", variant: "destructive" });
            return;
        }
    
        if (!await spendTokens(0, description, 'scan-exam')) return;
    
        setIsGrading(true);
        try {
            const body = { serviceType: 'scan-and-grade', examen_id: selectedExamId, estudiante_id: selectedStudentId };
            if (isRecalculation) {
                body.respuestas_json = editableAnswers;
            } else {
                body.text = extractedText;
            }
    
            const { data, error } = await supabase.functions.invoke('openai-proxy', { body });
            if (error) throw error;
            if (data.error) throw new Error(data.error);
            
            setGradeResult(data);
            setEditableAnswers(data.respuestas_estudiante || {});
            toast({ title: "¡Calificación Exitosa!", description: data.observaciones });
    
        } catch (error) {
            toast({ title: "Error al Calificar", description: error.message, variant: "destructive" });
        } finally {
            setIsGrading(false);
        }
      };
    
      const handleAnswerChange = (question, value) => {
        setEditableAnswers(prev => ({ ...prev, [question]: value }));
      };
    
      const getExportData = () => {
        if (!gradeResult) return null;
        const studentName = students.find(s => s.id === selectedStudentId)?.nombre || "N/A";
        const examName = exams.find(e => e.id === selectedExamId)?.nombre || "N/A";
    
        const title = `Resultados de ${studentName} - ${examName}`;
        const head = [["Pregunta", "Tu Respuesta", "Respuesta Correcta", "Resultado"]];
        const body = Object.entries(gradeResult.comparison).map(([pregunta, details]) => [
          pregunta,
          details.estudiante,
          details.correcta,
          details.esCorrecta ? "Correcto" : "Incorrecto"
        ]);
        const summary = `\n\nResumen:\nNota Final: ${gradeResult.nota}/100\n${gradeResult.observaciones}`;
    
        return { studentName, examName, title, head, body, summary, gradeResult };
      };
    
      const handleExport = (format) => {
        const data = getExportData();
        if (!data) return;
        const { title, head, body, summary, examName, studentName, gradeResult } = data;
        const fileName = `resultados_${examName.replace(/ /g, '_')}_${studentName.replace(/ /g, '_')}`.toLowerCase();
        
        if (format === 'txt') {
            const textContent = `${title}\n\n${head[0].join("\t")}\n${body.map(row => row.join("\t")).join("\n")}${summary}`;
            const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
            saveAs(blob, `${fileName}.txt`);
        } else if (format === 'pdf') {
            const doc = new jsPDF();
            doc.setFontSize(16);
            doc.text(title, 14, 22);
            doc.autoTable({ head, body, startY: 30 });
            const finalY = doc.autoTable.previous.finalY;
            doc.setFontSize(10);
            doc.text(summary.trim(), 14, finalY + 10);
            doc.save(`${fileName}.pdf`);
        } else if (format === 'excel') {
            const worksheet = XLSX.utils.aoa_to_sheet([...head, ...body, [], ["Nota Final", gradeResult.nota], ["Observaciones", gradeResult.observaciones]]);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Resultados");
            XLSX.writeFile(workbook, `${fileName}.xlsx`);
        } else if (format === 'word') {
            const tableRows = [
                new TableRow({ children: head[0].map(cell => new TableCell({ children: [new Paragraph({ text: cell, style: "strong" })], width: { size: 25, type: WidthType.PERCENT } })) }),
                ...body.map(row => new TableRow({ children: row.map(cell => new TableCell({ children: [new Paragraph(String(cell))] })) })),
            ];
            const doc = new Document({
                creator: "Profe IA",
                title,
                styles: { paragraphStyles: [{ id: "strong", name: "Strong", run: { bold: true } }] },
                sections: [{
                    children: [
                        new Paragraph({ text: title, heading: "Title", alignment: AlignmentType.CENTER }),
                        new Table({ rows: tableRows, width: { size: 100, type: WidthType.PERCENT } }),
                        new Paragraph({ text: `Nota Final: ${gradeResult.nota}/100`, style: "strong", spacing: { before: 200 } }),
                        new Paragraph({ text: gradeResult.observaciones, spacing: { before: 100 } }),
                    ]
                }]
            });
            Packer.toBlob(doc).then(blob => saveAs(blob, `${fileName}.docx`));
        }
        toast({title: "¡Exportación Exitosa!", description: `Se ha generado el archivo ${format.toUpperCase()}.`});
      };
    
      return (
        <Card className="glass-effect glow-effect w-full max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle className="text-white flex items-center"><ScanLine className="w-6 h-6 mr-3 text-pink-400" />Paso 4: Escanear y Calificar</CardTitle>
            <CardDescription className="text-gray-300">Sube la foto del examen de un estudiante, califícalo con IA y obtén resultados al instante.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2"><Label htmlFor="examen" className="text-white">Examen</Label><Select value={selectedExamId} onValueChange={setSelectedExamId}><SelectTrigger><SelectValue placeholder="Elige un examen..." /></SelectTrigger><SelectContent>{exams.map(exam => <SelectItem key={exam.id} value={exam.id}>{exam.nombre}</SelectItem>)}</SelectContent></Select></div>
              <div className="space-y-2"><Label htmlFor="estudiante" className="text-white">Estudiante</Label><Select value={selectedStudentId} onValueChange={setSelectedStudentId} disabled={!selectedExamId || !students.length}><SelectTrigger><SelectValue placeholder={!selectedExamId ? "Primero selecciona un examen" : (students.length === 0 ? "No hay estudiantes" : "Elige un estudiante...")} /></SelectTrigger><SelectContent>{students.map(student => <SelectItem key={student.id} value={student.id}>{student.nombre}</SelectItem>)}</SelectContent></Select></div>
            </div>
    
            <div className="border-2 border-dashed border-white/20 rounded-lg p-6 text-center cursor-pointer hover:border-pink-400/50 transition-colors" onClick={() => fileInputRef.current?.click()}>
              <Upload className="w-10 h-10 text-gray-400 mx-auto mb-3" />
              <Label htmlFor="scan-file-input" className="text-white"><span className="text-lg font-medium">Capturar o Subir Examen</span><p className="text-gray-400 text-sm mt-1">{fileName || "Usa la cámara de tu móvil o sube una imagen"}</p></Label>
              <Input id="scan-file-input" ref={fileInputRef} type="file" accept="image/*" capture="environment" onChange={handleFileChange} className="hidden" />
            </div>
    
            {(isOcrRunning || ocrProgress > 0) && <Progress value={ocrProgress} className="w-full" />}
            
            {extractedText && !gradeResult && (
              <div className="space-y-4">
                  <Label className="text-white">Texto Extraído</Label>
                  <Textarea value={extractedText} onChange={(e) => setExtractedText(e.target.value)} rows={6} className="glass-effect font-mono text-xs" />
                  <Button onClick={() => handleGrade(false)} className="w-full bg-gradient-to-r from-pink-500 to-rose-600" disabled={isGrading}>
                      {isGrading ? <Loader2 className="animate-spin mr-2" /> : <CheckCircle className="mr-2" />}
                      Calificar con IA
                  </Button>
              </div>
            )}
    
            {isGrading && !gradeResult && <div className="text-center text-pink-300 flex items-center justify-center"><Loader2 className="animate-spin mr-2" />Calificando, por favor espera...</div>}
    
            {gradeResult && (
              <Card className="bg-slate-900/50 border-pink-500/30">
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle className="gradient-text">Resultado de Calificación</CardTitle>
                      <CardDescription>Nota: <span className={`font-bold text-2xl ${gradeResult.nota >= 60 ? 'text-green-400' : 'text-red-400'}`}>{gradeResult.nota}/100</span></CardDescription>
                    </div>
                    <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" onClick={() => handleExport('txt')} title="Exportar TXT"><FileText className="h-5 w-5"/></Button>
                        <Button variant="ghost" size="icon" onClick={() => handleExport('word')} title="Exportar Word"><WordIcon className="h-5 w-5 text-blue-400"/></Button>
                        <Button variant="ghost" size="icon" onClick={() => handleExport('pdf')} title="Exportar PDF"><PdfIcon className="h-5 w-5 text-red-400"/></Button>
                        <Button variant="ghost" size="icon" onClick={() => handleExport('excel')} title="Exportar Excel"><ExcelIcon className="h-5 w-5 text-emerald-400"/></Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="max-h-96 overflow-y-auto pr-2 space-y-3">
                  {Object.entries(gradeResult.comparison).map(([pregunta, details]) => (
                    <div key={pregunta} className="p-3 rounded-lg bg-slate-800/60">
                      <div className="flex justify-between items-center">
                        <p className="font-bold text-white">Pregunta {pregunta}</p>
                        {details.esCorrecta ? <CheckCircle className="text-green-500" /> : <XCircle className="text-red-500" />}
                      </div>
                      <p className="text-xs text-gray-400 mt-1">Respuesta Correcta: <span className="font-semibold text-gray-300">{details.correcta}</span></p>
                      <div className="flex items-center gap-2 mt-2">
                        <Label htmlFor={`ans-${pregunta}`} className="text-sm text-gray-400 whitespace-nowrap">Tu Respuesta:</Label>
                        <Input id={`ans-${pregunta}`} value={editableAnswers[pregunta] || ''} onChange={(e) => handleAnswerChange(pregunta, e.target.value)} className="glass-effect text-sm h-8" />
                      </div>
                    </div>
                  ))}
                  </div>
                  <Button onClick={() => handleGrade(true)} className="w-full" variant="secondary" disabled={isGrading}>
                    {isGrading ? <Loader2 className="animate-spin mr-2" /> : <Save className="mr-2" />}
                    Recalcular y Guardar Nota
                  </Button>
                </CardContent>
              </Card>
            )}
    
          </CardContent>
        </Card>
      );
    };
    
    export default ScanExamForm;