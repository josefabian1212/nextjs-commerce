import React, { useState } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { PlusCircle, Loader2 } from 'lucide-react';
    import { supabase } from '@/lib/supabase';
    import { useAuth } from '@/contexts/AuthContext';
    import { toast } from '@/components/ui/use-toast';
    
    const ManualStudentForm = ({ selectedExamId, onStudentAdded }) => {
      const { user } = useAuth();
      const [loading, setLoading] = useState(false);
      const [newStudent, setNewStudent] = useState({ nombre: '', identificacion: '', correo: '' });
    
      const handleManualAddStudent = async (e) => {
        e.preventDefault();
        if (!selectedExamId || !newStudent.nombre) {
          toast({ title: "Error", description: "Selecciona un examen e ingresa al menos el nombre del estudiante.", variant: "destructive" });
          return;
        }
    
        setLoading(true);
        try {
          const { error } = await supabase
            .from('estudiantes_ia')
            .insert({
              ...newStudent,
              examen_id: selectedExamId,
              creado_por: user.id
            });
    
          if (error) throw error;
    
          onStudentAdded();
          setNewStudent({ nombre: '', identificacion: '', correo: '' });
          toast({ title: "Estudiante Agregado", description: "El estudiante ha sido añadido a la lista." });
        } catch (error) {
          toast({ title: "Error", description: error.message, variant: "destructive" });
        } finally {
          setLoading(false);
        }
      };
    
      return (
        <form onSubmit={handleManualAddStudent} className="flex flex-col md:flex-row items-end gap-4 mb-6">
          <div className="flex-grow w-full">
            <Label htmlFor="nombre" className="text-white">Nombre Completo</Label>
            <Input id="nombre" value={newStudent.nombre} onChange={(e) => setNewStudent({ ...newStudent, nombre: e.target.value })} placeholder="Nombre del estudiante" className="glass-effect" required />
          </div>
          <div className="flex-grow w-full">
            <Label htmlFor="identificacion" className="text-white">Identificación (Opcional)</Label>
            <Input id="identificacion" value={newStudent.identificacion} onChange={(e) => setNewStudent({ ...newStudent, identificacion: e.target.value })} placeholder="ID o Cédula" className="glass-effect" />
          </div>
          <div className="flex-grow w-full">
            <Label htmlFor="correo" className="text-white">Correo (Opcional)</Label>
            <Input type="email" id="correo" value={newStudent.correo} onChange={(e) => setNewStudent({ ...newStudent, correo: e.target.value })} placeholder="Email" className="glass-effect" />
          </div>
          <Button type="submit" className="w-full md:w-auto bg-gradient-to-r from-cyan-500 to-blue-600" disabled={loading || !selectedExamId}>
            {loading ? <Loader2 className="animate-spin" /> : <PlusCircle className="w-4 h-4 mr-2" />} Añadir
          </Button>
        </form>
      );
    };
    
    export default ManualStudentForm;