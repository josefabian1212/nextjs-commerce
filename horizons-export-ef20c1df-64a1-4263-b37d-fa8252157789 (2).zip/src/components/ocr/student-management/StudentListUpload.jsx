import React, { useState, useRef } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Progress } from '@/components/ui/progress';
    import { toast } from '@/components/ui/use-toast';
    import { Upload, Save, Loader2, Mic } from 'lucide-react';
    import { supabase } from '@/lib/supabase';
    import { useAuth } from '@/contexts/AuthContext';
    import { parseStudentFile } from '@/lib/fileParser';
    import { createWorker } from 'tesseract.js';
    
    const StudentListUpload = ({ selectedExamId, onListSaved }) => {
      const { user } = useAuth();
      const [loading, setLoading] = useState(false);
      const [fileName, setFileName] = useState('');
      const [extractedStudents, setExtractedStudents] = useState([]);
      const [processingProgress, setProcessingProgress] = useState(0);
      const [isProcessing, setIsProcessing] = useState(false);
      const [isRecording, setIsRecording] = useState(false);
      const recognitionRef = useRef(null);
    
      const handleOcrScan = async (file) => {
        const worker = await createWorker({
          logger: m => {
            if (m.status === 'recognizing text') {
              setProcessingProgress(Math.round(m.progress * 100));
            }
          },
        });
        await worker.loadLanguage('spa');
        await worker.initialize('spa');
        const { data: { text } } = await worker.recognize(file);
        await worker.terminate();
        setProcessingProgress(100);
        return text;
      };
    
      const processStudentListText = (text) => {
        const studentData = text
          .split('\n')
          .map(line => line.trim())
          .filter(line => line)
          .map(line => {
            const parts = line.split(/[,;\t|]/).map(p => p.trim());
            return {
              nombre: parts[0] || '',
              identificacion: parts[1] || '',
              correo: parts[2] || ''
            };
          }).filter(s => s.nombre).slice(0, 50);
    
        setExtractedStudents(studentData);
        toast({ title: "Lista Procesada", description: `Se encontraron ${studentData.length} estudiantes. Revisa y guarda.` });
      };
    
      const handleFileChange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
    
        setFileName(file.name);
        setExtractedStudents([]);
        setProcessingProgress(0);
        setIsProcessing(true);
    
        try {
          let parsedContent = await parseStudentFile(file);
          if (parsedContent.useOcr) {
            toast({ title: "Procesando Imagen...", description: "Extrayendo texto con OCR, esto puede tardar." });
            parsedContent = await handleOcrScan(parsedContent.file);
          }
          processStudentListText(parsedContent);
        } catch (error) {
          toast({ title: "Error de Procesamiento", description: error.message, variant: "destructive" });
        } finally {
          setIsProcessing(false);
          setProcessingProgress(100);
        }
      };
    
      const handleSaveFromList = async () => {
        if (extractedStudents.length === 0 || !selectedExamId) {
          toast({ title: "Error", description: "No hay estudiantes para guardar o no se ha seleccionado un examen.", variant: "destructive" });
          return;
        }
    
        setLoading(true);
        try {
          const studentsToInsert = extractedStudents
            .filter(s => s.nombre)
            .map(s => ({
              examen_id: selectedExamId,
              creado_por: user.id,
              nombre: s.nombre,
              identificacion: s.identificacion || null,
              correo: s.correo || null,
            }));
    
          const { error } = await supabase.from('estudiantes_ia').insert(studentsToInsert);
          if (error) throw error;
    
          toast({ title: "¡Éxito!", description: "Lista de estudiantes guardada correctamente." });
          setExtractedStudents([]);
          setFileName('');
          setProcessingProgress(0);
          onListSaved();
        } catch (error) {
          toast({ title: "Error al Guardar", description: error.message || "No se pudo guardar la lista.", variant: "destructive" });
        } finally {
          setLoading(false);
        }
      };
    
      const handleExtractedStudentChange = (index, field, value) => {
        const newExtractedStudents = [...extractedStudents];
        newExtractedStudents[index][field] = value;
        setExtractedStudents(newExtractedStudents);
      };
    
      const toggleRecording = () => {
        if (isRecording) {
          recognitionRef.current?.stop();
          setIsRecording(false);
        } else {
          const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
          if (!SpeechRecognition) {
            toast({ title: "Navegador no compatible", description: "Tu navegador no soporta el reconocimiento de voz.", variant: "destructive" });
            return;
          }
    
          recognitionRef.current = new SpeechRecognition();
          recognitionRef.current.lang = 'es-ES';
          recognitionRef.current.continuous = true;
          recognitionRef.current.interimResults = false;
    
          recognitionRef.current.onstart = () => setIsRecording(true);
          recognitionRef.current.onend = () => setIsRecording(false);
          recognitionRef.current.onerror = (event) => {
            console.error("Speech recognition error", event.error);
            toast({ title: "Error de Voz", description: "Ocurrió un error con el reconocimiento de voz.", variant: "destructive" });
            setIsRecording(false);
          };
          recognitionRef.current.onresult = (event) => {
            let transcript = '';
            for (let i = event.resultIndex; i < event.results.length; ++i) {
              transcript += event.results[i][0].transcript + '\n';
            }
            processStudentListText(transcript);
          };
    
          recognitionRef.current.start();
        }
      };
    
      return (
        <div className="space-y-4 mb-6">
          <h3 className="text-lg font-semibold text-white">Cargar lista (máx. 50)</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="border-2 border-dashed border-white/20 rounded-lg p-6 text-center cursor-pointer hover:border-cyan-400/50 transition-all" onClick={() => document.getElementById('student-file-input')?.click()}>
              <Upload className="w-10 h-10 text-gray-400 mx-auto mb-3" />
              <Label htmlFor="student-file-input" className="text-white"><span className="font-medium text-lg">Subir Archivo</span></Label>
              <p className="text-gray-400 text-sm mt-2">{fileName ? fileName : "PDF, TXT, DOCX, XLSX, imagen"}</p>
              <Input id="student-file-input" type="file" accept=".pdf,.txt,.csv,.docx,.xlsx,image/*" onChange={handleFileChange} className="hidden" />
            </div>
            <div className="border-2 border-dashed border-white/20 rounded-lg p-6 text-center">
              <Button onClick={toggleRecording} variant="ghost" className="w-full h-full flex flex-col items-center justify-center">
                <Mic className={`w-10 h-10 mx-auto mb-3 ${isRecording ? 'text-red-500 animate-pulse' : 'text-gray-400'}`} />
                <span className="text-white font-medium text-lg">{isRecording ? 'Grabando... (Click para parar)' : 'Usar Micrófono'}</span>
                <p className="text-gray-400 text-sm mt-2">Dicta la lista de estudiantes</p>
              </Button>
            </div>
          </div>
          {isProcessing && <Progress value={processingProgress} className="w-full" />}
          {extractedStudents.length > 0 && (
            <div className="space-y-4">
              <Label className="text-white">Estudiantes Extraídos (Puedes editar la lista)</Label>
              <div className="max-h-60 overflow-y-auto glass-effect p-2 rounded-md">
                <Table>
                  <TableHeader><TableRow><TableHead className="text-cyan-300">Nombre</TableHead><TableHead className="text-cyan-300">Identificación</TableHead><TableHead className="text-cyan-300">Correo</TableHead></TableRow></TableHeader>
                  <TableBody>
                    {extractedStudents.map((student, index) => (
                      <TableRow key={index}>
                        <TableCell><Input value={student.nombre} onChange={(e) => handleExtractedStudentChange(index, 'nombre', e.target.value)} className="glass-effect h-8" /></TableCell>
                        <TableCell><Input value={student.identificacion} onChange={(e) => handleExtractedStudentChange(index, 'identificacion', e.target.value)} className="glass-effect h-8" /></TableCell>
                        <TableCell><Input value={student.correo} onChange={(e) => handleExtractedStudentChange(index, 'correo', e.target.value)} className="glass-effect h-8" /></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <Button onClick={handleSaveFromList} className="w-full bg-gradient-to-r from-cyan-500 to-blue-600" disabled={loading || !selectedExamId}>
                {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="w-4 h-4 mr-2" />} Guardar Lista
              </Button>
            </div>
          )}
        </div>
      );
    };
    
    export default StudentListUpload;