import React from 'react';
    import { Button } from '@/components/ui/button';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Loader2, Trash2 } from 'lucide-react';
    
    const StudentTable = ({ students, loading, onDelete, selectedExamId }) => {
      return (
        <div className="max-h-96 overflow-y-auto">
          {loading ? (
            <div className="flex justify-center items-center h-40">
              <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-cyan-300">Nombre</TableHead>
                  <TableHead className="hidden md:table-cell text-cyan-300">Identificación</TableHead>
                  <TableHead className="hidden md:table-cell text-cyan-300">Correo</TableHead>
                  <TableHead className="text-right text-cyan-300">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {students.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell>{student.nombre}</TableCell>
                    <TableCell className="hidden md:table-cell">{student.identificacion || 'N/A'}</TableCell>
                    <TableCell className="hidden md:table-cell">{student.correo || 'N/A'}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" onClick={() => onDelete(student.id)} className="text-red-400 hover:bg-red-500/10">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
          {!loading && students.length === 0 && (
            <p className="text-center text-gray-500 py-8">{selectedExamId ? 'No hay estudiantes para este examen.' : 'Selecciona o crea un examen para empezar.'}</p>
          )}
        </div>
      );
    };
    
    export default StudentTable;