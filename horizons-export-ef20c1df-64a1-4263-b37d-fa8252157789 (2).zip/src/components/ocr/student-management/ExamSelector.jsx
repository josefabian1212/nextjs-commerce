import React, { useState } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { FilePlus, Loader2 } from 'lucide-react';
    import { supabase } from '@/lib/supabase';
    import { toast } from '@/components/ui/use-toast';
    
    const ExamSelector = ({ exams, selectedExamId, setSelectedExamId, refreshExams, user }) => {
      const [newExamName, setNewExamName] = useState('');
      const [loading, setLoading] = useState(false);
    
      const handleCreateExam = async () => {
        if (!newExamName.trim()) {
          toast({ title: "Error", description: "El nombre del examen no puede estar vacío.", variant: "destructive" });
          return;
        }
        setLoading(true);
        try {
          const { data, error } = await supabase
            .from('examenes_ia')
            .insert({ nombre: newExamName, creado_por: user.id })
            .select()
            .single();
          if (error) throw error;
    
          toast({ title: "Examen Creado", description: `El examen "${newExamName}" ha sido creado.` });
          await refreshExams();
          setSelectedExamId(data.id);
          setNewExamName('');
        } catch (error) {
          toast({ title: "Error al crear examen", description: error.message, variant: "destructive" });
        } finally {
          setLoading(false);
        }
      };
    
      return (
        <div className="grid md:grid-cols-3 gap-4 mb-6">
          <div className="md:col-span-2 space-y-2">
            <Label htmlFor="examen" className="text-white">Seleccionar Examen</Label>
            <Select value={selectedExamId || ''} onValueChange={setSelectedExamId}>
              <SelectTrigger className="glass-effect"><SelectValue placeholder="Elige un examen..." /></SelectTrigger>
              <SelectContent className="glass-effect">
                {exams.map(exam => <SelectItem key={exam.id} value={exam.id}>{exam.nombre}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className='space-y-2'>
            <Label htmlFor="new-exam-name" className="text-white">O crear uno nuevo</Label>
            <div className="flex gap-2">
              <Input id="new-exam-name" placeholder="Nombre del nuevo examen" value={newExamName} onChange={(e) => setNewExamName(e.target.value)} className="glass-effect" />
              <Button onClick={handleCreateExam} disabled={loading} className="bg-gradient-to-r from-green-500 to-emerald-600">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <FilePlus className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </div>
      );
    };
    
    export default ExamSelector;