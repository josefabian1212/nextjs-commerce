import React, { useState } from 'react';
    import ManualStudentForm from './ManualStudentForm';
    import StudentListUpload from './StudentListUpload';
    
    const StudentInputTabs = ({ selectedExamId, onStudentsAdded }) => {
      const [activeInputMethod, setActiveInputMethod] = useState('manual');
    
      return (
        <div>
          <div className="flex border-b border-white/10 mb-4">
            <button onClick={() => setActiveInputMethod('manual')} className={`px-4 py-2 font-medium ${activeInputMethod === 'manual' ? 'text-cyan-300 border-b-2 border-cyan-300' : 'text-gray-400'}`}>
              Entrada Manual
            </button>
            <button onClick={() => setActiveInputMethod('file')} className={`px-4 py-2 font-medium ${activeInputMethod === 'file' ? 'text-cyan-300 border-b-2 border-cyan-300' : 'text-gray-400'}`}>
              Cargar Lista
            </button>
          </div>
    
          {activeInputMethod === 'manual' && (
            <ManualStudentForm selectedExamId={selectedExamId} onStudentAdded={onStudentsAdded} />
          )}
    
          {activeInputMethod === 'file' && (
            <StudentListUpload selectedExamId={selectedExamId} onListSaved={onStudentsAdded} />
          )}
        </div>
      );
    };
    
    export default StudentInputTabs;