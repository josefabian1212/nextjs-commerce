import React, { useState, useEffect, useCallback } from 'react';
    import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
    import { Users } from 'lucide-react';
    import ExamSelector from '@/components/ocr/student-management/ExamSelector';
    import StudentInputTabs from '@/components/ocr/student-management/StudentInputTabs';
    import StudentTable from '@/components/ocr/student-management/StudentTable';
    import { supabase } from '@/lib/supabase';
    import { useAuth } from '@/contexts/AuthContext';
    import { toast } from '@/components/ui/use-toast';
    
    const StudentManagementForm = ({ exams, selectedExamId, setSelectedExamId, refreshExams }) => {
      const { user } = useAuth();
      const [students, setStudents] = useState([]);
      const [loadingStudents, setLoadingStudents] = useState(false);
    
      const fetchStudents = useCallback(async () => {
        if (!selectedExamId) {
          setStudents([]);
          return;
        }
        setLoadingStudents(true);
        try {
          const { data, error } = await supabase
            .from('estudiantes_ia')
            .select('*')
            .eq('examen_id', selectedExamId)
            .order('nombre', { ascending: true });
          
          if (error) {
            if (error.message.includes('Failed to fetch')) {
              toast({ title: "Error de Red", description: "No se pudieron cargar los estudiantes. Revisa tu conexión.", variant: "destructive" });
            } else {
              throw error;
            }
          }
          setStudents(data || []);
        } catch (error) {
          toast({ title: "Error", description: "No se pudieron cargar los estudiantes.", variant: "destructive" });
          setStudents([]);
        } finally {
          setLoadingStudents(false);
        }
      }, [selectedExamId]);
    
      useEffect(() => {
        fetchStudents();
      }, [selectedExamId, fetchStudents]);
    
      const handleDeleteStudent = async (studentId) => {
        try {
          const { error } = await supabase
            .from('estudiantes_ia')
            .delete()
            .eq('id', studentId);
    
          if (error) throw error;
          setStudents(prev => prev.filter(s => s.id !== studentId));
          toast({ title: "Estudiante Eliminado", description: "El estudiante ha sido eliminado." });
        } catch (error) {
          toast({ title: "Error", description: error.message, variant: "destructive" });
        }
      };
    
      return (
        <Card className="glass-effect glow-effect w-full max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle className="text-white flex items-center"><Users className="w-6 h-6 mr-3 text-cyan-400" />Paso 2: Gestionar Estudiantes</CardTitle>
            <CardDescription className="text-gray-300">Crea o selecciona un examen y luego añade estudiantes.</CardDescription>
          </CardHeader>
          <CardContent>
            <ExamSelector
              exams={exams}
              selectedExamId={selectedExamId}
              setSelectedExamId={setSelectedExamId}
              refreshExams={refreshExams}
              user={user}
            />
            
            <StudentInputTabs 
              selectedExamId={selectedExamId}
              onStudentsAdded={fetchStudents}
            />
    
            <StudentTable
              students={students}
              loading={loadingStudents}
              onDelete={handleDeleteStudent}
              selectedExamId={selectedExamId}
            />
          </CardContent>
        </Card>
      );
    };
    
    export default StudentManagementForm;