import React, { useState, useEffect, useCallback } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
    import { Progress } from '@/components/ui/progress';
    import { useTokens } from '@/contexts/TokenContext';
    import { toast } from '@/components/ui/use-toast';
    import { KeyRound, Upload, Save, Loader2, PlusCircle, Trash2 } from 'lucide-react';
    import { supabase } from '@/lib/supabase';
    import { useAuth } from '@/contexts/AuthContext';
    import { createWorker } from 'tesseract.js';
    import { parseAnswerKeyFile } from '@/lib/fileParser';
    
    const AnswerKeyManagementForm = ({ exams, selectedExamId, setSelectedExamId }) => {
      const { user } = useAuth();
      const { spendTokens } = useTokens();
      const [loading, setLoading] = useState(false);
      const [activeInputMethod, setActiveInputMethod] = useState('file');
    
      const [answers, setAnswers] = useState([{ question: '', answer: '', value: '' }]);
    
      const [extractedText, setExtractedText] = useState('');
      const [processingProgress, setProcessingProgress] = useState(0);
      const [isProcessing, setIsProcessing] = useState(false);
      const [fileName, setFileName] = useState('');
    
      const fetchAnswerKey = useCallback(async () => {
        if (!selectedExamId) {
          setAnswers([{ question: '', answer: '', value: '' }]);
          return;
        }
    
        setLoading(true);
        try {
          const { data, error } = await supabase
            .from('clave_respuestas_ia')
            .select('respuestas')
            .eq('examen_id', selectedExamId)
            .maybeSingle();
      
          if (error) {
            console.error("Error fetching answer key:", error);
            if (error.message?.includes('Failed to fetch')) {
                toast({ title: "Error de Red", description: "No se pudo cargar la clave. Revisa tu conexión.", variant: "destructive" });
            } else {
                toast({ title: "Error", description: "No se pudo cargar la clave de respuestas.", variant: "destructive" });
            }
            setAnswers([{ question: '', answer: '', value: '' }]);
            return;
          }
      
          if (data && data.respuestas) {
            const loadedAnswers = Object.entries(data.respuestas).map(([q, a]) => ({
              question: q,
              answer: a.respuesta,
              value: a.valor || '',
            }));
            setAnswers(loadedAnswers.length > 0 ? loadedAnswers : [{ question: '', answer: '', value: '' }]);
          } else {
            setAnswers([{ question: '', answer: '', value: '' }]);
          }
        } catch (error) {
            console.error("Critical error in fetchAnswerKey:", error);
            if (error.message?.includes('Failed to fetch')) {
                toast({ title: "Error de Red", description: "Ocurrió un error de red inesperado al cargar la clave.", variant: "destructive" });
            } else {
                toast({ title: "Error Crítico", description: "Ocurrió un error inesperado al cargar la clave.", variant: "destructive" });
            }
        } finally {
            setLoading(false);
        }
      }, [selectedExamId]);
    
      useEffect(() => {
        fetchAnswerKey();
      }, [fetchAnswerKey]);
    
      const handleAnswerChange = (index, field, value) => {
        const newAnswers = [...answers];
        newAnswers[index][field] = value;
        setAnswers(newAnswers);
      };
    
      const addAnswerField = () => {
        setAnswers([...answers, { question: '', answer: '', value: '' }]);
      };
    
      const removeAnswerField = (index) => {
        const newAnswers = answers.filter((_, i) => i !== index);
        setAnswers(newAnswers);
      };
    
      const handleManualSubmit = async (e) => {
        e.preventDefault();
        if (!selectedExamId || answers.some(a => !a.question || !a.answer)) {
           toast({ title: "Error", description: "Selecciona un examen y completa todos los campos de pregunta y respuesta.", variant: "destructive" });
           return;
        }
        
        const answerKeyObject = answers.reduce((acc, curr) => {
          if (curr.question) {
            acc[curr.question] = {
              respuesta: curr.answer,
              valor: parseFloat(curr.value) || 1
            };
          }
          return acc;
        }, {});
    
        if (!await spendTokens(0, `Subir clave manual para examen`, 'answer-key')) return;
        
        setLoading(true);
        try {
          const { error } = await supabase
            .from('clave_respuestas_ia')
            .upsert({
              examen_id: selectedExamId,
              respuestas: answerKeyObject,
              creado_por: user.id,
            }, { onConflict: 'examen_id' });
    
          if (error) throw error;
          toast({ title: "¡Clave Guardada!", description: "La clave de respuestas ha sido guardada/actualizada." });
        } catch (error) {
          toast({ title: "Error", description: error.message, variant: "destructive" });
        } finally {
          setLoading(false);
        }
      };
      
      const handleFileChange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
    
        setFileName(file.name);
        setExtractedText('');
        setProcessingProgress(0);
        setIsProcessing(true);
    
        try {
          const result = await parseAnswerKeyFile(file);
          if (result.useOcr) {
            await handleOcrScan(result.file);
          } else {
            setExtractedText(result);
            toast({ title: "Archivo Procesado", description: "El texto ha sido extraído. Revísalo y guárdalo." });
          }
        } catch (error) {
          toast({ title: "Error de Procesamiento", description: error.message, variant: "destructive" });
        } finally {
          setIsProcessing(false);
        }
      };
      
      const handleOcrScan = async (file) => {
        const worker = await createWorker({
          logger: m => {
            if (m.status === 'recognizing text') {
              setProcessingProgress(Math.round(m.progress * 100));
            }
          },
        });
        await worker.loadLanguage('spa');
        await worker.initialize('spa');
        const { data: { text } } = await worker.recognize(file);
        setExtractedText(text);
        await worker.terminate();
        setProcessingProgress(100);
        toast({ title: "OCR Completado", description: "El texto ha sido extraído. Revísalo y guárdalo." });
      };
      
      const handleSaveFromText = async () => {
        if (!extractedText || !selectedExamId) {
          toast({ title: "Error", description: "No hay texto para procesar o no se ha seleccionado un examen.", variant: "destructive" });
          return;
        }
        if (!await spendTokens(0, `Procesar clave de respuestas para examen`, 'answer-key')) return;
    
        setLoading(true);
        try {
          const { data, error } = await supabase.functions.invoke('openai-proxy', {
            body: { serviceType: 'ocr-answer-key', text: extractedText, examen_id: selectedExamId },
          });
          if (error) throw error;
          if (data.error) throw new Error(data.error);
          
          toast({ title: "¡Éxito!", description: "Clave de respuestas procesada y guardada." });
          setExtractedText('');
          setFileName('');
          setProcessingProgress(0);
          fetchAnswerKey();
        } catch (error) {
          let errorMessage = "La IA no pudo procesar el texto.";
          if (error.message?.includes('Failed to fetch')) {
            errorMessage = "Error de red al contactar la IA. Revisa tu conexión.";
          } else if (error.message) {
            errorMessage = error.message;
          }
          toast({ title: "Error de Estructuración", description: errorMessage, variant: "destructive" });
        } finally {
          setLoading(false);
        }
      };
    
      return (
        <Card className="glass-effect glow-effect w-full max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle className="text-white flex items-center"><KeyRound className="w-6 h-6 mr-3 text-yellow-400" />Paso 3: Clave de Respuestas</CardTitle>
            <CardDescription className="text-gray-300">Sube un archivo o ingresa las respuestas manualmente.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 mb-6">
                <Label htmlFor="examen" className="text-white">Seleccionar Examen</Label>
                <Select value={selectedExamId || ''} onValueChange={setSelectedExamId}>
                  <SelectTrigger className="glass-effect"><SelectValue placeholder="Elige un examen..." /></SelectTrigger>
                  <SelectContent className="glass-effect">
                    {exams.map(exam => <SelectItem key={exam.id} value={exam.id}>{exam.nombre}</SelectItem>)}
                  </SelectContent>
                </Select>
            </div>
    
            <div className="flex border-b border-white/10 mb-4">
                <button onClick={() => setActiveInputMethod('file')} className={`px-4 py-2 font-medium ${activeInputMethod === 'file' ? 'text-yellow-300 border-b-2 border-yellow-300' : 'text-gray-400'}`}>Cargar Archivo</button>
                <button onClick={() => setActiveInputMethod('manual')} className={`px-4 py-2 font-medium ${activeInputMethod === 'manual' ? 'text-yellow-300 border-b-2 border-yellow-300' : 'text-gray-400'}`}>Entrada Manual</button>
            </div>
    
            {activeInputMethod === 'file' && (
              <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">Cargar clave</h3>
                  <div className="border-2 border-dashed border-white/20 rounded-lg p-6 text-center cursor-pointer hover:border-yellow-400/50 transition-all" onClick={() => document.getElementById('key-file-input')?.click()}>
                      <Upload className="w-10 h-10 text-gray-400 mx-auto mb-3" />
                      <Label htmlFor="key-file-input" className="text-white"><span className="font-medium text-lg">Arrastra o selecciona un archivo</span></Label>
                      <p className="text-gray-400 text-sm mt-2">{fileName ? fileName : "Soporta imágenes, PDF, DOCX, XLSX, TXT"}</p>
                      <Input id="key-file-input" type="file" accept=".txt,.xlsx,.pdf,.docx,image/*" onChange={handleFileChange} className="hidden" />
                  </div>
                  {isProcessing && <Progress value={processingProgress} className="w-full" />}
                  {extractedText && (
                      <div className="space-y-2">
                          <Label className="text-white">Texto Extraído (Puedes editarlo)</Label>
                          <Textarea value={extractedText} onChange={(e) => setExtractedText(e.target.value)} rows={8} className="glass-effect font-mono text-xs" />
                          <Button onClick={handleSaveFromText} className="w-full bg-gradient-to-r from-yellow-500 to-amber-600" disabled={loading || !selectedExamId}>
                              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                              Procesar con IA y Guardar
                          </Button>
                      </div>
                  )}
              </div>
            )}
            
            {activeInputMethod === 'manual' && (
              <form onSubmit={handleManualSubmit} className="space-y-6">
                <h3 className="text-lg font-semibold text-white">Entrada Manual</h3>
                <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
                  {loading ? (
                     <div className="flex justify-center items-center h-40"><Loader2 className="w-8 h-8 animate-spin text-yellow-400" /></div>
                  ) : answers.map((ans, index) => (
                    <div key={index} className="flex items-center gap-2 p-3 bg-slate-800/50 rounded-lg">
                      <Input
                        type="text"
                        placeholder="Nº Preg."
                        value={ans.question}
                        onChange={(e) => handleAnswerChange(index, 'question', e.target.value)}
                        className="glass-effect w-24"
                        required
                      />
                      <Input
                        type="text"
                        placeholder="Respuesta Correcta"
                        value={ans.answer}
                        onChange={(e) => handleAnswerChange(index, 'answer', e.target.value)}
                        className="glass-effect flex-grow"
                        required
                      />
                      <Input
                        type="number"
                        placeholder="Valor"
                        value={ans.value}
                        onChange={(e) => handleAnswerChange(index, 'value', e.target.value)}
                        className="glass-effect w-20"
                        step="0.1"
                      />
                      <Button type="button" variant="ghost" size="icon" onClick={() => removeAnswerField(index)} className="text-red-400 hover:bg-red-500/10">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
                <Button type="button" variant="outline" onClick={addAnswerField} className="w-full border-dashed">
                  <PlusCircle className="mr-2 h-4 w-4" /> Añadir Respuesta
                </Button>
                <Button type="submit" className="w-full glow-effect bg-gradient-to-r from-yellow-500 to-amber-600" disabled={loading || !selectedExamId}>
                  {loading ? (<div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>) : <Save className="w-4 h-4 mr-2" />}
                  Guardar Clave Manual
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      );
    };
    
    export default AnswerKeyManagementForm;