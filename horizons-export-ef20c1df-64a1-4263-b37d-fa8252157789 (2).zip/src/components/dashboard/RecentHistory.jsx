import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Award, History } from 'lucide-react';

const RecentHistory = ({ history, loading, serviceTypes }) => {
  const usageHistory = Array.isArray(history) ? history.filter(h => serviceTypes.includes(h.type)) : [];

  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <History className="w-6 h-6 mr-3 text-purple-400" />
          Historial Reciente de Uso
        </CardTitle>
        <CardDescription className="text-gray-300">
          Tus últimas actividades y uso de créditos.
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-3 max-h-80 overflow-y-auto scrollbar-hide">
          {loading ? (
            <div className="text-center py-8 text-gray-400">Cargando historial...</div>
          ) : usageHistory.length === 0 ? (
            <div className="text-center py-8">
              <Award className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-400">No has utilizado servicios aún.</p>
              <p className="text-gray-500 text-sm">¡Explora nuestras herramientas IA!</p>
            </div>
          ) : (
            usageHistory.slice(0, 10).map((item) => (
              <div key={item.id} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg border border-slate-700/50">
                <div className="flex-1">
                  <p className="text-white text-sm font-medium truncate" title={item.description}>{item.description || 'Uso de servicio IA'}</p>
                  <p className="text-gray-400 text-xs">
                    {new Date(item.created_at).toLocaleDateString('es-ES', {
                      day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'
                    })}
                  </p>
                </div>
                <div className="text-sm font-medium text-orange-400 ml-2">
                  {Math.abs(item.amount || 0)} créditos
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default RecentHistory;