import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';
import { Settings, ShieldCheck } from 'lucide-react';

const UserAccountSettings = ({ profile, user, subscriptionPlan, onPasswordChangeClick }) => {
    const navigate = useNavigate();

    const handleManageSubscription = () => {
        navigate('/#pricing');
    };

    return (
        <Card className="glass-effect">
            <CardHeader>
                <CardTitle className="text-white flex items-center">
                    <Settings className="w-6 h-6 mr-3 text-sky-400" />
                    Configuración de Cuenta
                </CardTitle>
                <CardDescription className="text-gray-300">
                    Actualiza tu información personal y preferencias.
                </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
                <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                    <h4 className="text-lg font-semibold text-white mb-1">Información Personal</h4>
                    <p className="text-sm text-gray-400">Nombre: {profile?.full_name || 'N/A'}</p>
                    <p className="text-sm text-gray-400">Correo: {user?.email}</p>
                    <Button variant="link" className="p-0 h-auto text-sky-400 hover:text-sky-300 text-sm mt-2" onClick={() => toast({ title: 'Próximamente', description: 'Podrás editar tu perfil pronto.'})}>Editar Perfil (Próximamente)</Button>
                </div>

                <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                    <h4 className="text-lg font-semibold text-white mb-1">Suscripción y Facturación</h4>
                    <p className="text-sm text-gray-400">Plan actual: <span className="font-semibold text-yellow-400">{subscriptionPlan || 'Gratis'}</span></p>
                    <Button className="mt-3 bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-700 hover:to-sky-600 text-white" onClick={handleManageSubscription}>
                        Ver Planes y Precios
                    </Button>
                </div>

                <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                    <h4 className="text-lg font-semibold text-white mb-1">Seguridad</h4>
                    <Button variant="link" className="p-0 h-auto text-sky-400 hover:text-sky-300 text-sm" onClick={onPasswordChangeClick}>Cambiar Contraseña</Button>
                    <div className="flex items-center text-sm text-green-400 mt-2">
                        <ShieldCheck className="w-4 h-4 mr-1"/> Cuenta Segura
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};

export default UserAccountSettings;