import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

const VerificationWarning = ({ isVerified, isResending, onResend }) => {
    if (isVerified) return null;

    return (
        <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 p-4 bg-yellow-500/20 border border-yellow-400/50 rounded-lg text-yellow-200"
        >
            <div className="flex items-center justify-between">
                <div>
                    <h3 className="font-bold">Verifica tu Correo Electrónico</h3>
                    <p className="text-sm">Para acceder a todas las funciones, por favor verifica tu correo electrónico. Revisa tu bandeja de entrada (y spam).</p>
                </div>
                <Button 
                    variant="outline" 
                    className="border-yellow-300 text-yellow-300 hover:bg-yellow-400/20"
                    onClick={onResend}
                    disabled={isResending}
                >
                    {isResending ? 'Reenviando...' : 'Reenviar Correo'}
                </Button>
            </div>
        </motion.div>
    );
};

export default VerificationWarning;