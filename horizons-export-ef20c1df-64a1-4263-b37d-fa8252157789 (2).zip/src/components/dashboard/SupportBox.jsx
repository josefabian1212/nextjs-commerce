import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { LifeBuoy } from 'lucide-react';

const SupportBox = () => {
    return (
        <Card className="glass-effect">
            <CardHeader>
                <CardTitle className="text-white flex items-center">
                    <LifeBuoy className="w-6 h-6 mr-3 text-green-400" />
                    Soporte y Ayuda
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
                <a href="https://wa.me/573207303024" target="_blank" rel="noopener noreferrer" className="w-full">
                    <Button variant="outline" className="w-full border-green-500/50 text-green-300 hover:bg-green-500/10">
                        Contactar Soporte por WhatsApp
                    </Button>
                </a>
                <Link to="/faq" className="w-full">
                    <Button variant="link" className="w-full text-gray-400 hover:text-sky-300">
                        Preguntas Frecuentes (FAQ)
                    </Button>
                </Link>
            </CardContent>
        </Card>
    );
};

export default SupportBox;