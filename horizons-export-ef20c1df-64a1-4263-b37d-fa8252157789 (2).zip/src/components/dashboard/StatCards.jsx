import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Brain, TrendingUp, Calendar, Award } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

const StatCards = ({ user, subscriptionPlan, tokens, creditHistory, loading }) => {
  const aiServiceTypes = [
    'class-generator', 'children-creativity', 'attention-diversity', 
    'pedagogical-workshops', 'cooperative-learning', 'create-startup', 
    'academic-articles', 'tutorial-generator', 'poems-songs', 'unit-topics', 
    'educational-projects', 'math-analysis', 'text-analysis', 'cognitive-analysis', 
    'podcast-generator', 'pqrs-generator', 'critical-thinking', 'multiple-intelligences', 
    'neuroeducation', 'evaluacion-formativa', 'inteligencia-artificial', 'gamificacion',
    'ocr-exam', 'uso_servicio_ia', 'exam-generator-ia', 'inclusion-workshops',
    'create-exam', 'students'
  ];

  const usageHistory = Array.isArray(creditHistory) ? creditHistory.filter(h => aiServiceTypes.includes(h.type)) : [];
  const totalUsage = usageHistory.reduce((acc, h) => acc + Math.abs(h.amount || 0), 0);

  const stats = [
    {
      title: 'Plan Actual',
      value: loading ? <Skeleton className="h-7 w-24" /> : (subscriptionPlan || 'Gratis'),
      icon: Award,
      color: 'from-yellow-500 to-orange-500'
    },
    {
      title: 'Créditos Disponibles',
      value: loading ? <Skeleton className="h-7 w-12" /> : tokens,
      icon: Brain,
      color: 'from-purple-500 to-blue-500'
    },
    {
      title: 'Uso Total (Créditos)',
      value: loading ? <Skeleton className="h-7 w-12" /> : totalUsage,
      icon: TrendingUp,
      color: 'from-green-500 to-teal-500'
    },
    {
      title: 'Miembro Desde',
      value: loading ? <Skeleton className="h-7 w-32" /> : (user?.created_at ? new Date(user.created_at).toLocaleDateString('es-ES', { year: 'numeric', month: 'long' }) : 'N/A'),
      icon: Calendar,
      color: 'from-pink-500 to-purple-500'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {stats.map((stat, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
        >
          <Card className="glass-effect card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm font-medium">{stat.title}</p>
                  <p className="text-2xl font-bold text-white">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 bg-gradient-to-r ${stat.color} rounded-lg flex items-center justify-center`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
};

export default StatCards;