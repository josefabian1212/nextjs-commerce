import React from 'react';
import { motion } from 'framer-motion';
import Logo from '@/components/Logo';

const DashboardHeader = ({ profile, user }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between"
    >
      <div className="flex items-center gap-4 mb-4 md:mb-0">
        <Logo className="h-16 hidden sm:block" />
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-white">
            ¡Bienvenido, {profile?.full_name || user?.email}!
          </h1>
          <p className="text-lg text-gray-300">
            Tu centro de control en Profe IA.
          </p>
        </div>
      </div>
    </motion.div>
  );
};

export default DashboardHeader;