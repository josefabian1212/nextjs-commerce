import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { Users, Star, TrendingUp } from 'lucide-react';

export const useHomeLogic = (user) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [showAuthModal, setShowAuthModal] = useState(location.state?.showAuthModal || false);
  const [dynamicStats, setDynamicStats] = useState({
    totalUsers: '10K+',
    totalServices: '20+',
    satisfaction: '98%',
    icons: { Users, Star, TrendingUp }
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (location.state?.showAuthModal) {
      setShowAuthModal(true);
      navigate(location.pathname, { replace: true, state: {} }); 
    }
  }, [location, navigate]);

  useEffect(() => {
    const loadDynamicContent = async () => {
      setIsLoading(true);
      try {
        const { data, error } = await supabase.rpc('get_public_stats');

        if (error) {
          console.warn('Error fetching public stats:', error.message);
          return;
        }
        
        if (data) {
          if (data.profilesCount) {
            const userCount = data.profilesCount;
            setDynamicStats(prev => ({
              ...prev,
              totalUsers: userCount > 1000 ? `${Math.floor(userCount/1000)}K+` : `${userCount}+`
            }));
          }
          if (data.servicesCount) {
            setDynamicStats(prev => ({
              ...prev,
              totalServices: `${Math.min(data.servicesCount, 25)}+`
            }));
          }
        }
      } catch (error) {
        console.warn('Error loading dynamic content:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadDynamicContent();
  }, []);
  
  const handleCTA = (path, requiresAuth = false) => {
    if (requiresAuth && !user) {
      setShowAuthModal(true);
    } else {
      navigate(path);
    }
  };

  return {
    showAuthModal,
    setShowAuthModal,
    dynamicStats,
    isLoading,
    handleCTA
  };
};

export default useHomeLogic;