import React from 'react';
import { motion } from 'framer-motion';
import { Quote } from 'lucide-react';

const TestimonialsSection = () => {
  const testimonials = [
    { name: 'Ana Sofía Pérez', role: 'Docente de Secundaria, Bogotá', text: 'Profe IA ha sido un cambio radical en mi planificación. Ahora tengo más tiempo para enfocarme en las necesidades individuales de mis estudiantes.' },
    { name: 'Javier Castillo', role: 'Coordinador Académico, Lima', text: 'La capacidad de generar exámenes y analizar resultados con IA ha mejorado nuestra eficiencia en un 80%. Es una herramienta indispensable.' },
    { name: 'Laura Fernández', role: 'Profesora de Primaria, Santiago', text: 'Mis clases son más dinámicas y creativas. Los recursos y talleres que genero con Profe IA mantienen a mis alumnos totalmente enganchados.' },
  ];

  return (
    <section className="py-20 bg-slate-900/50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Amado por docentes, <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-500">impulsado por resultados</span>
          </h2>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            Más de 100 docentes comprobaron: 90% de ahorro de tiempo, mejora en el rendimiento estudiantil y reducción de carga administrativa.
          </p>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto mt-4">
            Profe IA se alinea con los Derechos Básicos de Aprendizaje (DBA) de cada país, los Planes Educativos Institucionales (PEI) y cumple con las normativas locales de educación.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
              viewport={{ once: true }}
              className="glass-effect p-8 rounded-2xl border border-blue-500/20"
            >
              <Quote className="w-8 h-8 text-blue-400 mb-4" />
              <p className="text-gray-300 mb-6 flex-grow">"{testimonial.text}"</p>
              <div>
                <p className="font-bold text-white">{testimonial.name}</p>
                <p className="text-sm text-gray-400">{testimonial.role}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;