import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, Brain } from 'lucide-react';
import SocialShareButtons from '@/components/SocialShareButtons';
import { pageUrl } from '@/components/home/homeData';

const FinalCTA = ({ user, handleCTA }) => {
  const navigate = useNavigate();
  const shareTitle = "¡He descubierto una plataforma de IA increíble para docentes! Se llama Profe IA y está transformando la forma de crear contenido educativo. ¡Tienes que probarla!";
  const shareImage = "https://storage.googleapis.com/hostinger-horizons-assets-prod/ef20c1df-64a1-4263-b37d-fa8252157789/9f657bcc7fc862261dd737580a812d2e.png";

  return (
    <section className="py-24 px-4 bg-gradient-to-b from-black to-slate-950">
      <div className="max-w-3xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">¿Listo para Transformar tu Enseñanza?</h2>
          <p className="text-lg text-gray-300 mb-10 leading-relaxed">
            No te quedes atrás. Profe AI optimiza tu tiempo, personaliza el aprendizaje y prepara a tus estudiantes para el futuro. <span className="font-semibold text-sky-300">¡Inscríbete hoy y sé parte del cambio!</span>
          </p>
          <div className="flex flex-col items-center gap-6">
              {!user ? (
                <a href="mailto:innovaciondigital2050@gmail.com" className="glow-effect bg-gradient-to-r from-blue-600 via-sky-500 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-xl text-xl px-10 py-6 rounded-xl inline-flex items-center">
                  Únete <ArrowRight className="ml-3 w-6 h-6" />
                </a>
              ) : (
                <Button size="lg" className="glow-effect bg-gradient-to-r from-green-600 via-emerald-500 to-teal-600 hover:from-green-700 hover:to-teal-700 text-white shadow-xl text-xl px-10 py-6 rounded-xl" onClick={() => navigate('/servicios')}>
                  Comenzar a Crear <Brain className="ml-3 w-6 h-6" />
                </Button>
              )}
              <SocialShareButtons title={shareTitle} url={pageUrl} imageUrl={shareImage} />
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default FinalCTA;