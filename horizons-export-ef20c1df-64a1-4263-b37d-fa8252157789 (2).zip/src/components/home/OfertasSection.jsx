import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Check, Zap, Crown, Star, Package } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';

const formatCOP = (amount) => {
    return new Intl.NumberFormat('es-CO', {
        style: 'currency',
        currency: 'COP',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
    }).format(amount);
};

const OfertasSection = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  
  const handleGetPlan = (planId, couponCode) => {
     if (!user) {
      toast({
        title: "Inicia Sesión para Continuar",
        description: "Necesitas una cuenta para aprovechar esta oferta.",
        variant: "destructive"
      });
      navigate('/registro');
      return;
    }
    
    // The Ofertas page now directly handles plan selection and redirection
    navigate('/ofertas'); 
  };


  return (
    <section id="ofertas-home" className="py-20 bg-gradient-to-b from-slate-900 to-purple-900/40">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Planes y <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">Ofertas</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Elige la opción perfecta para potenciar tu enseñanza con inteligencia artificial.
          </p>
          <div className="mt-8">
            <Button size="lg" onClick={() => navigate('/ofertas')} className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-bold text-lg animate-pulse">
                <Zap className="w-5 h-5 mr-2" />
                ¡Ver Ofertas de Lanzamiento por Tiempo Limitado!
            </Button>
          </div>
        </motion.div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Plan Gratuito */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
            className="h-full"
          >
            <Card className="glass-effect border-sky-500/30 h-full flex flex-col">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-r from-gray-600 to-gray-700 flex items-center justify-center text-white mb-4">
                  <Star className="w-6 h-6" />
                </div>
                <CardTitle className="text-2xl font-bold text-white">Gratis</CardTitle>
                <div className="mt-4">
                  <span className="text-4xl font-bold text-yellow-400">GRATIS</span>
                </div>
                <p className="text-sky-300 font-semibold mt-2">10 créditos</p>
              </CardHeader>
              <CardContent className="space-y-4 flex-grow flex flex-col justify-between">
                <ul className="space-y-3">
                  <li className="flex items-center text-gray-300"><Check className="w-5 h-5 text-green-400 mr-3"/>Acceso a servicios básicos</li>
                  <li className="flex items-center text-gray-300"><Check className="w-5 h-5 text-green-400 mr-3"/>Generación de talleres</li>
                </ul>
                <Button onClick={() => navigate('/registro')} className="w-full mt-6 bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800 text-white">Empezar Gratis</Button>
              </CardContent>
            </Card>
          </motion.div>

          {/* Oferta Anual - Example, now redirected to Ofertas */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="relative h-full"
          >
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
              <span className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black px-4 py-1 rounded-full text-sm font-bold">¡Descuento!</span>
            </div>
            <Card className="glass-effect border-2 border-yellow-400/50 shadow-xl h-full flex flex-col">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-r from-purple-600 to-pink-600 flex items-center justify-center text-white mb-4">
                  <Crown className="w-6 h-6" />
                </div>
                <CardTitle className="text-2xl font-bold text-white">Plan Anual</CardTitle>
                 <div className="mt-4">
                  <p className="text-gray-400 text-md line-through">{formatCOP(Math.round(98000 * 12 / (1 - 0.70)))}</p>
                  <span className="text-4xl font-bold text-yellow-400">{formatCOP(98000 * 12 * (1 - 0.70))}</span>
                  <span className="text-gray-400 ml-1">/año</span>
                </div>
                <p className="text-sky-300 font-semibold mt-2">Créditos mensuales</p>
              </CardHeader>
              <CardContent className="space-y-4 flex-grow flex flex-col justify-between">
                <ul className="space-y-3">
                  <li className="flex items-center text-gray-300"><Check className="w-5 h-5 text-green-400 mr-3"/>Todos los servicios de IA</li>
                  <li className="flex items-center text-gray-300"><Check className="w-5 h-5 text-green-400 mr-3"/>Soporte prioritario 24/7</li>
                </ul>
                <Button onClick={() => handleGetPlan('annual', 'ANUAL50')} className="w-full mt-6 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold">¡Ver Oferta!</Button>
              </CardContent>
            </Card>
          </motion.div>

          {/* Oferta Mensual Premium - Example, now redirected to Ofertas */}
           <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            viewport={{ once: true }}
            className="relative h-full"
          >
             <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
              <span className="bg-gradient-to-r from-sky-400 to-blue-500 text-white px-4 py-1 rounded-full text-sm font-bold">¡Descuento!</span>
            </div>
            <Card className="glass-effect border-2 border-sky-400/50 shadow-xl h-full flex flex-col">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center text-white mb-4">
                  <Zap className="w-6 h-6" />
                </div>
                <CardTitle className="text-2xl font-bold text-white">Premium Mensual</CardTitle>
                <div className="mt-4">
                  <p className="text-gray-400 text-md line-through">{formatCOP(Math.round(98000 / (1 - 0.50)))}</p>
                  <span className="text-4xl font-bold text-sky-300">{formatCOP(98000)}</span>
                  <span className="text-gray-400 ml-1">/mes</span>
                </div>
                 <p className="text-sky-300 font-semibold mt-2">600 créditos mensuales</p>
              </CardHeader>
              <CardContent className="space-y-4 flex-grow flex flex-col justify-between">
                <ul className="space-y-3">
                  <li className="flex items-center text-gray-300"><Check className="w-5 h-5 text-green-400 mr-3"/>Acceso a funciones Beta</li>
                  <li className="flex items-center text-gray-300"><Check className="w-5 h-5 text-green-400 mr-3"/>Análisis avanzado con IA</li>
                </ul>
                <Button onClick={() => handleGetPlan('premium', 'PREMIUM30')} className="w-full mt-6 bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-700 hover:to-sky-600 text-white">¡Ver Oferta!</Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default OfertasSection;