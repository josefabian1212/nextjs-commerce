import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Check, Zap, Crown, Star, Package, CreditCard, HelpCircle, ChevronDown, Award } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

const formatCOP = (amount) => {
    return new Intl.NumberFormat('es-CO', {
        style: 'currency',
        currency: 'COP',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
    }).format(amount);
};

const PricingSection = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [billingCycle, setBillingCycle] = useState('monthly');

  const handlePlanSelect = (plan) => {
    if (!user) {
      toast({
        title: "Inicia Sesión",
        description: "Debes iniciar sesión para seleccionar un plan.",
        variant: "destructive"
      });
      navigate('/login');
      return;
    }

    if (plan.id === 'free') {
      toast({
        title: "Plan Gratuito",
        description: "Ya tienes acceso al plan gratuito con 10 créditos.",
      });
      return;
    }
    
    navigate('/ofertas');
  };

  const subscriptionPlans = [
    {
      id: 'free',
      name: 'Gratis',
      priceMonthly: 0,
      priceYearly: 0,
      credits: 10,
      features: ['10 créditos gratis', 'Acceso a servicios básicos', 'Generación de talleres'],
      popular: false,
      icon: <Award className="w-6 h-6" />,
      gradient: 'from-gray-600 to-gray-700'
    },
    {
      id: 'basic',
      name: 'Básico',
      // Base prices (before discounts)
      priceMonthly: Math.round(35000 / (1 - 0.30)), // 30% off to reach 35000 COP
      priceYearly: Math.round(35000 * 12 / (1 - 0.40)), // 40% off for annual
      credits: 200,
      features: ['200 créditos/mes', 'Todos los servicios de IA', 'Exportación PDF y Word', 'Soporte prioritario'],
      popular: true,
      icon: <Zap className="w-6 h-6" />,
      gradient: 'from-blue-600 to-purple-600'
    },
    {
      id: 'premium',
      name: 'Premium',
      // Base prices (before discounts)
      priceMonthly: Math.round(98000 / (1 - 0.50)), // 50% off to reach 98000 COP
      priceYearly: Math.round(98000 * 12 / (1 - 0.70)), // 70% off for annual
      credits: 600,
      features: ['600 créditos/mes', 'Acceso completo a todas las funciones', 'Análisis avanzado con IA', 'Soporte 24/7'],
      popular: false,
      icon: <Crown className="w-6 h-6" />,
      gradient: 'from-purple-600 to-pink-600'
    }
  ];

  const PlanCard = ({ plan, index }) => {
    const isYearly = billingCycle === 'yearly';
    const basePrice = isYearly ? plan.priceYearly : plan.priceMonthly;
    const period = isYearly ? '/año' : '/mes';
    let discount = 0;

    if (plan.id !== 'free') {
        if (isYearly) {
            if (plan.id === 'basic') discount = 0.40; // 40% OFF for annual basic
            if (plan.id === 'premium') discount = 0.70; // 70% OFF for annual premium
        } else {
            if (plan.id === 'basic') discount = 0.30; // 30% OFF for monthly basic
            if (plan.id === 'premium') discount = 0.50; // 50% OFF for monthly premium
        }
    }
    const discountedPrice = basePrice * (1 - discount);

    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        viewport={{ once: true }}
        className="relative h-full"
      >
        {plan.popular && (
          <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
            <span className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black px-4 py-1 rounded-full text-sm font-bold">
              Más Popular
            </span>
          </div>
        )}
        <Card className={`glass-effect border-2 ${plan.popular ? 'border-yellow-400/50' : 'border-sky-500/30'} shadow-xl hover:shadow-2xl transition-all duration-300 h-full flex flex-col`}>
          <CardHeader className="text-center pb-4">
            <div className={`w-16 h-16 mx-auto rounded-full bg-gradient-to-r ${plan.gradient} flex items-center justify-center text-white mb-4`}>
              {plan.icon}
            </div>
            <CardTitle className="text-2xl font-bold text-white">{plan.name}</CardTitle>
            <div className="mt-4 min-h-[90px]">
              {plan.id !== 'free' && discount > 0 && <p className="text-gray-400 line-through">{formatCOP(basePrice)}</p>}
              <span className="text-4xl font-bold text-yellow-400">
                {plan.id === 'free' ? 'GRATIS' : formatCOP(discountedPrice)}
              </span>
              {plan.id !== 'free' && (
                <span className="text-gray-400 ml-1">{period}</span>
              )}
            </div>
            <p className="text-sky-300 font-semibold mt-2">
              <Zap className="w-4 h-4 inline mr-1" />
              {plan.credits} créditos {plan.id !== 'free' ? 'mensuales' : ''}
            </p>
          </CardHeader>
          <CardContent className="space-y-4 flex-grow flex flex-col justify-between">
            <ul className="space-y-3">
              {plan.features.map((feature, featureIndex) => (
                <li key={featureIndex} className="flex items-center text-gray-300">
                  <Check className="w-5 h-5 text-green-400 mr-3 flex-shrink-0" />
                  <span className="text-sm">{feature}</span>
                </li>
              ))}
            </ul>
            <Button
              onClick={() => handlePlanSelect(plan)}
              className={`w-full mt-6 ${
                plan.popular
                  ? 'bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold'
                  : basePrice === 0
                  ? 'bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800 text-white'
                  : 'bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-700 hover:to-sky-600 text-white'
              } transition-all duration-300`}
            >
              {basePrice === 0 ? 'Empezar Gratis' : 'Ver Ofertas'}
            </Button>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  const faqItems = [
    { q: '¿Cómo funcionan los créditos?', a: 'Cada servicio de IA consume créditos. Los créditos de suscripción se renuevan mensualmente. También puedes comprar paquetes de créditos de pago único.' },
    { q: '¿Puedo cambiar de plan?', a: '¡Claro! Puedes cambiar tu plan de suscripción en cualquier momento desde tu panel de usuario.' },
    { q: '¿Qué métodos de pago aceptan?', a: 'Aceptamos pagos seguros a través de Mercado Pago, donde puedes usar tarjetas de crédito, débito y otros métodos locales disponibles en tu país.' },
    { q: '¿Hay algún contrato o permanencia?', a: 'No. Puedes cancelar tu suscripción mensual en cualquier momento sin penalizaciones.' },
  ];

  return (
    <section id="pricing" className="py-20 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Planes Flexibles para Todos
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Elige la opción perfecta para potenciar tu enseñanza con inteligencia artificial.
          </p>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className="text-3xl font-bold text-white text-center mb-4 flex items-center justify-center gap-3">
            <CreditCard className="w-8 h-8 text-sky-400" />
            Planes de Suscripción
          </h3>
          <p className="text-center text-gray-400 mb-6">Créditos que se renuevan cada mes.</p>
          <div className="flex justify-center items-center space-x-4 mb-8">
            <Label htmlFor="billing-cycle-home" className={`font-medium transition-colors ${billingCycle === 'monthly' ? 'text-white' : 'text-gray-400'}`}>
              Pago Mensual
            </Label>
            <Switch
              id="billing-cycle-home"
              checked={billingCycle === 'yearly'}
              onCheckedChange={(checked) => setBillingCycle(checked ? 'yearly' : 'monthly')}
            />
            <Label htmlFor="billing-cycle-home" className={`font-medium transition-colors ${billingCycle === 'yearly' ? 'text-white' : 'text-gray-400'}`}>
              Pago Anual <span className="text-green-400 font-bold">(¡Ahorra más!)</span>
            </Label>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {subscriptionPlans.map((plan, index) => (
              <PlanCard key={plan.id} plan={plan} index={index} />
            ))}
          </div>
        </motion.div>

        <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            viewport={{ once: true }}
            className="mt-20 max-w-4xl mx-auto"
        >
            <h3 className="text-3xl font-bold text-white text-center mb-8 flex items-center justify-center gap-3">
                <HelpCircle className="w-8 h-8 text-yellow-400" />
                Preguntas Frecuentes
            </h3>
            <div className="space-y-4">
                {faqItems.map((item, index) => (
                    <details key={index} className="glass-effect p-4 rounded-lg border border-slate-700/50 group">
                        <summary className="font-semibold text-white list-none flex justify-between items-center cursor-pointer">
                            {item.q}
                            <ChevronDown className="w-5 h-5 transition-transform duration-300 group-open:rotate-180" />
                        </summary>
                        <p className="text-gray-300 mt-2 group-open:animate-fadeIn">{item.a}</p>
                    </details>
                ))}
            </div>
            <p className="text-center mt-8 text-gray-400">¿Tienes más dudas? <Link to="/faq" className="text-sky-400 hover:underline">Visita nuestra página de FAQ</Link> o <a href="https://wa.me/573207303024" target="_blank" rel="noopener noreferrer" className="text-sky-400 hover:underline">contáctanos</a>.</p>
        </motion.div>
      </div>
    </section>
  );
};

export default PricingSection;