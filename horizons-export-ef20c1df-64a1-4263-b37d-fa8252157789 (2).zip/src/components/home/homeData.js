import { Brain, FileText, Camera, Users, Star, TrendingUp, UploadCloud, Share2, Download, Award } from 'lucide-react';

export const featureCards = [
  {
    icon: Brain,
    title: 'Contenido Educativo al Instante',
    description: 'Genera talleres, artículos, tutoriales y más, adaptados a cualquier nivel y asignatura.',
    color: 'from-blue-500 to-sky-400',
    path: '/servicios/talleres-pedagogicos',
    requiresAuth: true
  },
  {
    icon: FileText,
    title: 'Evaluación Inteligente y Presentaciones Dinámicas',
    description: 'Crea presentaciones atractivas y genera exámenes únicos con hojas de respuestas personalizadas para tus estudiantes.',
    color: 'from-purple-500 to-indigo-400',
    path: '/examenes-ai-ocr',
    requiresAuth: true
  },
  {
    icon: Camera,
    title: 'Calificación con OCR',
    description: 'Digitaliza y califica exámenes impresos de forma automática. Este servicio está incluido en tu acceso a Profe IA.',
    color: 'from-pink-500 to-rose-400',
    path: '/examenes-ai-ocr',
    requiresAuth: true
  }
];

export const communityStatsData = (dynamicStats) => [
  { icon: Users, value: dynamicStats.totalUsers, label: 'Docentes Impactados' },
  { icon: Star, value: dynamicStats.satisfaction, label: 'Satisfacción del Usuario' },
  { icon: TrendingUp, value: dynamicStats.totalServices, label: 'Nuevas Funciones Anuales' },
];

export const blogHighlights = [
  { icon: UploadCloud, title: 'Sube tus Recursos', description: 'Comparte tus materiales educativos con una comunidad global.' },
  { icon: Download, title: 'Descarga Material', description: 'Accede a una vasta biblioteca de recursos listos para usar.' },
  { icon: Share2, title: 'Comparte en Redes', description: 'Difunde conocimiento e inspira a otros educadores fácilmente.' },
];

export const innovationPoints = [
  { title: 'Investigación y Desarrollo', description: 'Exploramos continuamente nuevas tecnologías para mejorar la enseñanza.'},
  { title: 'Feedback y Mejoras', description: 'Tu opinión nos ayuda a evolucionar y adaptarnos a tus necesidades.'},
  { title: 'Expansión de Capacidades', description: 'Añadimos constantemente nuevas herramientas y funciones innovadoras.'},
];

export const pageUrl = "https://profe.io";
export const shareTitle = "Profe IA: ¡El Futuro de la Enseñanza en tus Manos!";

export const educationalOrgSchema = {
  "@context": "https://schema.org",
  "@type": "EducationalOrganization",
  "name": "Profe IA",
  "url": pageUrl,
  "logo": `${pageUrl}/assets/logo.svg`,
  "description": "Descubre Profe AI, la plataforma educativa que transforma tu manera de enseñar con herramientas de inteligencia artificial avanzadas.",
  "contactPoint": {
    "@type": "ContactPoint",
    "contactType": "customer support",
    "email": "soporte@profe.io"
  }
};

export const blogPosts = [];