import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Sparkles, Zap, ArrowRight, Brain } from 'lucide-react';
import { useTokens } from '@/contexts/TokenContext';

const PersonalizedWelcome = ({ profile }) => {
  const navigate = useNavigate();
  const { tokens } = useTokens();
  
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-blue-500/30 rounded-xl p-4 mb-8 backdrop-blur-sm"
    >
      <div className="flex items-center gap-3">
        <Sparkles className="w-6 h-6 text-yellow-400" />
        <div>
          <h3 className="text-lg font-semibold text-white">
            ¡Bienvenido de vuelta, {profile?.full_name || 'Profesor'}!
          </h3>
          <p className="text-gray-300 text-sm">
            Tienes {tokens || 0} créditos disponibles. ¡Continúa creando contenido increíble!
          </p>
        </div>
        <Button 
          onClick={() => navigate('/dashboard')}
          className="ml-auto bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
        >
          Ir a la página
        </Button>
      </div>
    </motion.div>
  );
};

const HeroSection = ({ user, profile, handleCTA }) => {
  const navigate = useNavigate();

  return (
    <header className="relative pt-28 pb-20 md:pt-40 md:pb-32 px-4 hero-pattern overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-blue-900/10 to-black/30"></div>
      <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-blue-600/20 rounded-full blur-3xl animate-pulse-slow opacity-50"></div>
      <div className="absolute bottom-1/4 right-1/4 w-72 h-72 bg-purple-600/20 rounded-full blur-3xl animate-pulse-slow animation-delay-4000 opacity-50"></div>
      
      <div className="relative z-10 max-w-7xl mx-auto">
        {user && profile && <PersonalizedWelcome profile={profile} />}
        
        <div className="grid md:grid-cols-2 gap-8 items-center">
            <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                className="text-center md:text-left"
            >
                <h1 className="text-5xl md:text-7xl font-extrabold tracking-tighter mb-6">
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-sky-300 to-indigo-400">Profe IA:</span>
                    <span className="block text-white">¡El Futuro de la Enseñanza en tus Manos!</span>
                </h1>
                <p className="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto md:mx-0 mb-10 leading-relaxed">
                    Descubre Profe AI, la plataforma educativa que transforma tu manera de enseñar con herramientas de inteligencia artificial avanzadas. Prepárate para innovar, personalizar y potenciar el aprendizaje de tus estudiantes como nunca antes.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                    {!user ? (
                        <>
                        <Button size="lg" className="glow-effect bg-gradient-to-r from-blue-600 via-sky-500 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-xl text-lg px-8 py-6 rounded-xl" onClick={() => handleCTA('/registro', false)}>
                            Comenzar Ahora <Zap className="ml-2 w-5 h-5" />
                        </Button>
                        <Button size="lg" variant="outline" className="border-sky-400/50 text-sky-300 hover:bg-sky-500/10 hover:text-white text-lg px-8 py-6 rounded-xl" onClick={() => document.getElementById('features').scrollIntoView({ behavior: 'smooth' })}>
                            Explorar Funciones <ArrowRight className="ml-2 w-5 h-5" />
                        </Button>
                        </>
                    ) : (
                        <>
                        <Button size="lg" className="glow-effect bg-gradient-to-r from-green-600 via-emerald-500 to-teal-600 hover:from-green-700 hover:to-teal-700 text-white shadow-xl text-lg px-8 py-6 rounded-xl" onClick={() => navigate('/servicios')}>
                            Usar Herramientas IA <Brain className="ml-2 w-5 h-5" />
                        </Button>
                        <Button size="lg" variant="outline" className="border-purple-400/50 text-purple-300 hover:bg-purple-500/10 hover:text-white text-lg px-8 py-6 rounded-xl" onClick={() => navigate('/dashboard')}>
                            Mi página <ArrowRight className="ml-2 w-5 h-5" />
                        </Button>
                        </>
                    )}
                </div>
            </motion.div>
            <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="hidden md:flex justify-center"
            >
                <img src="https://storage.googleapis.com/hostinger-horizons-assets-prod/ef20c1df-64a1-4263-b37d-fa8252157789/9f657bcc7fc862261dd737580a812d2e.png" alt="Docente utilizando interfaz de IA para planificar clases" className="max-w-md w-full rounded-2xl shadow-2xl shadow-blue-500/20" />
            </motion.div>
        </div>
      </div>
    </header>
  );
};

export default HeroSection;