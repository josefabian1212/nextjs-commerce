
import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Zap, ShieldCheck } from 'lucide-react';
import FeaturesGrid from '@/components/home/FeaturesGrid';
import TestimonialsSection from '@/components/home/TestimonialsSection';

const HomeSections = () => {
  const stats = [
    { value: '98%', label: 'Satisfacción Docente' },
    { value: '10,000+', label: 'Clases Generadas' },
    { value: '75%', label: 'Reducción de Tiempo' },
  ];

  const benefits = [
    { title: 'Optimización de Tiempo', description: 'Dedica más tiempo a tus estudiantes y menos a la planificación.', icon: <Zap className="w-8 h-8 text-yellow-400" /> },
    { title: 'Contenido Personalizado', description: 'Genera material educativo adaptado a las necesidades específicas de tu aula.', icon: <CheckCircle className="w-8 h-8 text-green-400" /> },
    { title: 'Innovación Educativa', description: 'Incorpora la última tecnología de IA para enriquecer tus métodos de enseñanza.', icon: <ShieldCheck className="w-8 h-8 text-blue-400" /> },
  ];

  return (
    <>
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-4xl md:text-5xl font-bold text-white"
            >
              Transforma tu <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-purple-500">Enseñanza</span>
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
              className="text-lg text-gray-400 mt-4 max-w-3xl mx-auto"
            >
              Descubre cómo Profe IA puede ayudarte a optimizar tu tiempo, personalizar el aprendizaje y fomentar la creatividad en el aula.
            </motion.p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 text-center mb-20">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                viewport={{ once: true }}
                className="glass-effect p-6 rounded-xl"
              >
                <p className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">{stat.value}</p>
                <p className="text-gray-300 mt-2">{stat.label}</p>
              </motion.div>
            ))}
          </div>

          <div className="grid md:grid-cols-3 gap-10">
            {benefits.map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className="flex justify-center mb-4">{benefit.icon}</div>
                <h3 className="text-xl font-bold text-white mb-2">{benefit.title}</h3>
                <p className="text-gray-400">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      <FeaturesGrid />
      <TestimonialsSection />
    </>
  );
};

export default HomeSections;
