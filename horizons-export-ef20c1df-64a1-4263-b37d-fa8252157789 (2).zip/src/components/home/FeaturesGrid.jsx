import React from 'react';
import { motion } from 'framer-motion';
import { Zap, BookOpen, ShieldCheck, BarChart, Settings, Users } from 'lucide-react';

const features = [
  {
    icon: <Zap className="w-10 h-10 text-yellow-400" />,
    title: 'Generación Rápida',
    description: 'Crea planes de clase, exámenes y talleres en segundos, no en horas.',
  },
  {
    icon: <BookOpen className="w-10 h-10 text-sky-400" />,
    title: 'Contenido Personalizado',
    description: 'Adapta el material a las necesidades específicas de tu aula y estudiantes.',
  },
  {
    icon: <ShieldCheck className="w-10 h-10 text-green-400" />,
    title: 'Calidad Pedagógica',
    description: 'Recursos alineados con estándares educativos y mejores prácticas.',
  },
  {
    icon: <BarChart className="w-10 h-10 text-purple-400" />,
    title: 'Evaluación Inteligente',
    description: 'Califica exámenes escaneados con OCR y analiza los resultados.',
  },
  {
    icon: <Settings className="w-10 h-10 text-orange-400" />,
    title: 'Herramientas Versátiles',
    description: 'Desde análisis de texto hasta la creación de proyectos educativos completos.',
  },
  {
    icon: <Users className="w-10 h-10 text-pink-400" />,
    title: 'Enfoque Colaborativo',
    description: 'Fomenta el aprendizaje cooperativo y el pensamiento crítico con actividades diseñadas para ello.',
  },
];

const FeaturesGrid = () => {
  return (
    <section className="py-20 bg-slate-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-bold text-white"
          >
            Todo lo que necesitas, en un solo lugar
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="text-lg text-gray-400 mt-4 max-w-3xl mx-auto"
          >
            Nuestra plataforma está diseñada para ser tu copiloto en la enseñanza, dándote las herramientas para innovar y optimizar tu trabajo diario.
          </motion.p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
              viewport={{ once: true }}
              className="glass-effect p-8 rounded-xl flex flex-col items-center text-center"
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-2xl font-bold text-white mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesGrid;