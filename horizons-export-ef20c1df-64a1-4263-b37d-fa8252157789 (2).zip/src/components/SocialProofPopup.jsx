import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, X } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const SocialProofPopup = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [notification, setNotification] = useState(null);
  const [remainingSlots, setRemainingSlots] = useState(10);
  const { user } = useAuth();

  const countries = ['México', 'Colombia', 'Argentina', 'Chile', 'Perú', 'Ecuador', 'España'];
  const names = ['Ana', 'Carlos', 'Sofía', 'Javier', 'Lucía', 'Mateo', 'Valentina'];

  const generateNotification = () => {
    const randomName = names[Math.floor(Math.random() * names.length)];
    const randomCountry = countries[Math.floor(Math.random() * countries.length)];
    return {
      name: randomName,
      country: randomCountry,
      message: `¡${randomName} de ${randomCountry} acaba de registrarse!`,
    };
  };

  useEffect(() => {
    if (user) {
      setIsVisible(false);
      return;
    }

    const interval = setInterval(() => {
      setIsVisible(false);
      setTimeout(() => {
        setNotification(generateNotification());
        setIsVisible(true);
      }, 500);
    }, 12000);

    return () => clearInterval(interval);
  }, [user]);

  useEffect(() => {
    if (user) return;
    const slotsInterval = setInterval(() => {
      setRemainingSlots(prev => (prev > 3 ? prev - 1 : 10));
    }, 25000);
    return () => clearInterval(slotsInterval);
  }, [user]);

  if (!notification || user) return null;

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.3 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, scale: 0.5, transition: { duration: 0.2 } }}
          className="fixed bottom-5 left-5 z-50"
        >
          <div className="glass-effect rounded-xl shadow-lg shadow-purple-500/20 border border-purple-400/50 p-4 max-w-sm w-full">
            <button
              onClick={() => setIsVisible(false)}
              className="absolute top-2 right-2 text-gray-400 hover:text-white transition-colors"
            >
              <X size={18} />
            </button>
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-purple-600 to-indigo-600 rounded-full flex items-center justify-center text-white shadow-md">
                <Zap size={24} />
              </div>
              <div>
                <p className="font-bold text-white">{notification.message}</p>
                <div className="mt-2">
                  <p className="text-sm text-yellow-300 font-semibold">¡Quedan {remainingSlots}/100 cupos!</p>
                  <div className="w-full bg-gray-700 rounded-full h-2.5 mt-1">
                    <div
                      className="bg-gradient-to-r from-yellow-400 to-orange-500 h-2.5 rounded-full transition-all duration-500"
                      style={{ width: `${100 - remainingSlots}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default SocialProofPopup;