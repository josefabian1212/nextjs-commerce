import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const Logo = ({ className = 'h-12 md:h-16' }) => {
  const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/ef20c1df-64a1-4263-b37d-fa8252157789/f3d3ab4e3a0accd3aad79c4040a4b472.png";
  return (
    <Link to="/" className="inline-block group" aria-label="Página de inicio de Profe IA">
      <motion.div
        whileHover={{ scale: 1.05, rotate: 5 }}
        whileTap={{ scale: 0.95 }}
        transition={{ type: 'spring', stiffness: 400, damping: 10 }}
      >
        <img src={logoUrl} alt="Profe IA Logo" className={`${className} w-auto object-contain`} />
      </motion.div>
    </Link>
  );
};

export default Logo;