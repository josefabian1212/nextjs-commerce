import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import AuthModal from '@/components/AuthModal';

const AuthModalTrigger = ({ children, actionRequiresAuth = true }) => {
  const { user } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);

  const handleInteraction = (e, originalOnClick) => {
    if (actionRequiresAuth && !user) {
      e.preventDefault();
      e.stopPropagation();
      setShowAuthModal(true);
    } else if (originalOnClick) {
      originalOnClick(e);
    }
  };

  const cloneChildrenWithAuthCheck = (element) => {
    if (!React.isValidElement(element)) {
      return element;
    }

    const originalOnClick = element.props.onClick;
    
    const newProps = {
      ...element.props,
      onClick: (e) => handleInteraction(e, originalOnClick),
    };

    if (element.props.children) {
      newProps.children = React.Children.map(element.props.children, cloneChildrenWithAuthCheck);
    }
    
    return React.cloneElement(element, newProps);
  };

  return (
    <>
      {React.Children.map(children, cloneChildrenWithAuthCheck)}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </>
  );
};

export default AuthModalTrigger;