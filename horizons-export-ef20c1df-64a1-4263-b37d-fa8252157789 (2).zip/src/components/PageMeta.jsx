import React from 'react';
import { Helmet } from 'react-helmet-async';

const PageMeta = ({ title, description, keywords, imageUrl, canonicalUrl }) => {
  const defaultTitle = 'Profe IA - Generador de Clases y Exámenes con Inteligencia Artificial';
  const defaultDescription = '🚀 Genera clases, exámenes y contenido educativo automáticamente con IA. Plataforma educativa #1 para docentes. ✅ Gratis ✅ Fácil ✅ Resultados instantáneos';
  const defaultKeywords = 'generador de clases con IA, crear exámenes automáticamente, plataforma educativa inteligencia artificial, herramientas docentes IA, planificación clases automática, evaluación educativa IA, Profe IA';
  const defaultImageUrl = 'https://storage.googleapis.com/hostinger-horizons-assets-prod/ef20c1df-64a1-4263-b37d-fa8252157789/a676666c0f9c77182850dd05caecae24.jpg';
  const siteUrl = canonicalUrl || 'https://profe.io';

  const metaTitle = title ? `${title} | Profe IA` : defaultTitle;
  const metaDescription = description || defaultDescription;
  const metaKeywords = keywords ? `${keywords}, ${defaultKeywords}` : defaultKeywords;
  const metaImageUrl = imageUrl || defaultImageUrl;

  return (
    <Helmet>
      <title>{metaTitle}</title>
      <meta name="description" content={metaDescription} />
      <meta name="keywords" content={metaKeywords} />
      <link rel="canonical" href={siteUrl} />

      <meta property="og:type" content="website" />
      <meta property="og:url" content={siteUrl} />
      <meta property="og:title" content={metaTitle} />
      <meta property="og:description" content={metaDescription} />
      <meta property="og:image" content={metaImageUrl} />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="630" />
      <meta property="og:site_name" content="Profe IA" />
      <meta property="og:locale" content="es_ES" />

      <meta name="twitter:card" content="summary_large_image" />
      <meta property="twitter:url" content={siteUrl} />
      <meta property="twitter:title" content={metaTitle} />
      <meta property="twitter:description" content={metaDescription} />
      <meta property="twitter:image" content={metaImageUrl} />
      <meta name="twitter:site" content="@feskawsay" />
      <meta name="twitter:creator" content="@feskawsay" />
    </Helmet>
  );
};

export default PageMeta;