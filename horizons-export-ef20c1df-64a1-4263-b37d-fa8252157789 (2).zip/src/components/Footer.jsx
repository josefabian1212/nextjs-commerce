import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Youtube, MessageCircle } from 'lucide-react';
import Logo from '@/components/Logo';
import { useAuth } from '@/contexts/AuthContext';
import TiktokIcon from '@/components/TiktokIcon';

const Footer = () => {
  const { user, profile } = useAuth();
  const isAdmin = profile?.is_admin;
  
  const sections = {
    'Soluciones IA': [
      { name: 'Generador de Talleres', href: '/servicios/talleres-pedagogicos' },
      { name: 'Exámenes con OCR', href: '/examenes-ai-ocr' },
      { name: 'Análisis Cognitivo', href: '/servicios/analisis-cognitivo-ia' },
      { name: 'Ver todos los servicios', href: '/servicios' },
    ],
    'Empresa': [
      { name: 'Sobre Nosotros', href: '/sobre-nosotros' },
      { name: 'Blog Educativo', href: '/blog' },
      { name: 'Ofertas', href: '/ofertas' },
    ],
    'Soporte': [
      { name: 'Preguntas Frecuentes (FAQ)', href: '/faq' },
      { name: 'Contacto', href: 'mailto:soporte@profe.io' },
      { name: 'Reportar un problema', href: 'mailto:soporte@profe.io' },
    ],
    'Legal': [
      { name: 'Términos de Servicio', href: '/terms-of-service' },
      { name: 'Política de Privacidad', href: '/privacy-policy' },
    ],
  };

  const socialLinks = [
    { name: 'Facebook', href: 'https://www.facebook.com/feskawsay', icon: Facebook },
    { name: 'WhatsApp', href: 'https://wa.me/3114123000', icon: MessageCircle },
    { name: 'Instagram', href: 'https://www.instagram.com/feskawsay/', icon: Instagram },
    { name: 'YouTube', href: 'https://www.youtube.com/@feskawsay', icon: Youtube },
    { name: 'TikTok', href: 'https://www.tiktok.com/@feskawsay', icon: TiktokIcon },
  ];
  
  return (
    <footer className="bg-slate-900/50 border-t border-slate-700/50">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="xl:grid xl:grid-cols-3 xl:gap-8">
          <div className="space-y-8 xl:col-span-1">
            <Logo className="h-16"/>
            <p className="text-gray-400 text-sm">
              Revolucionando la educación con inteligencia artificial. Empoderamos a los docentes para crear experiencias de aprendizaje inolvidables.
            </p>
            <div className="flex space-x-6">
              {socialLinks.map((item) => (
                <a key={item.name} href={item.href} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-sky-400">
                  <span className="sr-only">{item.name}</span>
                  <item.icon className="h-6 w-6" aria-hidden="true" />
                </a>
              ))}
            </div>
          </div>
          <div className="mt-12 grid grid-cols-2 gap-8 xl:mt-0 xl:col-span-2">
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <p className="text-sm font-semibold text-white tracking-wider uppercase">Soluciones IA</p>
                <ul className="mt-4 space-y-4">
                  {sections['Soluciones IA'].map((item) => (
                    <li key={item.name}>
                      <Link to={item.href} className="text-base text-gray-400 hover:text-sky-300">
                        {item.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="mt-12 md:mt-0">
                <p className="text-sm font-semibold text-white tracking-wider uppercase">Empresa</p>
                <ul className="mt-4 space-y-4">
                  {sections['Empresa'].map((item) => (
                    <li key={item.name}>
                       {item.href.startsWith('/') ? (
                         <Link to={item.href} className="text-base text-gray-400 hover:text-sky-300">
                           {item.name}
                         </Link>
                       ) : (
                         <a href={item.href} className="text-base text-gray-400 hover:text-sky-300">
                           {item.name}
                         </a>
                       )}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <p className="text-sm font-semibold text-white tracking-wider uppercase">Soporte</p>
                <ul className="mt-4 space-y-4">
                  {sections['Soporte'].map((item) => (
                    <li key={item.name}>
                      {item.href.startsWith('mailto:') ? (
                         <a href={item.href} className="text-base text-gray-400 hover:text-sky-300">
                           {item.name}
                         </a>
                      ) : (
                         <Link to={item.href} className="text-base text-gray-400 hover:text-sky-300">
                           {item.name}
                         </Link>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="mt-12 md:mt-0">
                <p className="text-sm font-semibold text-white tracking-wider uppercase">Legal</p>
                <ul className="mt-4 space-y-4">
                  {sections['Legal'].map((item) => (
                    <li key={item.name}>
                      <Link to={item.href} className="text-base text-gray-400 hover:text-sky-300">
                        {item.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-12 border-t border-slate-700 pt-8 flex flex-col sm:flex-row justify-between items-center">
          <p className="text-base text-gray-400">&copy; {new Date().getFullYear()} Profe IA. Todos los derechos reservados.</p>
          {isAdmin && (
            <Link to="/admin-panel" className="text-base text-gray-400 hover:text-sky-300 transition-colors mt-4 sm:mt-0">
                Panel de Administración
            </Link>
          )}
        </div>
      </div>
    </footer>
  );
};

export default Footer;