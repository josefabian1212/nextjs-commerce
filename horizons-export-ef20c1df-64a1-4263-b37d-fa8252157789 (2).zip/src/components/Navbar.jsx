import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import AuthModal from '@/components/AuthModal';
import Logo from '@/components/Logo';
import { 
  Menu, 
  X, 
  User, 
  LogOut, 
  Home as HomeIcon,
  Briefcase,
  ScanEye,
  Newspaper,
  DollarSign
} from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const { user, profile, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/');
    setIsOpen(false);
  };

  const navItems = [
    { name: 'Inicio', path: '/', icon: HomeIcon, requiresAuth: false },
    { name: 'Servicios IA', path: '/servicios', icon: Briefcase, requiresAuth: true },
    { name: 'Exámenes AI-OCR', path: '/examenes-ai-ocr', icon: ScanEye, requiresAuth: true },
    { name: 'Blog', path: '/blog', icon: Newspaper, requiresAuth: false },
    { name: 'Ofertas', path: '/ofertas', icon: DollarSign, requiresAuth: false },
  ];

  const handleNavClick = (e, path, requiresAuth) => {
    if (requiresAuth && !user) {
      e.preventDefault();
      setShowAuthModal(true);
      setIsOpen(false);
    } else {
      if (path.includes('#')) {
        const targetId = path.substring(path.indexOf('#') + 1);
        
        if (location.pathname === '/' && targetId) {
            e.preventDefault();
            document.getElementById(targetId)?.scrollIntoView({ behavior: 'smooth' });
        } else if (targetId) {
            navigate(`/#${targetId}`); 
        } else {
            navigate(path.split('#')[0]);
        }
      } else {
        navigate(path);
      }
      setIsOpen(false);
    }
  };


  return (
    <>
      <nav className="fixed top-0 w-full z-50 glass-effect border-b border-slate-700/50 bg-slate-950/70 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div onClick={() => setIsOpen(false)}>
              <Logo className="h-12 md:h-16" />
            </div>

            <div className="hidden md:flex items-center space-x-6">
              {navItems.map((item) => {
                if (item.requiresAuth && !user && item.path !== '/#pricing') return null;
                return (
                    <Link
                    key={item.path}
                    to={item.path}
                    onClick={(e) => handleNavClick(e, item.path, item.requiresAuth)}
                    className={`text-sm font-medium transition-colors hover:text-sky-300 ${
                        (location.pathname === item.path.split('#')[0] && (!item.path.includes('#') || location.hash === item.path.substring(item.path.indexOf('#'))))
                        ? 'text-sky-300'
                        : 'text-gray-300'
                    }`}
                    >
                    {item.name}
                    </Link>
                )
              })}
            </div>

            <div className="hidden md:flex items-center space-x-4">
              {user ? (
                <>
                  <div className="flex items-center space-x-2">
                    <Link to="/dashboard" onClick={() => setIsOpen(false)}>
                      <Button variant="ghost" size="sm" className="text-gray-300 hover:bg-slate-700/50 hover:text-sky-300">
                        <User className="w-4 h-4 mr-2" />
                        {profile?.full_name || user.email}
                      </Button>
                    </Link>
                    <Button variant="ghost" size="icon" onClick={handleLogout} className="text-gray-300 hover:bg-slate-700/50 hover:text-red-400">
                      <LogOut className="w-5 h-5" />
                    </Button>
                  </div>
                </>
              ) : (
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="sm" className="text-gray-300 hover:bg-slate-700/50 hover:text-sky-300" onClick={() => { setShowAuthModal(true); setIsOpen(false); }}>Iniciar Sesión</Button>
                  <Button size="sm" className="bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-700 hover:to-sky-600 text-white" onClick={() => { navigate('/registro') }}>Registrarse</Button>
                </div>
              )}
            </div>

            <div className="md:hidden">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsOpen(!isOpen)}
                className="text-gray-300 hover:text-sky-300"
              >
                {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </Button>
            </div>
          </div>
        </div>

        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden glass-effect border-t border-slate-700/50 bg-slate-950/90 backdrop-blur-lg"
          >
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navItems.map((item) => {
                  if (item.requiresAuth && !user) return null;
                  return (
                    <Link
                        key={item.path}
                        to={item.path}
                        onClick={(e) => handleNavClick(e, item.path, item.requiresAuth)}
                        className={`block px-3 py-2 text-base font-medium transition-colors ${
                        (location.pathname === item.path.split('#')[0] && (!item.path.includes('#') || location.hash === item.path.substring(item.path.indexOf('#'))))
                            ? 'text-sky-300 bg-blue-500/20'
                            : 'text-gray-300 hover:text-sky-300 hover:bg-blue-500/10'
                        } rounded-md`}
                    >
                        <div className="flex items-center space-x-3">
                        <item.icon className="w-5 h-5" />
                        <span>{item.name}</span>
                        </div>
                    </Link>
                  )
              })}
              
              {user ? (
                <div className="border-t border-slate-700/50 pt-4 mt-4">
                  <Link
                    to="/dashboard"
                    className="block px-3 py-2 text-base font-medium text-gray-300 hover:text-sky-300 hover:bg-blue-500/10 rounded-md"
                    onClick={() => setIsOpen(false)}
                  >
                    <div className="flex items-center space-x-3">
                      <User className="w-5 h-5" />
                      <span>Ir al panel de usuario</span>
                    </div>
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="block w-full text-left px-3 py-2 text-base font-medium text-gray-300 hover:text-red-400 hover:bg-red-500/10 rounded-md"
                  >
                    <div className="flex items-center space-x-3">
                      <LogOut className="w-5 h-5" />
                      <span>Cerrar Sesión</span>
                    </div>
                  </button>
                </div>
              ) : (
                <div className="border-t border-slate-700/50 pt-4 mt-4 space-y-2">
                  <Button variant="ghost" className="w-full justify-start" onClick={() => { setShowAuthModal(true); setIsOpen(false); }}>Iniciar Sesión</Button>
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-sky-500 text-white" onClick={() => { navigate('/registro'); setIsOpen(false); }}>Registrarse</Button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </nav>
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </>
  );
};

export default Navbar;