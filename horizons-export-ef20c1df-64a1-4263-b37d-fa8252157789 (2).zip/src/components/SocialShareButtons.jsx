import React from 'react';
import { Facebook, Twitter, Linkedin, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const SocialShareButtons = ({ title, url, imageUrl }) => {
  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);
  
  const shareLinks = {
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
    twitter: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`,
    linkedin: `https://www.linkedin.com/shareArticle?mini=true&url=${encodedUrl}&title=${encodedTitle}`,
    whatsapp: `https://api.whatsapp.com/send?text=${encodedTitle}%20${encodedUrl}`
  };

  const socialPlatforms = [
    { name: 'Facebook', icon: Facebook, href: shareLinks.facebook, color: 'bg-blue-600 hover:bg-blue-700' },
    { name: 'Twitter', icon: Twitter, href: shareLinks.twitter, color: 'bg-sky-500 hover:bg-sky-600' },
    { name: 'LinkedIn', icon: Linkedin, href: shareLinks.linkedin, color: 'bg-sky-700 hover:bg-sky-800' },
    { name: 'WhatsApp', icon: MessageCircle, href: shareLinks.whatsapp, color: 'bg-green-500 hover:bg-green-600' },
  ];

  return (
    <div className="flex flex-wrap items-center justify-center gap-4">
        <p className="text-white font-semibold text-sm mr-2">Compartir en:</p>
      {socialPlatforms.map((platform) => (
        <a 
          key={platform.name}
          href={platform.href}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={`Share on ${platform.name}`}
        >
          <Button size="icon" className={`${platform.color} text-white rounded-full`}>
            <platform.icon className="w-5 h-5" />
          </Button>
        </a>
      ))}
    </div>
  );
};

export default SocialShareButtons;