import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Shield, Database, UserCheck, Cookie, Mail, Share2, Bot } from 'lucide-react';

const PrivacyPolicy = () => {
  const sections = [
    {
      icon: Database,
      title: '1. Información que Recopilamos',
      content: 'Recopilamos información que nos proporcionas directamente, como tu nombre y correo electrónico al registrarte. También recopilamos datos de uso, como los servicios que utilizas y el contenido que generas, para mejorar nuestra plataforma. Los datos de pago son procesados por proveedores externos seguros como Stripe y no se almacenan en nuestros servidores.'
    },
    {
      icon: Bot,
      title: '2. Cómo Usamos tu Información',
      content: 'Utilizamos tu información para operar, mantener y mejorar nuestros servicios, personalizar tu experiencia, comunicarnos contigo y procesar transacciones. El contenido que proporcionas para los servicios de IA (como temas de clase o preguntas de examen) se envía a nuestros socios de IA (como OpenAI) únicamente para generar la respuesta solicitada y no se utiliza para entrenar sus modelos.'
    },
    {
      icon: Share2,
      title: '3. Cómo Compartimos tu Información',
      content: 'No vendemos tus datos personales. Podemos compartir información con proveedores de servicios de confianza que nos ayudan a operar la plataforma (como proveedores de nube y procesadores de pago) y con socios de IA para proporcionar las funcionalidades principales. Cualquier intercambio se realiza bajo estrictos acuerdos de confidencialidad.'
    },
    {
      icon: Shield,
      title: '4. Seguridad de los Datos',
      content: 'Implementamos medidas de seguridad técnicas y organizativas para proteger tu información contra el acceso no autorizado, la alteración, la divulgación o la destrucción. Esto incluye encriptación, controles de acceso y auditorías de seguridad regulares.'
    },
    {
      icon: Cookie,
      title: '5. Cookies y Tecnologías Similares',
      content: 'Utilizamos cookies para el funcionamiento esencial del sitio, como mantener tu sesión iniciada y recordar tus preferencias. No utilizamos cookies de seguimiento con fines publicitarios de terceros. Puedes gestionar las cookies a través de la configuración de tu navegador.'
    },
    {
      icon: UserCheck,
      title: '6. Tus Derechos y Opciones',
      content: 'Tienes derecho a acceder, corregir o eliminar tus datos personales. Puedes gestionar la información de tu perfil en el panel de control. Para solicitudes de eliminación de datos u otras consultas sobre privacidad, por favor contáctanos.'
    }
  ];

  return (
    <div className="min-h-screen pt-24 pb-12 bg-gradient-to-br from-slate-950 via-gray-900 to-slate-950 text-gray-200 hero-pattern">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="text-center mb-12"
        >
          <Shield className="w-20 h-20 text-blue-400 mx-auto mb-6 animate-pulse-slow" />
          <h1 className="text-5xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-sky-300 to-indigo-400 mb-4">
            Política de Privacidad
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Última actualización: 20 de junio de 2025. Tu confianza es nuestra prioridad.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
        >
          <Card className="glass-effect shadow-2xl border border-blue-800/50">
            <CardHeader>
              <CardTitle className="text-2xl text-white">Nuestro Compromiso con tu Privacidad</CardTitle>
              <CardDescription className="text-gray-300">En Profe IA, nos tomamos muy en serio la protección de tus datos. Esta política explica qué información recopilamos y cómo la usamos para ofrecerte una experiencia segura y eficaz.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8 text-gray-300 leading-relaxed">
              {sections.map((section, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.4 + index * 0.15 }}
                  className="flex items-start space-x-4"
                >
                  <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-blue-900/50 flex items-center justify-center border border-blue-700/50">
                    <section.icon className="w-6 h-6 text-blue-400" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-2">{section.title}</h3>
                    <p className="text-gray-400">{section.content}</p>
                  </div>
                </motion.div>
              ))}
              <div className="border-t border-blue-800/50 pt-6 mt-8 text-center">
                <p className="mb-4 text-lg">¿Tienes alguna pregunta?</p>
                <p className="text-gray-400 mb-4">Si tienes dudas sobre nuestra política de privacidad, no dudes en contactarnos.</p>
                <a href="mailto:privacidad@profeia.com" className="inline-flex items-center justify-center px-6 py-3 font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors">
                  <Mail className="w-5 h-5 mr-2" /> privacidad@profeia.com
                </a>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;