import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { Mail, RefreshCw, Send } from 'lucide-react';

const AwaitingVerification = () => {
  const [resending, setResending] = useState(false);
  const { sendVerificationEmail, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const userEmail = location.state?.email;

  useEffect(() => {
    if (!userEmail) {
      navigate('/register');
    }
  }, [userEmail, navigate]);

  const handleResendEmail = async () => {
    setResending(true);
    await sendVerificationEmail();
    setResending(false);
  };

  return (
    <div className="min-h-screen pt-28 md:pt-32 pb-12 flex items-center justify-center px-4 hero-pattern">
      <div className="w-full max-w-lg">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <Card className="glass-effect glow-effect">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-sky-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Send className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-3xl font-bold text-white">¡Un último paso!</CardTitle>
              <CardDescription className="text-gray-300 mt-2 text-lg">
                Confirma tu cuenta para empezar a revolucionar la educación.
              </CardDescription>
            </CardHeader>
            
            <CardContent className="text-center">
              <p className="text-gray-300 mb-6 leading-relaxed">
                Hemos enviado un enlace de verificación a:
                <br />
                <span className="text-sky-400 font-semibold break-words">{userEmail}</span>
                <br />
                Por favor, haz clic en ese enlace para activar tu cuenta.
              </p>
              <div className="bg-slate-800/50 border border-slate-700 p-4 rounded-lg mb-6">
                 <p className="text-sm text-gray-400">Si no encuentras el correo, asegúrate de revisar tu carpeta de correo no deseado (spam).</p>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button 
                  onClick={handleResendEmail}
                  disabled={resending || loading}
                  className="w-full sm:w-auto glow-effect bg-gradient-to-r from-blue-600 to-sky-500"
                >
                  {resending ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  ) : (
                    <RefreshCw className="w-4 h-4 mr-2" />
                  )}
                  {resending ? 'Reenviando...' : 'Reenviar Email'}
                </Button>
                 <Link to="/login">
                  <Button variant="outline" className="w-full sm:w-auto border-sky-400/50 text-sky-300 hover:bg-sky-500/10 hover:text-white">
                    Ya lo verifiqué, ¡iniciar sesión!
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default AwaitingVerification;