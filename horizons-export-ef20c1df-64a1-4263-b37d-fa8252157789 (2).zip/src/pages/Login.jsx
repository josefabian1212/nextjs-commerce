import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { Mail, Lock, ArrowRight } from 'lucide-react';
import Logo from '@/components/Logo';
import GoogleIcon from '@/components/GoogleIcon';

const servicesPromise = import('@/pages/Services');

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login, signInWithGoogle } = useAuth();
  const navigate = useNavigate();

  const handleMouseEnter = () => {
    servicesPromise.catch(err => console.error("Failed to prefetch Services component", err));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    const result = await login(email, password);
    
    if (result.success) {
      // Navigation is now handled by ProtectedRoute based on `is_onboarded`
      // navigate('/servicios', { replace: true });
    }
    
    setLoading(false);
  };

  const handleGoogleSignIn = async () => {
    setLoading(true);
    await signInWithGoogle();
    // The AuthProvider will handle navigation after successful OAuth login
  };

  return (
    <div className="min-h-screen pt-28 md:pt-32 pb-12 flex items-center justify-center px-4 hero-pattern">
      <div className="w-full max-w-md">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <Card className="glass-effect glow-effect">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <Logo className="h-20" />
              </div>
              <CardTitle className="text-2xl text-white">Iniciar Sesión en Profe IA</CardTitle>
              <CardDescription className="text-gray-300">
                ¡Qué bueno verte de nuevo!
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <Button variant="outline" className="w-full bg-white text-slate-700 hover:bg-slate-100 mb-4 text-base py-6" onClick={handleGoogleSignIn} disabled={loading} onMouseEnter={handleMouseEnter}>
                <GoogleIcon className="mr-3 h-6 w-6" />
                Continuar con Google
              </Button>
              
              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-slate-600" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-slate-800/80 px-2 text-slate-400 backdrop-blur-sm">O inicia con tu email</span>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4" onMouseEnter={handleMouseEnter}>
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-white">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="tu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10 glass-effect border-white/20"
                      required
                      disabled={loading}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-white">Contraseña</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 glass-effect border-white/20"
                      required
                      disabled={loading}
                    />
                  </div>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full glow-effect bg-gradient-to-r from-blue-600 to-sky-500" 
                  disabled={loading}
                >
                  {loading ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  ) : (
                    <ArrowRight className="w-4 h-4 mr-2" />
                  )}
                  {loading ? 'Iniciando sesión...' : 'Iniciar Sesión'}
                </Button>
              </form>

              <div className="mt-6 text-center">
                <p className="text-sm text-gray-400">
                  ¿No tienes cuenta?{' '}
                  <Link to="/registro" className="text-sky-400 hover:text-sky-300 font-medium underline" onMouseEnter={handleMouseEnter}>
                    Regístrate aquí
                  </Link>
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default Login;