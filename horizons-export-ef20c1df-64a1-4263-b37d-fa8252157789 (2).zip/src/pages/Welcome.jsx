import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle, Zap, Brain, Edit, ArrowRight } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

const Welcome = () => {
    const navigate = useNavigate();
    const { user, profile, setProfile } = useAuth();

    const benefits = [
        { icon: Zap, text: "90% de ahorro de tiempo en planificación" },
        { icon: Edit, text: "Genera exámenes en segundos" },
        { icon: Brain, text: "Mejora el rendimiento académico de los estudiantes" },
        { icon: CheckCircle, text: "Reduce la carga administrativa" },
    ];
    
    const services = [
      { name: "Crear clases en un clic", path: "/servicios/class-preparer" },
      { name: "Más de 12 servicios innovadores", path: "/servicios" },
      { name: "Accede a una biblioteca digital con IA", path: "/servicios/online-resources" }, 
    ];

    const handleStart = async () => {
        if (profile && !profile.is_onboarded) {
             try {
                const { error } = await supabase
                    .from('profiles')
                    .update({ is_onboarded: true })
                    .eq('id', user.id);

                if (error) throw error;
                
                setProfile(prev => ({...prev, is_onboarded: true}));
            } catch (error) {
                console.error("Error updating onboarding status:", error);
                toast({ title: "Error", description: "No se pudo iniciar el tour. Serás redirigido igualmente.", variant: "destructive" });
            }
        }
        navigate('/dashboard');
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4 pt-20">
            <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, ease: 'easeOut' }}
                className="max-w-4xl w-full"
            >
                <Card className="glass-effect shadow-2xl border-purple-500/30">
                    <CardContent className="p-8 md:p-12 text-center">
                        <motion.h1 
                            initial={{ y: -20, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            transition={{ delay: 0.2, duration: 0.5 }}
                            className="text-4xl md:text-5xl font-extrabold text-white mb-4"
                        >
                            ¡Bienvenido a Profe IA, <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-purple-500">{profile?.full_name || 'Docente'}</span>!
                        </motion.h1>
                        <motion.p 
                            initial={{ y: -20, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            transition={{ delay: 0.3, duration: 0.5 }}
                            className="text-lg md:text-xl text-gray-300 mb-8"
                        >
                            Estás a un paso de transformar tu forma de enseñar.
                        </motion.p>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10 text-left">
                            <div className="space-y-4">
                                {benefits.map((benefit, index) => (
                                    <motion.div 
                                        key={index}
                                        initial={{ x: -20, opacity: 0 }}
                                        animate={{ x: 0, opacity: 1 }}
                                        transition={{ delay: 0.5 + index * 0.1, duration: 0.5 }}
                                        className="flex items-center bg-slate-800/50 p-3 rounded-lg"
                                    >
                                        <benefit.icon className="w-6 h-6 text-green-400 mr-3 flex-shrink-0" />
                                        <span className="text-white">{benefit.text}</span>
                                    </motion.div>
                                ))}
                            </div>
                             <div className="space-y-4">
                                {services.map((service, index) => (
                                    <motion.div 
                                        key={index}
                                        initial={{ x: 20, opacity: 0 }}
                                        animate={{ x: 0, opacity: 1 }}
                                        transition={{ delay: 0.5 + index * 0.1, duration: 0.5 }}
                                        className="flex items-center bg-slate-800/50 p-3 rounded-lg"
                                    >
                                        <ArrowRight className="w-6 h-6 text-sky-400 mr-3 flex-shrink-0" />
                                        <span className="text-white">{service.name}</span>
                                    </motion.div>
                                ))}
                            </div>
                        </div>

                        <motion.div
                            initial={{ y: 20, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            transition={{ delay: 1, duration: 0.5 }}
                        >
                            <Button size="lg" className="text-lg h-14 px-10 glow-effect bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700" onClick={handleStart}>
                                ¡Comenzar el Tour Interactivo! <ArrowRight className="ml-2" />
                            </Button>
                        </motion.div>
                    </CardContent>
                </Card>
            </motion.div>
        </div>
    );
};

export default Welcome;