import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Zap, Heart, Users, Milestone, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import PageMeta from '@/components/PageMeta';
import SocialShareButtons from '@/components/SocialShareButtons';

const AboutUs = () => {
  const teamMembers = [
    { 
      name: 'Juan Felipe Cruz Salamanca', 
      role: 'Fundador y CEO', 
      description: 'Un visionario educativo con la misión de derribar barreras. Como experto en IA y líder social, Juan Felipe impulsa a Profe IA para transformar comunidades a través de la innovación.',
      imgSrc: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/ef20c1df-64a1-4263-b37d-fa8252157789/a676666c0f9c77182850dd05caecae24.jpg' 
    },
    { 
      name: 'Mariana Lucía Poveda Patiño', 
      role: 'Directora de Tecnología y Estrategia Pedagógica', 
      description: 'La mente estratégica que une la pedagogía con la tecnología. Como docente e investigadora, Mariana asegura que cada herramienta de IA responda a las necesidades reales del aula.',
      imgSrc: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/ef20c1df-64a1-4263-b37d-fa8252157789/f49c3d30a89dc85358739378f1d95e71.jpg' 
    },
    { 
      name: 'Sol Lía Cárdenas (SLC)', 
      role: 'Directora de Producto', 
      description: 'La arquitecta de la experiencia Profe IA. Con su alma creativa y pasión por el diseño UX/UI, Sol se dedica a crear una plataforma intuitiva, accesible y atractiva.',
      imgSrc: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/ef20c1df-64a1-4263-b37d-fa8252157789/897bdfb34422f5f663889334905200d4.jpg' 
    },
    { 
      name: 'Jeremías Santiago Peña (JSP)', 
      role: 'Jefe de Comunidad', 
      description: 'El corazón de nuestra comunidad y la voz de la nueva generación. Como líder estudiantil, Jeremías tiende puentes entre la tecnología, los docentes y los estudiantes.',
      imgSrc: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/ef20c1df-64a1-4263-b37d-fa8252157789/3873645c6cdc0114f80ca236738af69b.jpg' 
    },
  ];

  const values = [
    { icon: Zap, title: 'Innovación con Propósito', description: 'Rompemos los moldes tradicionales, desarrollando tecnología de vanguardia que transforma la manera de enseñar y aprender.' },
    { icon: Heart, title: 'Corazón Latino', description: 'Nacimos en Latinoamérica para el mundo. Nuestra tecnología lleva el sello de nuestra cultura: cálida, cercana y profundamente humana.' },
    { icon: Users, title: 'Comunidad Inclusiva', description: 'Creemos en una educación sin barreras. Construimos puentes para que el conocimiento sea accesible para todos.' },
    { icon: Milestone, title: 'Impacto Real', description: 'Más que herramientas, creamos oportunidades. Cada función está diseñada para democratizar la educación y empoderar a los docentes.' },
  ];

  const impactStats = [
    { value: '10K+', label: 'Docentes Empoderados' },
    { value: '98%', label: 'Satisfacción Garantizada' },
    { value: '20+', label: 'Soluciones Educativas IA' },
  ];

  const pageUrl = "https://profe.io/sobre-nosotros";
  const shareTitle = "Conoce al equipo de Profe IA: Transformando la educación con corazón latino y tecnología de vanguardia";
  const shareImage = "https://storage.googleapis.com/hostinger-horizons-assets-prod/ef20c1df-64a1-4263-b37d-fa8252157789/9f657bcc7fc862261dd737580a812d2e.png";

  return (
    <>
      <PageMeta 
        title="Sobre Nosotros - Equipo Profe IA" 
        description="Conoce al equipo visionario detrás de Profe IA. Somos un movimiento de pedagogos y tecnólogos con una misión: empoderar a cada docente de habla hispana con herramientas de IA revolucionarias."
        keywords="equipo Profe IA, fundadores plataforma educativa, tecnología educativa latinoamericana, innovación pedagógica IA, misión educativa inteligencia artificial"
        canonicalUrl={pageUrl}
        imageUrl={shareImage}
      />
      <div className="min-h-screen pt-24 pb-12 bg-gradient-to-br from-slate-900 via-purple-950 to-slate-900 text-gray-200 hero-pattern">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-sky-300 via-blue-400 to-indigo-500 mb-4">
              Equipo Profe IA
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto italic">
              "Sabiduría con corazón latino. Tecnología al servicio de la educación."
            </p>
          </motion.div>

          <motion.div 
            className="text-center max-w-4xl mx-auto mb-20"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.8 }}
          >
            <p className="text-lg text-gray-300 leading-relaxed">
              Más que una empresa, somos un movimiento. Un colectivo de visionarios, pedagogos y tecnólogos con una misión compartida: empoderar a cada docente de habla hispana con herramientas de IA que no solo optimizan su tiempo, sino que encienden la chispa de la curiosidad en cada estudiante.
            </p>
            <p className="text-lg text-sky-300 mt-4 font-semibold">"Caminamos de la mano de Dios para que nadie se quede atrás."</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true, amount: 0.5 }}
              >
                <Card className="glass-effect card-hover h-full border-blue-500/30 hover:border-blue-400 shadow-blue-500/10 hover:shadow-blue-500/20 bg-slate-800/70 rounded-xl p-6 text-center">
                  <value.icon className="w-12 h-12 text-blue-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">{value.title}</h3>
                  <p className="text-gray-300 text-sm">{value.description}</p>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-white mb-4">Conoce a Nuestro Equipo Visionario</h2>
              <p className="text-lg text-gray-400 max-w-2xl mx-auto">Las mentes y corazones que hacen posible la revolución educativa con inteligencia artificial.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
              {teamMembers.map((member, index) => (
                   <motion.div
                      key={index}
                      initial={{ opacity: 0, scale: 0.95 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      viewport={{ once: true }}
                   >
                      <Card className="glass-effect card-hover flex flex-col md:flex-row items-center p-6 rounded-2xl border-indigo-500/30 hover:border-indigo-400 transition-all duration-300 h-full">
                          <img alt={`${member.name} - ${member.role} en Profe IA`} className="rounded-full w-32 h-32 md:w-40 md:h-40 object-cover border-4 border-indigo-500/50 flex-shrink-0 mb-4 md:mb-0 md:mr-6" src={member.imgSrc} loading="lazy" />
                          <div className="text-center md:text-left">
                            <h3 className="text-xl font-bold text-white">{member.name}</h3>
                            <p className="text-sm text-indigo-300 font-semibold mb-2">{member.role}</p>
                            <p className="text-gray-300 text-sm">{member.description}</p>
                          </div>
                      </Card>
                   </motion.div>
              ))}
          </div>
          
          <motion.div
            className="my-24 text-center"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold text-white mb-12">Nuestro Impacto</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 max-w-4xl mx-auto">
              {impactStats.map((stat, index) => (
                <motion.div
                  key={index}
                  className="p-6 glass-effect rounded-xl border border-sky-500/30"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.2 }}
                  viewport={{ once: true }}
                >
                  <p className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-cyan-300">{stat.value}</p>
                  <p className="text-sm text-gray-400 mt-2">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9 }}
              viewport={{ once: true }}
              className="mt-20"
          >
            <Card className="glass-effect p-8 md:p-12 rounded-2xl bg-gradient-to-br from-blue-900/50 to-purple-900/50 border-sky-600/50 text-center">
                <h2 className="text-3xl font-bold text-white mb-4">¿Listo para ser parte del cambio educativo?</h2>
                <p className="text-gray-300 mb-8 max-w-2xl mx-auto">No te quedes atrás en la evolución de la enseñanza. Únete a miles de docentes que ya están creando clases más dinámicas, evaluaciones justas y experiencias de aprendizaje inolvidables. El futuro de la educación está a un clic de distancia.</p>
                <div className="flex flex-col items-center gap-6">
                    <Link to="/registro">
                        <Button size="lg" className="glow-effect bg-gradient-to-r from-blue-600 via-sky-500 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-xl text-lg px-8 py-6 rounded-xl">
                            Comenzar Gratis
                            <ArrowRight className="ml-2 w-5 h-5" />
                        </Button>
                    </Link>
                    <SocialShareButtons title={shareTitle} url={pageUrl} imageUrl={shareImage} />
                </div>
            </Card>
          </motion.div>

        </div>
      </div>
    </>
  );
};

export default AboutUs;