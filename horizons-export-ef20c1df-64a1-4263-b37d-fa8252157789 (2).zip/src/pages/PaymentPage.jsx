import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { initMercadoPago, Wallet } from '@mercadopago/sdk-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Loader2, AlertTriangle, CreditCard, Package, Zap, Tag } from 'lucide-react';
import { motion } from 'framer-motion';

const MERCADOPAGO_PUBLIC_KEY = 'APP_USR-1d920e55-f642-4a51-900b-d0a88abc391d';

const MercadoPagoWrapper = ({ planDetails, coupon }) => {
  const [preferenceId, setPreferenceId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { user } = useAuth();
  const [couponCode, setCouponCode] = useState(coupon || '');
  const [validatedCoupon, setValidatedCoupon] = useState(null);
  const [finalPrice, setFinalPrice] = useState(planDetails.priceMonthly);

  useEffect(() => {
    initMercadoPago(MERCADOPAGO_PUBLIC_KEY, { locale: 'es-CO' });
  }, []);

  const validateAndApplyCoupon = async (codeToValidate) => {
    if (!codeToValidate) {
        setValidatedCoupon(null);
        setFinalPrice(planDetails.priceMonthly);
        toast({ title: "Cupón removido" });
        return;
    }
    try {
      const { data, error: functionError } = await supabase.functions.invoke('validate-coupon', {
        body: { couponCode: codeToValidate, userId: user.id },
      });

      if (functionError) throw functionError;
      if (data.error) throw new Error(data.error);

      const discount = data.coupon.descuento_porcentaje;
      const newPrice = planDetails.priceMonthly * (1 - discount / 100);
      setFinalPrice(newPrice.toFixed(2));
      setValidatedCoupon(data.coupon);
      toast({ title: `¡Cupón "${data.coupon.codigo}" aplicado!`, description: `Obtuviste un ${discount}% de descuento.` });
    } catch (err) {
      toast({ title: "Cupón Inválido", description: err.message, variant: "destructive" });
      setValidatedCoupon(null);
      setFinalPrice(planDetails.priceMonthly);
    }
  };

  useEffect(() => {
    if (coupon) {
      validateAndApplyCoupon(coupon);
    }
  }, [coupon]);

  useEffect(() => {
    const createPreference = async () => {
      if (!user) {
        setError('Debes iniciar sesión para continuar.');
        setLoading(false);
        return;
      }
      setLoading(true);
      setError(null);
      
      const updatedPlan = { ...planDetails, priceMonthly: finalPrice };

      try {
        const { data, error: functionError } = await supabase.functions.invoke('create-mercadopago-preference', {
          body: { planDetails: updatedPlan, userId: user.id },
        });

        if (functionError) throw functionError;
        if (data.error) throw new Error(data.error);
        
        setPreferenceId(data.preferenceId);
      } catch (err) {
        console.error('Error creating preference:', err);
        setError('No se pudo crear la preferencia de pago.');
      } finally {
        setLoading(false);
      }
    };
    createPreference();
  }, [finalPrice, user, planDetails]);


  return (
    <div className="space-y-4">
        <div className="space-y-2">
            <Label htmlFor="coupon" className="text-white">¿Tienes un código de descuento?</Label>
            <div className="flex gap-2">
                <Input id="coupon" placeholder="Ej: PROFE25" value={couponCode} onChange={(e) => setCouponCode(e.target.value)} className="glass-effect"/>
                <Button onClick={() => validateAndApplyCoupon(couponCode)}>Aplicar</Button>
            </div>
             {validatedCoupon && <p className="text-green-400 text-sm mt-1">¡Cupón aplicado!</p>}
        </div>

        {loading && (
          <div className="flex flex-col items-center justify-center h-24">
            <Loader2 className="h-8 w-8 text-sky-400 animate-spin" />
            <p className="text-gray-300 mt-2">Actualizando...</p>
          </div>
        )}
        {error && (
            <div className="flex flex-col items-center justify-center h-24 text-center">
                <AlertTriangle className="h-8 w-8 text-red-400" />
                <p className="text-red-300 mt-2">{error}</p>
            </div>
        )}
        {!loading && !error && preferenceId && (
          <div className="pt-4">
            <Wallet initialization={{ preferenceId }} customization={{ texts:{ valueProp: 'smart_option' }}} />
          </div>
        )}
    </div>
  );
};


const PaymentPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const planDetails = location.state?.plan;
  const coupon = location.state?.coupon;

  if (!planDetails) {
    return (
      <div className="min-h-screen pt-20 flex flex-col items-center justify-center text-center px-4">
        <AlertTriangle className="w-16 h-16 text-red-400 mb-4" />
        <h1 className="text-3xl font-bold text-white mb-2">Error en la Selección del Plan</h1>
        <p className="text-gray-300 mb-6">No se ha seleccionado ningún plan para el pago. Por favor, vuelve a la página de precios.</p>
        <Button onClick={() => navigate('/ofertas')}>Volver a Ofertas</Button>
      </div>
    );
  }

  const getPlanIcon = () => {
    if (planDetails.type === 'subscription') {
      return <CreditCard className="w-8 h-8 text-blue-400" />;
    }
    return <Package className="w-8 h-8 text-purple-400" />;
  };

  const getPlanTypeText = () => {
    if (planDetails.type === 'subscription') {
      return 'Plan de Suscripción';
    }
    return 'Paquete de Créditos';
  };

  return (
    <div className="min-h-screen pt-20 flex flex-col items-center bg-slate-900 hero-pattern">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md p-4 md:p-0"
      >
        <Card className="glass-effect border-sky-500/30 shadow-xl shadow-sky-500/10">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              {getPlanIcon()}
            </div>
            <CardTitle className="text-3xl font-bold text-white">Completa tu Compra</CardTitle>
            <CardDescription className="text-gray-300">
              {getPlanTypeText()}: <span className="font-semibold text-sky-300">{planDetails.name}</span>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-6 p-4 bg-slate-800/50 rounded-lg">
                 {planDetails.originalPrice && (
                    <p className="text-lg text-gray-400 line-through">
                      ${planDetails.originalPrice} {planDetails.currency?.toUpperCase() || 'USD'}
                    </p>
                )}
                <p className="text-3xl font-bold text-yellow-400">
                    ${planDetails.priceMonthly} {planDetails.currency?.toUpperCase() || 'USD'}
                    {planDetails.billingCycle === 'monthly' && '/mes'}
                    {planDetails.billingCycle === 'yearly' && '/año'}
                </p>
              {planDetails.credits && (
                <p className="text-sm text-gray-300 mt-1">
                  <Zap className="w-4 h-4 inline mr-1" />
                  {planDetails.credits} créditos {planDetails.type === 'subscription' ? 'mensuales' : ''}
                </p>
              )}
            </div>
            <MercadoPagoWrapper planDetails={planDetails} coupon={coupon} />
          </CardContent>
        </Card>
        <p className="text-xs text-gray-500 mt-6 text-center">
          Al completar el pago, aceptas nuestros{' '}
          <Link to="/terms-of-service" className="underline hover:text-sky-400">Términos de Servicio</Link> y{' '}
          <Link to="/privacy-policy" className="underline hover:text-sky-400">Política de Privacidad</Link>.
        </p>
      </motion.div>
    </div>
  );
};

export default PaymentPage;