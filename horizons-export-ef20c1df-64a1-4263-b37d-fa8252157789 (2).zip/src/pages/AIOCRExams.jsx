import React, { useState, useEffect, useCallback } from 'react';
    import { motion } from 'framer-motion';
    import { supabase } from '@/lib/supabase';
    import { useAuth } from '@/contexts/AuthContext';
    import { toast } from '@/components/ui/use-toast';
    import { Button } from '@/components/ui/button';
    import PageMeta from '@/components/PageMeta';
    import CreateExamIAForm from '@/components/ocr/CreateExamIAForm';
    import StudentManagementForm from '@/components/ocr/StudentManagementForm';
    import AnswerKeyManagementForm from '@/components/ocr/AnswerKeyManagementForm';
    import ScanExamForm from '@/components/ocr/ScanExamForm';
    import GradeAndResultsForm from '@/components/ocr/GradeAndResultsForm';
    import { FileText, Users, KeyRound, ScanLine, BarChart2 } from 'lucide-react';
    
    const steps = [
      { id: 1, title: 'Crear Examen con IA', icon: FileText, cost: 1 },
      { id: 2, title: 'Gestionar Estudiantes', icon: Users, cost: 0 },
      { id: 3, title: 'Clave de Respuestas', icon: KeyRound, cost: 0 },
      { id: 4, title: 'Escanear Exámenes', icon: ScanLine, cost: 0 },
      { id: 5, title: 'Resultados y Análisis', icon: BarChart2, cost: 0 },
    ];
    
    const AIOCRExams = () => {
      const { user } = useAuth();
      const [currentStep, setCurrentStep] = useState(1);
      const [exams, setExams] = useState([]);
      const [selectedExamId, setSelectedExamId] = useState('');
      const [loadingExams, setLoadingExams] = useState(true);
    
      const fetchExams = useCallback(async () => {
        if (!user) return;
        setLoadingExams(true);
        try {
          const { data, error } = await supabase
            .from('examenes_ia')
            .select('*')
            .eq('creado_por', user.id)
            .order('created_at', { ascending: false });
          if (error) {
            if (error.message.includes('Failed to fetch')) {
              toast({ title: "Error de Red", description: "No se pudieron cargar tus exámenes. Revisa tu conexión.", variant: "destructive" });
            } else {
              throw error;
            }
          }
          setExams(data || []);
        } catch (error) {
          toast({ title: "Error", description: "No se pudieron cargar tus exámenes.", variant: "destructive" });
        } finally {
          setLoadingExams(false);
        }
      }, [user]);
    
      useEffect(() => {
        fetchExams();
      }, [fetchExams]);
    
      const handleExamCreated = async (newExam) => {
        await fetchExams();
        if(newExam && newExam.id) {
            setSelectedExamId(newExam.id);
        }
        toast({
          title: "¡Examen Guardado!",
          description: "Tu nuevo examen ha sido guardado en la base de datos.",
        });
      };
    
      const handleNextStep = () => {
        if (currentStep > 1 && !selectedExamId) {
            toast({
                title: 'Selecciona un examen',
                description: 'Debes seleccionar un examen para continuar a los siguientes pasos.',
                variant: 'destructive',
            });
            return;
        }
        setCurrentStep(s => Math.min(steps.length, s + 1));
      };
    
      const renderStepContent = () => {
        switch (currentStep) {
          case 1:
            return <CreateExamIAForm onExamCreated={handleExamCreated} />;
          case 2:
            return <StudentManagementForm exams={exams} selectedExamId={selectedExamId} setSelectedExamId={setSelectedExamId} refreshExams={fetchExams} />;
          case 3:
            return <AnswerKeyManagementForm exams={exams} selectedExamId={selectedExamId} setSelectedExamId={setSelectedExamId} />;
          case 4:
            return <ScanExamForm exams={exams} selectedExamId={selectedExamId} setSelectedExamId={setSelectedExamId} />;
          case 5:
            return <GradeAndResultsForm exams={exams} selectedExamId={selectedExamId} setSelectedExamId={setSelectedExamId} />;
          default:
            return <div>Paso no encontrado</div>;
        }
      };
    
      return (
        <>
          <PageMeta
            title="Exámenes con IA y OCR"
            description="Crea, gestiona, escanea y califica exámenes de forma automática con nuestra potente herramienta de IA y OCR."
            canonicalUrl="https://profe.io/examenes-ai-ocr"
          />
          <div className="min-h-screen bg-slate-900 hero-pattern pt-24 pb-12 px-4 sm:px-6 lg:px-8">
            <header className="text-center mb-12">
              <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-sky-400 to-purple-500">
                  Exámenes con IA y OCR
                </span>
              </h1>
              <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-300">
                Optimiza tu flujo de evaluación en 5 simples pasos. Desde la creación hasta el análisis de resultados.
              </p>
            </header>
    
            <div className="max-w-6xl mx-auto">
              <div className="mb-8 overflow-x-auto pb-4">
                <div className="flex items-center justify-center space-x-2 sm:space-x-4">
                  {steps.map((step, index) => (
                    <div key={step.id} className="flex items-center">
                      <button
                        onClick={() => setCurrentStep(step.id)}
                        className="flex flex-col items-center text-center space-y-2 focus:outline-none"
                      >
                        <div
                          className={`w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center transition-all duration-300
                            ${currentStep === step.id ? 'bg-sky-500 shadow-lg shadow-sky-500/50' : 'bg-slate-700 hover:bg-slate-600'}
                            ${currentStep > step.id ? 'bg-green-500' : ''}`}
                        >
                          <step.icon className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                        </div>
                        <span className={`text-xs sm:text-sm font-medium transition-colors duration-300 ${currentStep === step.id ? 'text-sky-300' : 'text-gray-400'}`}>
                          {step.title}
                        </span>
                         <span className={`text-xs transition-colors duration-300 ${step.cost > 0 ? 'text-amber-400' : 'text-green-400'}`}>
                          {step.cost > 0 ? `${step.cost} Crédito` : 'Gratis'}
                        </span>
                      </button>
                      {index < steps.length - 1 && (
                        <div className={`w-8 sm:w-16 h-1 mx-2 rounded-full transition-colors duration-500 ${currentStep > step.id ? 'bg-green-500' : 'bg-slate-700'}`} />
                      )}
                    </div>
                  ))}
                </div>
              </div>
    
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
              >
                {renderStepContent()}
              </motion.div>
    
              <div className="flex justify-between mt-8 max-w-3xl mx-auto">
                <Button
                  onClick={() => setCurrentStep(s => Math.max(1, s - 1))}
                  disabled={currentStep === 1}
                  variant="outline"
                >
                  Anterior
                </Button>
                <Button
                  onClick={handleNextStep}
                  disabled={currentStep === steps.length}
                  className="bg-gradient-to-r from-sky-500 to-blue-600"
                >
                  Siguiente
                </Button>
              </div>
            </div>
          </div>
        </>
      );
    };
    
    export default AIOCRExams;