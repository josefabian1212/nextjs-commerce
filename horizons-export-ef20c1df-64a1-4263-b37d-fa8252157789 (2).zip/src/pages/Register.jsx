import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';
import { Mail, Lock, User, ArrowRight, Zap } from 'lucide-react';
import Logo from '@/components/Logo';
import GoogleIcon from '@/components/GoogleIcon';

const servicesPromise = import('@/pages/Services');

const Register = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [loading, setLoading] = useState(false);
  const { register, signInWithGoogle } = useAuth();
  const navigate = useNavigate();

  const handleMouseEnter = () => {
    servicesPromise.catch(err => console.error("Failed to prefetch Services component", err));
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      toast({
        title: "Error",
        description: "Las contraseñas no coinciden",
        variant: "destructive"
      });
      return;
    }
    
    if (formData.password.length < 8) {
      toast({
        title: "Contraseña muy corta",
        description: "La contraseña debe tener al menos 8 caracteres",
        variant: "destructive"
      });
      return;
    }
    
    setLoading(true);
    
    const result = await register(formData.email, formData.password, formData.name);
    
    if (result.success) {
      // Navigation is now handled by ProtectedRoute based on `is_onboarded`
      // navigate('/servicios', { replace: true });
    }
    
    setLoading(false);
  };

  const handleGoogleSignIn = async () => {
    setLoading(true);
    await signInWithGoogle();
    // The AuthProvider will handle navigation after successful OAuth login
  };

  return (
    <div className="min-h-screen pt-28 md:pt-32 pb-12 flex items-center justify-center px-4 hero-pattern">
      <div className="w-full max-w-md">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <Card className="glass-effect glow-effect">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <Logo className="h-20" />
              </div>
              <CardTitle className="text-2xl text-white">Crea tu Cuenta</CardTitle>
              <CardDescription className="text-gray-300">
                ✅ Acceso inmediato • 🎁 10 créditos gratis
              </CardDescription>
              
              <div className="flex items-center justify-center gap-2 mt-3 bg-blue-600/20 px-3 py-2 rounded-full">
                <Zap className="w-4 h-4 text-blue-400" />
                <span className="text-blue-300 text-sm font-medium">¡Únete a la revolución educativa!</span>
              </div>
            </CardHeader>
            
            <CardContent>
              <Button variant="outline" className="w-full bg-white text-slate-700 hover:bg-slate-100 mb-4 text-base py-6" onClick={handleGoogleSignIn} disabled={loading} onMouseEnter={handleMouseEnter}>
                <GoogleIcon className="mr-3 h-6 w-6" />
                Registrarse con Google
              </Button>

              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-slate-600" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-slate-800/80 px-2 text-slate-400 backdrop-blur-sm">O regístrate con tu email</span>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4" onMouseEnter={handleMouseEnter}>
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-white">Nombre completo *</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="name"
                      name="name"
                      type="text"
                      placeholder="Tu nombre"
                      value={formData.name}
                      onChange={handleChange}
                      className="pl-10 glass-effect border-white/20"
                      required
                      disabled={loading}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-white">Email *</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="tu@email.com"
                      value={formData.email}
                      onChange={handleChange}
                      className="pl-10 glass-effect border-white/20"
                      required
                      disabled={loading}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-white">Contraseña *</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="password"
                      name="password"
                      type="password"
                      placeholder="Mínimo 8 caracteres"
                      value={formData.password}
                      onChange={handleChange}
                      className="pl-10 glass-effect border-white/20"
                      minLength="8"
                      required
                      disabled={loading}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword" className="text-white">Confirmar contraseña *</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type="password"
                      placeholder="Repite tu contraseña"
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      className="pl-10 glass-effect border-white/20"
                      required
                      disabled={loading}
                    />
                  </div>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full glow-effect bg-gradient-to-r from-blue-600 to-sky-500" 
                  disabled={loading}
                >
                  {loading ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  ) : (
                    <ArrowRight className="w-4 h-4 mr-2" />
                  )}
                  {loading ? 'Creando cuenta...' : 'Crear Cuenta'}
                </Button>
              </form>
              
              <div className="mt-6 text-center">
                <p className="text-sm text-gray-400">
                  ¿Ya tienes cuenta?{' '}
                  <Link to="/login" className="text-sky-400 hover:text-sky-300 font-medium underline" onMouseEnter={handleMouseEnter}>
                    Inicia sesión aquí
                  </Link>
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default Register;