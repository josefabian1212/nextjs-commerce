import React, { useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { CheckCircle, XCircle, Clock, ArrowRight } from 'lucide-react';
import { useTokens } from '@/contexts/TokenContext';
import PageMeta from '@/components/PageMeta';

const PaymentStatus = ({ status }) => {
  const [searchParams] = useSearchParams();
  const { refreshTokenData } = useTokens();

  useEffect(() => {
    if (status === 'success') {
      refreshTokenData();
    }
  }, [status, refreshTokenData]);

  const statusConfig = {
    success: {
      icon: <CheckCircle className="w-20 h-20 text-green-400" />,
      title: '¡Pago Exitoso!',
      description: 'Tu compra ha sido procesada correctamente. Hemos añadido los créditos a tu cuenta. ¡Gracias por tu confianza!',
      buttonText: 'Ir al Panel de Usuario',
      buttonLink: '/dashboard',
      color: 'border-green-500/50 shadow-green-500/10',
    },
    failure: {
      icon: <XCircle className="w-20 h-20 text-red-400" />,
      title: 'Pago Fallido',
      description: 'Hubo un problema al procesar tu pago. Por favor, verifica tus datos e inténtalo de nuevo o contacta a soporte.',
      buttonText: 'Volver a Intentar',
      buttonLink: '/#pricing',
      color: 'border-red-500/50 shadow-red-500/10',
    },
    pending: {
      icon: <Clock className="w-20 h-20 text-yellow-400" />,
      title: 'Pago Pendiente',
      description: 'Tu pago está siendo procesado. Te notificaremos una vez que se complete. Puedes revisar el estado en tu panel de usuario.',
      buttonText: 'Ir al Panel de Usuario',
      buttonLink: '/dashboard',
      color: 'border-yellow-500/50 shadow-yellow-500/10',
    },
  };

  const currentStatus = statusConfig[status];

  return (
    <>
      <PageMeta title={`Estado del Pago: ${currentStatus.title}`} description={currentStatus.description} />
      <div className="min-h-screen pt-20 flex items-center justify-center bg-slate-900 hero-pattern">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Card className={`w-full max-w-lg text-center glass-effect ${currentStatus.color}`}>
            <CardHeader>
              <div className="flex justify-center mb-4">
                {currentStatus.icon}
              </div>
              <CardTitle className="text-3xl font-bold text-white">{currentStatus.title}</CardTitle>
              <CardDescription className="text-gray-300 mt-2 text-lg">
                {currentStatus.description}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-slate-800/50 p-4 rounded-lg text-left text-sm text-gray-400 space-y-1">
                <p><strong>ID de Pago:</strong> {searchParams.get('payment_id') || 'N/A'}</p>
                <p><strong>Estado:</strong> {searchParams.get('status') || status}</p>
                <p><strong>Referencia Externa:</strong> {searchParams.get('external_reference') || 'N/A'}</p>
              </div>
              <Button asChild size="lg" className="mt-8 w-full bg-gradient-to-r from-blue-600 to-sky-500">
                <Link to={currentStatus.buttonLink}>
                  {currentStatus.buttonText} <ArrowRight className="ml-2 w-5 h-5" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </>
  );
};

export default PaymentStatus;