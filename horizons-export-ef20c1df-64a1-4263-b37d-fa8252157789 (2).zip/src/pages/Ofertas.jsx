import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { Zap, CheckCircle, Package, Award, Sparkles, AlertTriangle, Share2 } from 'lucide-react';
import PageMeta from '@/components/PageMeta';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

const formatCOP = (amount) => {
    return new Intl.NumberFormat('es-CO', {
        style: 'currency',
        currency: 'COP',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
    }).format(amount);
};

const Ofertas = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [cuposRestantes, setCuposRestantes] = useState(7);
    const [billingCycle, setBillingCycle] = useState('monthly');

    useEffect(() => {
        const interval = setInterval(() => {
            setCuposRestantes(prev => (prev > 2 ? prev - 1 : 7));
        }, 8000);
        return () => clearInterval(interval);
    }, []);

    const handleGetPlan = (plan) => {
        if (!user) {
            toast({
                title: "Inicia Sesión para Continuar",
                description: "Necesitas una cuenta para aprovechar esta oferta.",
                variant: "destructive"
            });
            navigate('/registro');
            return;
        }

        if (plan.id === 'free') return;

        const isYearly = billingCycle === 'yearly' && plan.type === 'subscription';
        const price = isYearly ? plan.priceYearly : plan.priceMonthly;
        let discount = 0;

        if (plan.type === 'subscription') {
          if (isYearly) {
            if (plan.id === 'basic') discount = 0.40;
            if (plan.id === 'premium') discount = 0.70;
          } else {
            if (plan.id === 'basic') discount = 0.30;
            if (plan.id === 'premium') discount = 0.50;
          }
        }
        
        const finalPrice = price * (1 - discount);

        const planForNavigation = {
            id: plan.id,
            name: `${plan.name} (${isYearly ? 'Anual' : 'Mensual'})`,
            priceMonthly: finalPrice,
            credits: plan.credits,
            type: plan.type,
            currency: 'COP',
            billingCycle: isYearly ? 'yearly' : (plan.type === 'subscription' ? 'monthly' : null)
        };
        
        navigate('/checkout', { state: { plan: planForNavigation } });
    };

    const subscriptionPlans = [
        { id: 'free', name: 'Gratis', priceMonthly: 0, priceYearly: 0, credits: 10, features: ['10 créditos gratis', 'Acceso a servicios básicos', 'Generación de talleres'], icon: <Award className="w-8 h-8" /> },
        { id: 'basic', name: 'Básico', priceMonthly: 35000, priceYearly: 35000 * 12, credits: 200, features: ['200 créditos/mes', 'Todos los servicios de IA', 'Exportación PDF y Word'], icon: <Zap className="w-8 h-8" />, popular: true },
        { id: 'premium', name: 'Premium', priceMonthly: 98000, priceYearly: 98000 * 12, credits: 600, features: ['600 créditos/mes', 'Acceso a funciones Beta', 'Análisis avanzado con IA'], icon: <Sparkles className="w-8 h-8" /> }
    ];
    
    const creditPackages = [
        { id: 'essential', name: 'Esencial', priceMonthly: 40000, credits: 200, features: ['Pago único', 'Vigencia de 1 mes'] },
        { id: 'advanced', name: 'Avanzado', priceMonthly: 118000, credits: 600, features: ['Pago único', 'Vigencia de 1 mes', 'Mejor valor'] },
        { id: 'pro', name: 'Pro', priceMonthly: 195000, credits: 1200, features: ['Pago único', 'Vigencia de 1 mes', 'Máximo ahorro'] }
    ];

    return (
        <>
            <PageMeta
                title="Ofertas Exclusivas de Lanzamiento - Profe.io"
                description="¡Descuentos increíbles en planes mensuales y anuales! Transforma tu enseñanza con IA."
                canonicalUrl="https://profe.io/ofertas"
                imageUrl="https://horizons-cdn.hostinger.com/ef20c1df-64a1-4263-b37d-fa8252157789/b104c48ec50fd4b891d267f5446ea871.png"
            />
            <div className="min-h-screen bg-slate-900 hero-pattern pt-28 pb-20 px-4 overflow-hidden">
                <div className="max-w-7xl mx-auto">
                    <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }} className="text-center mb-16 p-6 rounded-xl glass-effect-light border border-purple-500/50">
                        <h1 className="text-3xl md:text-5xl font-extrabold text-white mb-4">
                            ¡Oferta de Lanzamiento!
                        </h1>
                        <p className="text-lg md:text-xl text-gray-300 mb-6">
                            Más de 100 docentes comprobaron: 90% de ahorro de tiempo, mejora en el rendimiento estudiantil y reducción de carga administrativa.
                        </p>
                         <div className="mt-8 p-4 bg-slate-800 rounded-lg border border-yellow-400 flex items-center justify-center flex-col md:flex-row text-center">
                            <Share2 className="w-6 h-6 text-yellow-400 mr-2 mb-2 md:mb-0" />
                            <p className="text-lg text-white font-semibold">
                                ¡Comparte con al menos 10 docentes y quedarás inscrito para el sorteo del premio sorpresa!
                            </p>
                        </div>
                    </motion.div>

                    <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                        <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.7, delay: 0.2 }} className="lg:col-span-3 space-y-8">
                           <div className="mt-8">
                             <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-10">Elige tu Plan Ideal</h2>
                            
                            <div className="text-center mb-12">
                              <h3 className="text-2xl font-bold text-white mb-4">Planes de Suscripción</h3>
                              <div className="flex justify-center items-center space-x-4">
                                <Label htmlFor="billing-cycle" className={`font-medium transition-colors ${billingCycle === 'monthly' ? 'text-white' : 'text-gray-400'}`}>Mensual</Label>
                                <Switch id="billing-cycle" checked={billingCycle === 'yearly'} onCheckedChange={(c) => setBillingCycle(c ? 'yearly' : 'monthly')} />
                                <Label htmlFor="billing-cycle" className={`font-medium transition-colors ${billingCycle === 'yearly' ? 'text-white' : 'text-gray-400'}`}>Anual <span className="text-green-400 font-bold">(¡Ahorra más!)</span></Label>
                              </div>
                            </div>

                            <div className="grid md:grid-cols-3 gap-8 mb-16">
                                {subscriptionPlans.map((plan, index) => {
                                    const isYearly = billingCycle === 'yearly';
                                    const price = isYearly ? plan.priceYearly : plan.priceMonthly;
                                    let discount = 0;

                                    if (plan.id !== 'free') {
                                        if (isYearly) {
                                            if (plan.id === 'basic') discount = 0.40;
                                            if (plan.id === 'premium') discount = 0.70;
                                        } else {
                                            if (plan.id === 'basic') discount = 0.30;
                                            if (plan.id === 'premium') discount = 0.50;
                                        }
                                    }
                                    const discountedPrice = price * (1 - discount);

                                    return (
                                    <motion.div key={plan.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: index * 0.1 }} viewport={{ once: true }}>
                                        <Card className={`glass-effect h-full flex flex-col border-2 ${plan.popular ? 'border-yellow-400/50' : 'border-slate-700/50'}`}>
                                            {plan.popular && <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-yellow-400 text-black px-3 py-1 text-sm font-bold rounded-full">Más Popular</div>}
                                            <CardHeader className="text-center">
                                                <div className="w-16 h-16 mx-auto rounded-full bg-slate-800 flex items-center justify-center text-purple-400 mb-4">{plan.icon}</div>
                                                <CardTitle className="text-2xl font-bold text-white">{plan.name}</CardTitle>
                                            </CardHeader>
                                            <CardContent className="flex-grow flex flex-col justify-between">
                                                <div>
                                                    <div className="text-center mb-4 min-h-[90px]">
                                                      {plan.id !== 'free' && <p className="text-gray-400 line-through">{formatCOP(price)}</p>}
                                                      <p className="text-4xl font-bold text-yellow-400">{plan.id === 'free' ? 'GRATIS' : formatCOP(discountedPrice)}</p>
                                                      {plan.id !== 'free' && <p className="text-gray-400">{isYearly ? '/año' : '/mes'}</p>}
                                                    </div>
                                                    <ul className="space-y-2 mb-6">
                                                        {plan.features.map(f => <li key={f} className="flex items-center text-gray-300"><CheckCircle className="w-4 h-4 mr-2 text-green-400" />{f}</li>)}
                                                    </ul>
                                                </div>
                                                <Button onClick={() => handleGetPlan(plan)} className="w-full mt-4 bg-purple-600 hover:bg-purple-700 font-bold" disabled={plan.id === 'free'}>
                                                    {plan.id === 'free' ? 'Plan Actual' : 'Obtener Plan'}
                                                </Button>
                                            </CardContent>
                                        </Card>
                                    </motion.div>
                                    )
                                })}
                            </div>
                            
                            <h3 className="text-2xl font-bold text-white text-center mb-8">Paquetes de Créditos (Compra Única)</h3>
                            <div className="grid md:grid-cols-3 gap-8">
                               {creditPackages.map((plan, index) => (
                                    <motion.div key={plan.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: index * 0.1 }} viewport={{ once: true }}>
                                        <Card className="glass-effect h-full flex flex-col border-2 border-slate-700/50">
                                            <CardHeader className="text-center">
                                                <div className="w-16 h-16 mx-auto rounded-full bg-slate-800 flex items-center justify-center text-green-400 mb-4"><Package className="w-8 h-8" /></div>
                                                <CardTitle className="text-2xl font-bold text-white">{plan.name}</CardTitle>
                                            </CardHeader>
                                            <CardContent className="flex-grow flex flex-col justify-between">
                                                <div>
                                                    <p className="text-4xl text-center font-bold text-green-400 mb-4">{formatCOP(plan.priceMonthly)}</p>
                                                    <p className="text-center text-xl font-semibold text-white mb-4">{plan.credits} créditos</p>
                                                    <ul className="space-y-2 mb-6">
                                                        {plan.features.map(f => <li key={f} className="flex items-center text-gray-300"><CheckCircle className="w-4 h-4 mr-2 text-green-400" />{f}</li>)}
                                                    </ul>
                                                </div>
                                                <Button onClick={() => handleGetPlan({ ...plan, type: 'credits' })} className="w-full mt-4 bg-green-600 hover:bg-green-700 font-bold">Comprar Paquete</Button>
                                            </CardContent>
                                        </Card>
                                    </motion.div>
                                ))}
                            </div>
                        </div>
                        </motion.div>

                        <motion.div initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.7, delay: 0.4 }} className="lg:col-span-2 space-y-8">
                            <img alt="Docente innovador usando tecnología de IA para crear una lección interactiva para estudiantes entusiastas." className="rounded-2xl shadow-2xl w-full object-cover border-4 border-purple-500/30" src="https://horizons-cdn.hostinger.com/ef20c1df-64a1-4263-b37d-fa8252157789/b104c48ec50fd4b891d267f5446ea871.png" />
                            
                            <Card className="glass-effect border-red-500/50 p-6 text-center animate-pulse">
                                <h3 className="text-2xl font-bold text-red-400 flex items-center justify-center"><AlertTriangle className="w-8 h-8 mr-2"/> ¡ATENCIÓN!</h3>
                                <p className="text-4xl text-white font-mono my-2">{cuposRestantes}</p>
                                <p className="text-xl text-white font-semibold">cupos restantes de 100 disponibles.</p>
                                <p className="text-gray-400 mt-1">Oferta válida hasta agotar existencias.</p>
                            </Card>

                            <Button onClick={() => navigate('/registro')} size="lg" className="w-full text-xl h-16 bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-extrabold animate-pulse-slow">
                                👉 REGÍSTRATE AHORA Y RECLAMA TU DESCUENTO
                            </Button>
                        </motion.div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default Ofertas;