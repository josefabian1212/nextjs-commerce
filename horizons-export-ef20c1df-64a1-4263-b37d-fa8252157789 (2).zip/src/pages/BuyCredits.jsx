import React from "react";
import PageMeta from "@/components/PageMeta";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "@/components/ui/use-toast";

const creditPlans = [
  {
    id: "essential",
    name: "Esencial",
    credits: 200,
    priceMonthly: "10",
    currency: "USD",
    description: "Ideal para empezar a explorar.",
    features: ["200 créditos", "Pago único", "Sin suscripción", "Vigencia de 1 mes"],
    type: 'credits',
    gradient: 'from-green-600 to-teal-600',
  },
  {
    id: "advanced",
    name: "Avanzado",
    credits: 600,
    priceMonthly: "30",
    currency: "USD",
    description: "Más créditos para tus proyectos.",
    features: ["600 créditos", "Pago único", "Sin suscripción", "Mejor valor"],
    type: 'credits',
    gradient: 'from-orange-600 to-red-600',
  },
  {
    id: "pro",
    name: "Pro",
    credits: 1200,
    priceMonthly: "50",
    currency: "USD",
    description: "La mejor opción para uso intensivo.",
    features: ["1200 créditos", "Pago único", "Sin suscripción", "Máximo ahorro"],
    type: 'credits',
    gradient: 'from-indigo-600 to-purple-600',
  },
];

const BuyCredits = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const handlePackageSelect = (plan) => {
    if (!user) {
      toast({
        title: "Inicia Sesión",
        description: "Debes iniciar sesión para comprar un paquete.",
        variant: "destructive"
      });
      navigate('/login');
      return;
    }
    navigate('/checkout', { state: { plan } });
  };

  return (
    <>
      <PageMeta
        title="Comprar Créditos - Profe.io"
        description="Elige el paquete de créditos que mejor se adapte a tus necesidades y recarga tu cuenta para seguir creando con IA."
      />
      <div className="container mx-auto px-4 py-12 pt-28">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-blue-600 mb-4">
            Recarga Tus Créditos
          </h1>
          <p className="text-lg text-slate-300 max-w-2xl mx-auto">
            Impulsa tu creatividad y productividad. Elige uno de nuestros paquetes de créditos y continúa utilizando nuestras herramientas de inteligencia artificial sin interrupciones.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {creditPlans.map((plan) => (
            <Card key={plan.id} className="glass-effect border border-slate-700 text-white flex flex-col transform hover:scale-105 transition-transform duration-300">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-sky-400">{plan.name}</CardTitle>
                <CardDescription className="text-slate-400">{plan.description}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <div className="mb-6">
                  <span className="text-5xl font-extrabold">${plan.priceMonthly}</span>
                  <span className="text-slate-400 ml-2">{plan.currency}</span>
                </div>
                <ul className="space-y-2">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button 
                    onClick={() => handlePackageSelect(plan)}
                    className="w-full bg-sky-500 hover:bg-sky-600"
                >
                    Comprar Paquete
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </>
  );
};

export default BuyCredits;