import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, Menu, Zap } from 'lucide-react';

import { useAuth } from '@/contexts/AuthContext';
import { useTokens } from '@/contexts/TokenContext';

import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

import GeneratedContentCard from '@/components/GeneratedContentCard';
import ServiceSidebar from '@/components/services/ServiceSidebar';
import PlaceholderServiceForm from '@/components/services/PlaceholderServiceForm';
import PageMeta from '@/components/PageMeta';
import SocialShareButtons from '@/components/SocialShareButtons';

import ChildrenCreativityForm from '@/components/services/ChildrenCreativityForm';
import PedagogicalWorkshopForm from '@/components/services/PedagogicalWorkshopForm';
import CooperativeLearningForm from '@/components/services/CooperativeLearningForm';
import CreateStartupForm from '@/components/services/CreateStartupForm';
import TutorialGeneratorForm from '@/components/services/TutorialGeneratorForm';
import PoemSongGeneratorForm from '@/components/services/PoemSongGeneratorForm';
import UnitTopicsGeneratorForm from '@/components/services/UnitTopicsGeneratorForm';
import EducationalProjectForm from '@/components/services/EducationalProjectForm';
import MathAnalysisForm from '@/components/services/MathAnalysisForm';
import TextAnalysisForm from '@/components/services/TextAnalysisForm';
import CognitiveAnalysisForm from '@/components/services/CognitiveAnalysisForm';
import PodcastGeneratorForm from '@/components/services/PodcastGeneratorForm';
import PqrsForm from '@/components/services/PqrsForm';
import CriticalThinkingForm from '@/components/services/CriticalThinkingForm';
import MultipleIntelligencesForm from '@/components/services/MultipleIntelligencesForm';
import NeuroeducacionForm from '@/components/services/NeuroeducacionForm';
import EvaluacionFormativaForm from '@/components/services/EvaluacionFormativaForm';
import InteligenciaArtificialForm from '@/components/services/InteligenciaArtificialForm';
import GamificacionForm from '@/components/services/GamificacionForm';
import PresentationGeneratorForm from '@/components/services/PresentationGeneratorForm';
import GenerateArticleForm from '@/components/services/GenerateArticleForm';
import ClassPreparerForm from '@/components/services/ClassPreparerForm';
import AtencionDiversidadForm from '@/components/services/AtencionDiversidadForm';

import { serviceData, slugToIdMap } from '@/components/services/serviceData';
import * as formInitialData from '@/components/services/formData/index.js';

import { handleAIServiceResponse } from '@/components/services/api/aiServiceApi';

const Services = () => {
  const { user } = useAuth();
  const { spendTokens } = useTokens(); 
  const { serviceSlug } = useParams();
  const navigate = useNavigate();
  const [activeService, setActiveService] = useState(null);
  const [loading, setLoading] = useState(false);
  const [generatedContent, setGeneratedContent] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth >= 768);

  const initialFormStates = {
    'class-preparer': formInitialData.initialClassPreparerFormData,
    'generate-article': formInitialData.initialGenerateArticleFormData,
    'pedagogical-workshops': formInitialData.initialPedagogicalWorkshopFormData,
    'atencion-diversidad': formInitialData.initialAtencionDiversidadFormData,
    'cooperative-learning': formInitialData.initialCooperativeLearningFormData,
    'children-creativity': formInitialData.initialChildrenCreativityFormData,
    'presentation-generator': formInitialData.initialPresentationGeneratorFormData,
    'tutorial-generator': formInitialData.initialTutorialFormData,
    'poems-songs': formInitialData.initialPoemSongFormData,
    'unit-topics': formInitialData.initialUnitTopicsFormData,
    'educational-projects': formInitialData.initialEducationalProjectFormData,
    'podcast-generator': formInitialData.initialPodcastFormData,
    'create-startup': formInitialData.initialStartupPlanFormData,
    'gamificacion': formInitialData.initialGamificacionFormData,
    'inteligencia-artificial': formInitialData.initialInteligenciaArtificialFormData,
    'evaluacion-formativa': formInitialData.initialEvaluacionFormativaFormData,
    'neuroeducation': formInitialData.initialNeuroeducacionFormData,
    'critical-thinking': formInitialData.initialCriticalThinkingFormData,
    'multiple-intelligences': formInitialData.initialMultipleIntelligencesFormData,
    'text-analysis': formInitialData.initialTextAnalysisFormData,
    'cognitive-analysis': formInitialData.initialCognitiveAnalysisFormData,
    'math-analysis': formInitialData.initialMathAnalysisFormData,
    'pqrs-generator': formInitialData.initialPqrsFormData,
  };

  const [formStates, setFormStates] = useState(initialFormStates);

  const setFormDataForService = (serviceId, data) => {
    setFormStates(prev => ({ 
      ...prev, 
      [serviceId]: typeof data === 'function' ? data(prev[serviceId]) : data 
    }));
  };

  const handleServiceSelect = useCallback((service) => {
    const slug = Object.keys(slugToIdMap).find(key => slugToIdMap[key] === service.id);
    setActiveService(service);
    setGeneratedContent('');
    if (slug) {
        navigate(`/servicios/${slug}`);
    }
    if (window.innerWidth < 768) { 
      setIsSidebarOpen(false);
    }
  }, [navigate]);

  useEffect(() => {
    let serviceToSelect = null;
    const allServices = Object.values(serviceData).flat();
    if (serviceSlug) {
        const serviceId = slugToIdMap[serviceSlug];
        if (serviceId) {
            serviceToSelect = allServices.find(s => s.id === serviceId);
        }
    }
    
    if (!serviceToSelect) {
        const defaultSlug = 'class-preparer';
        const defaultServiceId = slugToIdMap[defaultSlug];
        serviceToSelect = allServices.find(s => s.id === defaultServiceId) || allServices[0];
        if (serviceToSelect) {
            navigate(`/servicios/${defaultSlug}`, { replace: true });
        }
    }

    if (serviceToSelect) {
      setActiveService(serviceToSelect);
    }
  }, [serviceSlug, navigate]);

  useEffect(() => {
    const clearDownloadsOnExit = () => {
      const downloads = JSON.parse(sessionStorage.getItem('generatedDownloads') || '{}');
      const resultsToKeep = downloads['results-analysis'] || null;
      sessionStorage.clear();
      if (resultsToKeep) {
        sessionStorage.setItem('generatedDownloads', JSON.stringify({ 'results-analysis': resultsToKeep }));
      }
    };

    window.addEventListener('beforeunload', clearDownloadsOnExit);

    return () => {
      window.removeEventListener('beforeunload', clearDownloadsOnExit);
    };
  }, []);

  const handleSubmit = async (e, customFormData) => {
    e.preventDefault();
    if (!activeService || !user) {
      toast({ title: "Error", description: "Debes iniciar sesión y seleccionar un servicio.", variant: "destructive" });
      return;
    }
    
    const formData = customFormData || formStates[activeService.id];

    await handleAIServiceResponse({
      user,
      serviceType: activeService.id,
      formData,
      creditsRequired: activeService.credits || 1,
      setLoading,
      setGeneratedContent,
      spendTokens,
    });
  };

  const handleReset = () => {
    setGeneratedContent('');
    if (activeService) {
      const serviceId = activeService.id;
      setFormStates(prev => ({
        ...prev,
        [serviceId]: { ...(initialFormStates[serviceId] || {}) },
      }));
    }
  };

  const renderForm = () => {
    if (!activeService) return <div className="text-center p-8 text-gray-400">Selecciona un servicio para comenzar.</div>;

    const serviceId = activeService.id;
    const formData = formStates[serviceId] || initialFormStates[serviceId] || {};

    const commonProps = {
      key: serviceId,
      formData: formData,
      setFormData: (data) => setFormDataForService(serviceId, data),
      onSubmit: handleSubmit,
      loading: loading,
      activeService: activeService,
    };

    switch (serviceId) {
      case 'class-preparer': return <ClassPreparerForm {...commonProps} />;
      case 'generate-article': return <GenerateArticleForm {...commonProps} />;
      case 'children-creativity': return <ChildrenCreativityForm {...commonProps} />;
      case 'pedagogical-workshops': return <PedagogicalWorkshopForm {...commonProps} />;
      case 'atencion-diversidad': return <AtencionDiversidadForm {...commonProps} />;
      case 'cooperative-learning': return <CooperativeLearningForm {...commonProps} />;
      case 'create-startup': return <CreateStartupForm {...commonProps} />;
      case 'tutorial-generator': return <TutorialGeneratorForm {...commonProps} />;
      case 'poems-songs': return <PoemSongGeneratorForm {...commonProps} />;
      case 'unit-topics': return <UnitTopicsGeneratorForm {...commonProps} />;
      case 'educational-projects': return <EducationalProjectForm {...commonProps} />;
      case 'math-analysis': return <MathAnalysisForm {...commonProps} />;
      case 'text-analysis': return <TextAnalysisForm {...commonProps} />;
      case 'cognitive-analysis': return <CognitiveAnalysisForm {...commonProps} />;
      case 'podcast-generator': return <PodcastGeneratorForm {...commonProps} />;
      case 'pqrs-generator': return <PqrsForm {...commonProps} />;
      case 'critical-thinking': return <CriticalThinkingForm {...commonProps} />;
      case 'multiple-intelligences': return <MultipleIntelligencesForm {...commonProps} />;
      case 'neuroeducation': return <NeuroeducacionForm {...commonProps} />;
      case 'evaluacion-formativa': return <EvaluacionFormativaForm {...commonProps} />;
      case 'inteligencia-artificial': return <InteligenciaArtificialForm {...commonProps} />;
      case 'gamificacion': return <GamificacionForm {...commonProps} />;
      case 'presentation-generator': return <PresentationGeneratorForm {...commonProps} />;
      default: return <PlaceholderServiceForm activeService={activeService} />;
    }
  };

  const pageTitle = activeService ? activeService.title : 'Servicios de IA';
  const pageDescription = activeService ? `Utiliza la IA para generar ${activeService.title.toLowerCase()} y más.` : 'Explora nuestra suite de herramientas de IA para educadores.';
  const pageUrl = window.location.href;

  return (
    <>
      <PageMeta title={pageTitle} description={pageDescription} canonicalUrl={pageUrl} />
      <div className="min-h-screen flex flex-col md:flex-row pt-20 bg-slate-900 hero-pattern">
        <Button 
          variant="ghost" 
          size="icon" 
          className="md:hidden fixed top-[5.2rem] left-4 z-[60] bg-purple-600/80 hover:bg-purple-700 text-white backdrop-blur-sm"
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        >
          {isSidebarOpen ? <ChevronLeft className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>

        <ServiceSidebar 
          serviceData={serviceData}
          activeService={activeService}
          handleServiceSelect={handleServiceSelect}
          isSidebarOpen={isSidebarOpen}
        />

        <main className={`flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto h-[calc(100vh-5rem)] transition-all duration-300 ease-in-out md:ml-0 ${isSidebarOpen ? 'ml-72' : ''}`}>
          <div className="max-w-4xl mx-auto">
            <AnimatePresence mode="wait">
              {loading && (
                <motion.div 
                  key="loading"
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex flex-col items-center justify-center h-96"
                >
                  <div className="h-16 w-16 animate-spin rounded-full border-4 border-solid border-sky-500 border-t-transparent"></div>
                  <p className="mt-4 text-lg text-gray-300">Generando tu contenido...</p>
                </motion.div>
              )}

              {!loading && generatedContent && activeService && (
                <motion.div
                  key="content"
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <GeneratedContentCard 
                      content={generatedContent}
                      title={formStates[activeService.id]?.titulo || formStates[activeService.id]?.tema_principal || formStates[activeService.id]?.tema || formStates[activeService.id]?.topic || formStates[activeService.id]?.tema_taller || activeService?.title || 'Contenido Generado'}
                  />
                  <Button onClick={handleReset} className="mt-4 bg-purple-600 hover:bg-purple-700">
                    <Zap className="mr-2 h-4 w-4" /> Crear otro
                  </Button>
                </motion.div>
              )}

              {!loading && !generatedContent && (
                <motion.div 
                  key={activeService?.id || 'form'} 
                  initial={{ opacity: 0, y: 20 }} 
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }} 
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                >
                  {renderForm()}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="max-w-4xl mx-auto mt-12">
            <SocialShareButtons title={`Echa un vistazo a esta herramienta de IA: ${pageTitle}`} url={pageUrl} />
          </div>
        </main>
      </div>
    </>
  );
};

export default Services;