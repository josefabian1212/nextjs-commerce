import React, { useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import JsonLdSchema from '@/components/JsonLdSchema';
import PageMeta from '@/components/PageMeta';
import HeroSection from '@/components/home/HeroSection';
import { motion } from 'framer-motion';
import HomeSections from '@/components/home/HomeSections';
import PricingSection from '@/components/home/PricingSection';
import FinalCTA from '@/components/home/FinalCTA';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const { user, profile, loading, session } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    // Si no está cargando y hay un usuario autenticado...
    if (!loading && user) {
      // Si el perfil ya se cargó y no está "onboarded", llévalo a Welcome.
      if (profile && !profile.is_onboarded) {
        navigate('/welcome', { replace: true });
      } 
      // Si el perfil ya se cargó y SÍ está "onboarded", llévalo al Dashboard.
      else if (profile) {
        navigate('/dashboard', { replace: true });
      }
      // Si aún no hay perfil (está cargando o falló), no hagas nada y espera.
    }
  }, [user, profile, loading, navigate]);
  
  const pageUrl = "https://profe.io";
  const shareTitle = "Profe IA: ¡El Futuro de la Enseñanza en tus Manos!";
  const shareDescription = "Genera contenido educativo, evalúa con IA y optimiza tu tiempo con Profe AI.";
  const shareImage = "https://storage.googleapis.com/hostinger-horizons-assets-prod/ef20c1df-64a1-4263-b37d-fa8252157789/a676666c0f9c77182850dd05caecae24.jpg";
  
  const softwareAppSchema = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "Profe IA",
    "applicationCategory": "EducationalApplication",
    "operatingSystem": "Web",
    "description": "Plataforma educativa con inteligencia artificial para generar clases, exámenes y contenido educativo automáticamente. Revoluciona tu enseñanza con herramientas de IA avanzadas.",
    "url": pageUrl,
    "author": {
      "@type": "Organization",
      "name": "Profe IA",
      "url": pageUrl,
      "logo": `${pageUrl}/assets/logo.svg`
    },
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD",
      "availability": "https://schema.org/InStock"
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.9",
      "reviewCount": "1250",
      "bestRating": "5",
      "worstRating": "1"
    },
    "featureList": [
      "Generador de clases con IA",
      "Creación automática de exámenes",
      "Análisis cognitivo educativo",
      "Herramientas de gamificación",
      "Evaluación formativa inteligente",
      "Calificación automática con OCR"
    ]
  };

  // Muestra un spinner si está cargando la sesión inicial o si hay un usuario y se está redirigiendo
  if (loading || user) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-slate-900">
        <div className="h-16 w-16 animate-spin rounded-full border-4 border-solid border-sky-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <>
      <PageMeta 
        title="Profe IA - Generador de Clases y Exámenes con Inteligencia Artificial"
        description={shareDescription}
        canonicalUrl={pageUrl}
        imageUrl={shareImage}
      />
      <JsonLdSchema schema={softwareAppSchema} />
      
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
        className="overflow-x-hidden"
      >
        <HeroSection />
        <HomeSections />
        <PricingSection />
        <FinalCTA />
      </motion.div>
    </>
  );
};

export default Home;