import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useTokens } from '@/contexts/TokenContext'; 
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import ChangePasswordDialog from '@/components/dashboard/ChangePasswordDialog';
import DashboardHeader from '@/components/dashboard/DashboardHeader';
import LoadingSkeleton from '@/components/dashboard/LoadingSkeleton';
import RecentHistory from '@/components/dashboard/RecentHistory';
import StatCards from '@/components/dashboard/StatCards';
import SupportBox from '@/components/dashboard/SupportBox';
import UserAccountSettings from '@/components/dashboard/UserAccountSettings';
import VerificationWarning from '@/components/dashboard/VerificationWarning';
import Joyride from 'react-joyride';

const Dashboard = () => {
  const { user, profile, loading: authLoading, setProfile } = useAuth();
  const { creditHistory, loading: historyLoading, tokens, subscriptionPlan, loading: tokenLoading } = useTokens(); 
  const navigate = useNavigate();
  
  const [isPasswordDialogOpen, setIsPasswordDialogOpen] = useState(false);
  const [isVerified, setIsVerified] = useState(true);
  const [isResendingVerification, setIsResendingVerification] = useState(false);
  const [runTour, setRunTour] = useState(false);

  useEffect(() => {
    if (user) {
      setIsVerified(!!user.email_confirmed_at);
    }
    if (profile && !profile.is_onboarded) {
      setRunTour(true);
    }
  }, [user, profile]);

  const handleJoyrideCallback = async (data) => {
    const { status } = data;
    const finishedStatuses = ['finished', 'skipped'];

    if (finishedStatuses.includes(status)) {
      setRunTour(false);
      if (profile && !profile.is_onboarded) {
        try {
          const { data, error } = await supabase
            .from('profiles')
            .update({ is_onboarded: true })
            .eq('id', user.id)
            .select()
            .single();

          if (error) throw error;
          
          setProfile(data); // Update profile in AuthContext
          toast({ title: "¡Tour completado!", description: "Ahora estás listo para explorar Profe IA." });
        } catch (error) {
          console.error("Error updating onboarding status:", error);
          toast({ title: "Error", description: "No se pudo guardar el estado del tour.", variant: "destructive" });
        }
      }
    }
  };

  const tourSteps = [
    {
      target: '#dashboard-header',
      content: '¡Bienvenido a tu Panel! Aquí tienes un resumen de tu cuenta.',
      placement: 'bottom',
    },
    {
      target: '#stat-cards',
      content: 'Revisa tus créditos, plan actual y estadísticas de uso de un vistazo.',
      placement: 'bottom',
    },
    {
      target: '#account-settings',
      content: 'Aquí puedes gestionar los detalles de tu cuenta y contraseña.',
      placement: 'right',
    },
    {
      target: '#recent-history',
      content: 'Consulta tus últimas actividades y el uso de créditos.',
      placement: 'left',
    },
    {
      target: '#navbar-services',
      content: '¡Es hora de crear! Haz clic aquí para acceder a todas nuestras herramientas de IA.',
      placement: 'bottom',
    },
  ];

  const handleResendVerification = async () => {
    setIsResendingVerification(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user || !user.email) {
      toast({
        title: "Error",
        description: "No se ha encontrado un usuario para enviar la verificación.",
        variant: "destructive",
      });
      setIsResendingVerification(false);
      return;
    }

    const { error } = await supabase.auth.resend({
      type: 'signup',
      email: user.email,
    });

    if (error) {
      toast({
        title: 'Error al Reenviar Correo',
        description: error.message,
        variant: 'destructive',
      });
    } else {
       toast({
        title: 'Correo de Verificación Enviado',
        description: 'Por favor, revisa tu bandeja de entrada (y spam).',
      });
    }

    setIsResendingVerification(false);
  };
  
  const aiServiceTypes = [
    'class-generator', 'children-creativity', 'attention-diversity', 
    'pedagogical-workshops', 'cooperative-learning', 'create-startup', 
    'academic-articles', 'tutorial-generator', 'poems-songs', 'unit-topics', 
    'educational-projects', 'math-analysis', 'text-analysis', 'cognitive-analysis', 
    'podcast-generator', 'pqrs-generator', 'critical-thinking', 'multiple-intelligences', 
    'neuroeducation', 'evaluacion-formativa', 'inteligencia-artificial', 'gamificacion',
    'ocr-exam', 'uso_servicio_ia', 'exam-generator-ia', 'inclusion-workshops',
    'create-exam', 'students'
  ];

  const isLoading = authLoading || tokenLoading;

  if (isLoading) {
    return <LoadingSkeleton />;
  }

  return (
    <>
      <Joyride
        run={runTour}
        steps={tourSteps}
        continuous
        showProgress
        showSkipButton
        callback={handleJoyrideCallback}
        styles={{
          options: {
            arrowColor: '#38bdf8',
            backgroundColor: '#0f172a',
            overlayColor: 'rgba(7, 12, 22, 0.8)',
            primaryColor: '#38bdf8',
            textColor: '#e2e8f0',
            zIndex: 1000,
          },
          buttonClose: {
            color: '#94a3b8',
          },
          buttonNext: {
            backgroundColor: '#0ea5e9',
          },
          buttonBack: {
            color: '#94a3b8'
          }
        }}
        locale={{
          back: 'Atrás',
          close: 'Cerrar',
          last: 'Finalizar',
          next: 'Siguiente',
          skip: 'Saltar',
        }}
      />
      <ChangePasswordDialog open={isPasswordDialogOpen} onOpenChange={setIsPasswordDialogOpen} />
      <div className="min-h-screen pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div id="dashboard-header">
            <DashboardHeader profile={profile} user={user} />
          </div>
          
          <VerificationWarning 
            isVerified={isVerified}
            isResending={isResendingVerification}
            onResend={handleResendVerification}
          />
          
          <div id="stat-cards">
            <StatCards 
              user={user} 
              subscriptionPlan={subscriptionPlan}
              tokens={tokens}
              creditHistory={creditHistory}
              loading={historyLoading}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2" id="account-settings">
              <UserAccountSettings 
                profile={profile}
                user={user}
                subscriptionPlan={subscriptionPlan}
                onPasswordChangeClick={() => setIsPasswordDialogOpen(true)}
              />
            </div>

            <div className="lg:col-span-1 space-y-8">
              <div id="recent-history">
                <RecentHistory 
                  history={creditHistory}
                  loading={historyLoading}
                  serviceTypes={aiServiceTypes}
                />
              </div>
              <SupportBox />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;