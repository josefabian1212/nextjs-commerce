import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Search, Loader2, Heart, ExternalLink, Bookmark } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { useTokens } from '@/contexts/TokenContext';
import { toast } from '@/components/ui/use-toast';
import PageMeta from '@/components/PageMeta';
import { supabase } from '@/lib/supabase';

const resourceTypes = ["Cartilla", "Guía Pedagógica", "Video", "Tutorial", "Presentación", "Artículo", "Libro"];
const educationalLevels = ["Preescolar", "Primaria", "Secundaria", "Bachillerato", "Universidad", "Profesional"];
const subjects = ["Matemáticas", "Ciencias Naturales", "Ciencias Sociales", "Lenguaje", "Inglés", "Tecnología", "Arte"];
const formats = ["PDF", "Video", "PPTX", "DOCX", "Interactivo", "Web"];
const languages = ["Español", "Inglés"];

const OnlineResources = () => {
  const { user } = useAuth();
  const { tokens, spendTokens } = useTokens();
  const [filters, setFilters] = useState({
    keyword: '',
    level: '',
    subject: '',
    type: '',
    format: '',
    language: 'Español'
  });
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleFilterChange = (name, value) => {
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!filters.keyword) {
      toast({ title: "Información requerida", description: "Por favor, ingresa una palabra clave para buscar.", variant: "destructive" });
      return;
    }

    setLoading(true);
    setResults([]);

    try {
      const hasEnoughTokens = await spendTokens(10, `Búsqueda de recursos: ${filters.keyword}`, 'online-resources');
      if (!hasEnoughTokens) {
        setLoading(false);
        return;
      }

      const { data, error } = await supabase.functions.invoke('online-resource-finder', {
        body: { query: filters.keyword, filters },
      });

      if (error) throw error;
      if (data.error) throw new Error(data.error);

      setResults(data.resources || []);
      toast({
        title: "Búsqueda completada",
        description: `Se encontraron ${data.resources?.length || 0} recursos.`,
      });

    } catch (error) {
      console.error('Error searching for resources:', error);
      toast({
        title: "Error en la búsqueda",
        description: error.message || "No se pudieron obtener los recursos. Inténtalo de nuevo.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSaveFavorite = async (resourceId) => {
    try {
        const { data, error } = await supabase
            .from('recursos_favoritos')
            .insert({ user_id: user.id, recurso_id: resourceId });

        if (error) {
            if (error.code === '23505') { // duplicate key
                toast({ title: "Ya guardado", description: "Este recurso ya está en tus favoritos." });
            } else {
                throw error;
            }
        } else {
            toast({ title: "Guardado", description: "Recurso añadido a tus favoritos." });
        }
    } catch(error) {
        console.error('Error saving favorite:', error);
        toast({ title: "Error", description: "No se pudo guardar el recurso.", variant: "destructive" });
    }
  };

  return (
    <>
      <PageMeta
        title="Buscador de Recursos Educativos en Línea"
        description="Encuentra guías, videos, tutoriales y más recursos educativos de fuentes confiables con nuestro buscador inteligente."
      />
      <div className="container mx-auto px-4 py-8">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <h1 className="text-4xl font-bold text-center mb-2 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
            Buscador de Recursos Educativos
          </h1>
          <p className="text-lg text-center text-gray-400 mb-8">
            Tu asistente IA para encontrar material didáctico de calidad en la web.
          </p>
        </motion.div>
        
        <Card className="glass-effect mb-8">
          <CardHeader>
            <CardTitle>Define tu búsqueda</CardTitle>
            <CardDescription>Usa los filtros para encontrar exactamente lo que necesitas. Costo: 10 créditos.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSearch} className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <Input
                  name="keyword"
                  placeholder="Ej: 'guía sobre el sistema solar para primaria'"
                  value={filters.keyword}
                  onChange={(e) => handleFilterChange(e.target.name, e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                <div className="space-y-1">
                  <Label>Nivel Educativo</Label>
                  <Select onValueChange={(v) => handleFilterChange('level', v)}><SelectTrigger><SelectValue placeholder="Cualquiera" /></SelectTrigger><SelectContent>{educationalLevels.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
                </div>
                <div className="space-y-1">
                  <Label>Asignatura</Label>
                  <Select onValueChange={(v) => handleFilterChange('subject', v)}><SelectTrigger><SelectValue placeholder="Cualquiera" /></SelectTrigger><SelectContent>{subjects.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
                </div>
                <div className="space-y-1">
                  <Label>Tipo de Recurso</Label>
                  <Select onValueChange={(v) => handleFilterChange('type', v)}><SelectTrigger><SelectValue placeholder="Cualquiera" /></SelectTrigger><SelectContent>{resourceTypes.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
                </div>
                <div className="space-y-1">
                  <Label>Formato</Label>
                  <Select onValueChange={(v) => handleFilterChange('format', v)}><SelectTrigger><SelectValue placeholder="Cualquiera" /></SelectTrigger><SelectContent>{formats.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
                </div>
                <div className="space-y-1">
                  <Label>Idioma</Label>
                  <Select value={filters.language} onValueChange={(v) => handleFilterChange('language', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{languages.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
                </div>
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Buscando...</> : <><Search className="mr-2 h-4 w-4" /> Buscar Recursos</>}
              </Button>
            </form>
          </CardContent>
        </Card>

        <AnimatePresence>
          {loading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center py-10">
              <Loader2 className="mx-auto h-12 w-12 animate-spin text-sky-400" />
              <p className="mt-4 text-lg">Buscando en la web... Esto puede tardar un momento.</p>
            </motion.div>
          )}
        </AnimatePresence>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence>
            {results.map((res, index) => (
              <motion.div
                key={res.id || index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card className="h-full flex flex-col glass-effect hover:border-purple-500/50 transition-all">
                  <CardHeader>
                    <CardTitle className="text-lg text-cyan-300">{res.titulo}</CardTitle>
                    <CardDescription className="text-sm text-gray-400">Fuente: {res.fuente}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-grow">
                    <p className="text-gray-300 text-sm mb-4">{res.descripcion}</p>
                    <div className="flex flex-wrap gap-2 text-xs">
                        <span className="bg-purple-500/20 text-purple-300 px-2 py-1 rounded-full">{res.tipo_recurso}</span>
                        <span className="bg-sky-500/20 text-sky-300 px-2 py-1 rounded-full">{res.formato}</span>
                    </div>
                  </CardContent>
                  <div className="p-6 pt-0 flex justify-between items-center">
                    <Button asChild variant="link" className="p-0 h-auto">
                        <a href={res.url} target="_blank" rel="noopener noreferrer">
                            Ver Recurso <ExternalLink className="ml-2 h-4 w-4" />
                        </a>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleSaveFavorite(res.id)}>
                        <Bookmark className="h-5 w-5 hover:fill-yellow-400 transition-colors" />
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
        {results.length === 0 && !loading && (
            <div className="text-center py-10 text-gray-500">
                <p>Realiza una búsqueda para ver aquí los resultados.</p>
            </div>
        )}
      </div>
    </>
  );
};

export default OnlineResources;