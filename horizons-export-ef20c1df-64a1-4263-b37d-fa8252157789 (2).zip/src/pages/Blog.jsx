import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';
import { 
  Calendar, User, ArrowRight, Brain, BookOpen, Lightbulb, TrendingUp, Clock,
  UploadCloud, Download, Share2, Link as LinkIcon,
  Facebook, MessageCircle as WhatsAppIcon, Instagram, Linkedin, Twitter
} from 'lucide-react';
import AuthModal from '@/components/AuthModal';

const Blog = () => {
  const { user, profile, isVerified } = useAuth();
  const navigate = useNavigate();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showCreatePostForm, setShowCreatePostForm] = useState(false);
  const [newPost, setNewPost] = useState({ title: '', content: '', category: '', imageFile: null, documentFile: null });
  const imageFileRef = useRef(null);
  const documentFileRef = useRef(null);

  const blogPosts = [
    {
      id: 1,
      title: 'Cómo la IA está Revolucionando la Educación',
      excerpt: 'Descubre las últimas tendencias en inteligencia artificial aplicada a la educación y cómo está transformando la manera de enseñar.',
      author: 'Dr. María González',
      date: '2024-06-10',
      readTime: '5 min',
      category: 'Tecnología',
      image: 'https://images.unsplash.com/photo-1577510409458-a70f1efcba3d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
      featured: true,
      documentUrl: '#'
    },
    {
      id: 2,
      title: 'Generación Automática de Contenido Educativo',
      excerpt: 'Aprende cómo crear clases personalizadas usando herramientas de IA para diferentes grados y materias.',
      author: 'Prof. Carlos Ruiz',
      date: '2024-06-08',
      readTime: '7 min',
      category: 'Metodología',
      image: 'https://images.unsplash.com/photo-1702819073926-d9225ebd1760?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
      documentUrl: '#'
    },
  ];

  const categories = [
    { name: 'Tecnología', icon: Brain, count: 8 },
    { name: 'Metodología', icon: BookOpen, count: 12 },
    { name: 'Evaluación', icon: TrendingUp, count: 6 },
    { name: 'Pedagogía', icon: Lightbulb, count: 15 }
  ];

  const handleDigitalLibraryClick = () => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    if (!isVerified) {
      toast({ title: "Verificación Requerida", description: "Por favor, verifica tu correo electrónico para acceder a esta función.", variant: "destructive" });
      navigate('/verify-email');
      return;
    }
    const userPlan = profile?.plan;
    if (userPlan === 'basico' || userPlan === 'premium') {
      navigate('/digital-library');
    } else {
      toast({
        title: "Acceso Exclusivo",
        description: "La Biblioteca Digital es para usuarios con plan Básico o Premium. ¡Actualiza tu plan!",
        variant: "destructive",
      });
      navigate('/#pricing');
    }
  };

  const handleShare = (platform, title, url) => {
    const text = `¡Echa un vistazo a este artículo!: ${title} - ${url}`;
    let shareUrl = '';
    switch (platform) {
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
        break;
      case 'whatsapp':
        shareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
        break;
      case 'instagram':
        toast({ title: "Compartir en Instagram", description: "Copia el enlace y pégalo en tu historia o publicación de Instagram.", duration: 5000 });
        navigator.clipboard.writeText(url);
        return;
      case 'linkedin':
        shareUrl = `https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}&summary=${encodeURIComponent(title)}`;
        break;
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`;
        break;
      case 'copy':
        navigator.clipboard.writeText(url);
        toast({ title: "Enlace Copiado", description: "El enlace del artículo ha sido copiado al portapapeles." });
        return;
      default:
        return;
    }
    window.open(shareUrl, '_blank', 'noopener,noreferrer');
  };

  const handleCreatePostToggle = () => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    if (!isVerified) {
      toast({ title: "Verificación Requerida", description: "Por favor, verifica tu correo electrónico para crear publicaciones.", variant: "destructive" });
      navigate('/verify-email');
      return;
    }
    setShowCreatePostForm(!showCreatePostForm);
  };

  const handleNewPostChange = (e) => {
    setNewPost({ ...newPost, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e, fileType) => {
    setNewPost({ ...newPost, [fileType]: e.target.files[0] });
  };

  const handleCreatePostSubmit = (e) => {
    e.preventDefault();
    toast({ title: "🚧 En Desarrollo", description: "La función de crear posts está en construcción. ¡Pronto podrás compartir tus ideas!" });
    console.log("Nuevo Post:", newPost);
    setShowCreatePostForm(false);
    setNewPost({ title: '', content: '', category: '', imageFile: null, documentFile: null });
  };

  const shareOptions = [
    { platform: 'facebook', icon: Facebook, label: 'Facebook' },
    { platform: 'whatsapp', icon: WhatsAppIcon, label: 'WhatsApp' },
    { platform: 'instagram', icon: Instagram, label: 'Instagram' },
    { platform: 'linkedin', icon: Linkedin, label: 'LinkedIn' },
    { platform: 'twitter', icon: Twitter, label: 'Twitter' },
    { platform: 'copy', icon: LinkIcon, label: 'Copiar Enlace' },
  ];

  return (
    <>
    <div className="min-h-screen pt-20 pb-10 bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-950 text-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <motion.h1
            initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
            className="text-5xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 via-blue-400 to-indigo-500 mb-4"
          >
            Blog Profe IA
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl text-gray-300 max-w-3xl mx-auto"
          >
            Descubre las últimas tendencias, consejos y novedades en educación con inteligencia artificial.
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5, delay: 0.4 }}
            className="mt-8 flex flex-col sm:flex-row justify-center items-center gap-4"
          >
            <Button size="lg" className="bg-gradient-to-r from-blue-600 to-sky-500 hover:from-blue-700 hover:to-sky-600 text-white shadow-lg" onClick={handleCreatePostToggle}>
              <UploadCloud className="mr-2 h-5 w-5" /> Crear Nuevo Post
            </Button>
            <Button size="lg" variant="outline" className="border-yellow-400 text-yellow-400 hover:bg-yellow-400/10 hover:text-yellow-300 shadow-lg" onClick={handleDigitalLibraryClick}>
              <BookOpen className="mr-2 h-5 w-5" /> Biblioteca Digital (Premium)
            </Button>
          </motion.div>
        </div>

        {showCreatePostForm && (
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-12">
            <Card className="glass-effect p-6 md:p-8">
              <CardHeader>
                <CardTitle className="text-3xl text-white">Crear Nueva Publicación</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleCreatePostSubmit} className="space-y-6">
                  <div>
                    <Label htmlFor="title" className="text-lg text-white">Título</Label>
                    <Input type="text" name="title" id="title" value={newPost.title} onChange={handleNewPostChange} required className="mt-1 glass-effect border-white/20 text-white" />
                  </div>
                  <div>
                    <Label htmlFor="content" className="text-lg text-white">Contenido</Label>
                    <Textarea name="content" id="content" value={newPost.content} onChange={handleNewPostChange} rows={6} required className="mt-1 glass-effect border-white/20 text-white" />
                  </div>
                  <div>
                    <Label htmlFor="category" className="text-lg text-white">Categoría</Label>
                    <Input type="text" name="category" id="category" value={newPost.category} onChange={handleNewPostChange} required className="mt-1 glass-effect border-white/20 text-white" />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="imageFile" className="text-lg text-white">Imagen de Portada</Label>
                      <Input type="file" name="imageFile" id="imageFile" accept="image/*" onChange={(e) => handleFileChange(e, 'imageFile')} ref={imageFileRef} className="mt-1 file:text-sky-300 file:font-semibold file:bg-sky-500/20 file:border-0 file:rounded-md file:px-3 file:py-1.5 hover:file:bg-sky-500/30 cursor-pointer" />
                    </div>
                    <div>
                      <Label htmlFor="documentFile" className="text-lg text-white">Documento Adjunto (PDF, Word)</Label>
                      <Input type="file" name="documentFile" id="documentFile" accept=".pdf,.doc,.docx" onChange={(e) => handleFileChange(e, 'documentFile')} ref={documentFileRef} className="mt-1 file:text-purple-300 file:font-semibold file:bg-purple-500/20 file:border-0 file:rounded-md file:px-3 file:py-1.5 hover:file:bg-purple-500/30 cursor-pointer" />
                    </div>
                  </div>
                  <div className="flex justify-end space-x-3">
                    <Button type="button" variant="ghost" onClick={() => setShowCreatePostForm(false)}>Cancelar</Button>
                    <Button type="submit" className="bg-gradient-to-r from-sky-500 to-blue-600">Publicar</Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-3">
            {blogPosts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className={`mb-12 ${post.featured ? 'col-span-1 md:col-span-2 lg:col-span-3' : ''}`}
              >
                <Card className="glass-effect card-hover overflow-hidden shadow-2xl border border-blue-700/30">
                  <div className="relative">
                    <img  className="w-full h-64 md:h-80 object-cover" alt={post.title} src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
                    {post.featured && (
                      <div className="absolute top-4 left-4">
                        <span className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-3 py-1.5 rounded-full text-sm font-semibold shadow-lg">
                          Destacado
                        </span>
                      </div>
                    )}
                  </div>
                  <CardContent className="p-6 md:p-8">
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-gray-400 text-sm mb-4">
                      <div className="flex items-center"><Calendar className="w-4 h-4 mr-1.5 text-sky-400" />{new Date(post.date).toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' })}</div>
                      <div className="flex items-center"><User className="w-4 h-4 mr-1.5 text-sky-400" />{post.author}</div>
                      <div className="flex items-center"><Clock className="w-4 h-4 mr-1.5 text-sky-400" />{post.readTime}</div>
                      <div className="flex items-center"><span className="bg-slate-700 text-sky-300 px-2 py-0.5 rounded text-xs font-medium">{post.category}</span></div>
                    </div>
                    <h2 className="text-2xl md:text-3xl font-bold text-white mb-4 hover:text-sky-300 transition-colors">
                      <a href="#">{post.title}</a>
                    </h2>
                    <p className="text-gray-300 text-lg mb-6 line-clamp-3">
                      {post.excerpt}
                    </p>
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                      <Button className="bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white shadow-md" onClick={() => toast({ title: "🚧 Leer más...", description: "Próximamente podrás leer el artículo completo."})}>
                        Leer más <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                      <div className="flex items-center space-x-2">
                        {post.documentUrl && post.documentUrl !== '#' && (
                          <Button variant="outline" size="sm" className="text-green-400 border-green-500 hover:bg-green-500/10" onClick={() => window.open(post.documentUrl, '_blank')}>
                            <Download className="w-4 h-4 mr-1.5" /> Descargar
                          </Button>
                        )}
                        <div className="flex space-x-1">
                          {shareOptions.map(opt => (
                            <Button key={opt.platform} variant="ghost" size="icon" className="text-gray-400 hover:text-sky-300" onClick={() => handleShare(opt.platform, post.title, window.location.href + `#post-${post.id}`)}>
                              <opt.icon className="w-4 h-4" />
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <aside className="lg:col-span-1 space-y-8">
            <Card className="glass-effect p-6 shadow-xl border border-indigo-700/30">
              <CardTitle className="text-xl text-white mb-4">Categorías</CardTitle>
              <div className="space-y-2">
                {categories.map((cat, i) => (
                  <Button key={i} variant="ghost" className="w-full justify-start text-gray-300 hover:text-sky-300 hover:bg-slate-700/50">
                    <cat.icon className="w-5 h-5 mr-3 text-indigo-400" /> {cat.name} <span className="ml-auto text-xs text-gray-500">{cat.count}</span>
                  </Button>
                ))}
              </div>
            </Card>
            <Card className="glass-effect p-6 shadow-xl border border-purple-700/30">
              <CardTitle className="text-xl text-white mb-2">Newsletter</CardTitle>
              <CardDescription className="text-gray-400 mb-4">Recibe las últimas novedades.</CardDescription>
              <Input type="email" placeholder="tu@email.com" className="mb-3 glass-effect border-white/20 text-white" />
              <Button className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700">Suscribirse</Button>
            </Card>
          </aside>
        </div>
      </div>
    </div>
    <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </>
  );
};

export default Blog;