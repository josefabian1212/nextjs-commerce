import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { HelpCircle, ChevronDown, MessageCircle } from 'lucide-react';
import PageMeta from '@/components/PageMeta';

const FaqItem = ({ question, answer }) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
      className="glass-effect border border-slate-700/50 rounded-lg overflow-hidden"
    >
      <details className="group">
        <summary className="flex items-center justify-between p-4 cursor-pointer text-white font-semibold list-none">
          {question}
          <ChevronDown className="w-5 h-5 transition-transform duration-300 group-open:rotate-180" />
        </summary>
        <div className="p-4 pt-0 text-gray-300">
          {answer}
        </div>
      </details>
    </motion.div>
  );
};

const Faq = () => {
  const faqData = [
    {
      question: '¿Profe IA es gratuito?',
      answer: '¡Sí! Puedes usar muchas funciones de manera gratuita para empezar. Ofrecemos un plan gratuito con 10 créditos para que puedas explorar la plataforma. Para un uso más intensivo y acceso a funciones avanzadas, tenemos planes de suscripción y paquetes de créditos a precios muy accesibles.'
    },
    {
      question: '¿Cómo genero un examen con IA?',
      answer: 'Es muy fácil. Ve a la sección "Exámenes AI-OCR", haz clic en "Crear Examen", llena el formulario con los detalles como la asignatura, el tema y el número de preguntas, y finalmente, haz clic en "Generar Examen con IA". ¡La magia ocurrirá en segundos!'
    },
    {
        question: '¿Cómo funciona la calificación con OCR?',
        answer: 'Una vez que has creado tu examen y tienes la clave de respuestas, simplemente toma una foto o escanea los exámenes resueltos de tus estudiantes desde la sección "Escanear". Nuestra IA leerá las respuestas, las comparará con la clave y te entregará las calificaciones automáticamente.'
    },
    {
      question: '¿Qué hago si tengo un problema técnico?',
      answer: (
        <span>
          ¡Estamos aquí para ayudarte! La forma más rápida de contactarnos es a través de nuestro WhatsApp de soporte. Haz clic <a href="https://wa.me/573207303024" target="_blank" rel="noopener noreferrer" className="text-sky-400 underline hover:text-sky-300">aquí</a> para chatear directamente con nosotros. Nuestro equipo te atenderá con gusto.
        </span>
      )
    },
    {
      question: '¿Mis datos y los de mis estudiantes están seguros?',
      answer: 'Absolutamente. La seguridad y la privacidad son nuestra máxima prioridad. Todos los datos se manejan con encriptación de extremo a extremo y cumplimos con las mejores prácticas de protección de datos. Puedes consultar nuestra Política de Privacidad para más detalles.'
    },
    {
        question: '¿Puedo cancelar mi suscripción en cualquier momento?',
        answer: 'Sí, tienes total flexibilidad. Puedes cancelar tu suscripción en cualquier momento desde tu panel de control, sin preguntas ni complicaciones. Seguirás teniendo acceso a tu plan hasta el final del ciclo de facturación actual.'
    }
  ];

  return (
    <>
    <PageMeta 
        title="Preguntas Frecuentes (FAQ)"
        description="Encuentra respuestas a las preguntas más comunes sobre Profe IA, nuestros planes, el uso de créditos y la seguridad de tus datos."
        keywords="FAQ Profe IA, preguntas frecuentes IA, ayuda Profe IA, soporte técnico Profe IA"
      />
    <div className="min-h-screen pt-24 pb-12 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-gray-200 hero-pattern">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="text-center mb-12"
        >
          <HelpCircle className="w-20 h-20 text-purple-400 mx-auto mb-6 animate-pulse-slow" />
          <h1 className="text-5xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-indigo-500 mb-4">
            Preguntas Frecuentes
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Resolvemos tus dudas para que aproveches al máximo Profe IA.
          </p>
        </motion.div>
        
        <div className="space-y-4">
          {faqData.map((item, index) => (
            <FaqItem key={index} question={item.question} answer={item.answer} />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="mt-16"
        >
            <Card className="glass-effect text-center p-8 border border-purple-800/50">
                <CardHeader>
                    <MessageCircle className="w-12 h-12 mx-auto text-purple-400 mb-4"/>
                    <CardTitle className="text-2xl text-white">¿No encontraste tu respuesta?</CardTitle>
                    <CardDescription className="text-gray-300">
                        Nuestro equipo de soporte está listo para ayudarte.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <a href="https://wa.me/573207303024" target="_blank" rel="noopener noreferrer">
                        <button className="bg-green-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-600 transition-colors flex items-center justify-center mx-auto">
                            <MessageCircle className="w-5 h-5 mr-2" />
                            Contactar por WhatsApp
                        </button>
                    </a>
                </CardContent>
            </Card>
        </motion.div>
      </div>
    </div>
    </>
  );
};

export default Faq;