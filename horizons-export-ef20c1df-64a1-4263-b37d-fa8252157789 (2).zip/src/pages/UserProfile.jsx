import React, { useState, useEffect } from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { 
  User, 
  Calendar, 
  Award, 
  TrendingUp, 
  Brain,
  Clock,
  Star,
  Zap
} from 'lucide-react';

const UserProfile = () => {
  const { username } = useParams();
  const { user, profile } = useAuth();
  const [userStats, setUserStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUserStats = async () => {
      if (!user) return;
      
      try {
        // Por ahora, solo mostrar el perfil del usuario actual
        // En el futuro se puede expandir para mostrar perfiles públicos
        if (username !== profile?.full_name?.toLowerCase().replace(/\s+/g, '-')) {
          setLoading(false);
          return;
        }

        const { data, error } = await supabase
          .from('user_dashboard_stats')
          .select('*')
          .eq('user_id', user.id)
          .single();

        if (error) {
          console.error('Error fetching user stats:', error);
        } else {
          setUserStats(data);
        }
      } catch (error) {
        console.error('Error:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchUserStats();
  }, [user, username, profile]);

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (loading) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-400"></div>
      </div>
    );
  }

  if (!userStats) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Perfil no encontrado</h1>
          <p className="text-gray-400">Este perfil no existe o no tienes permisos para verlo.</p>
        </div>
      </div>
    );
  }

  const stats = [
    {
      title: 'Créditos Disponibles',
      value: userStats.current_credits || 0,
      icon: Zap,
      color: 'from-yellow-500 to-orange-500'
    },
    {
      title: 'Total Solicitudes IA',
      value: userStats.total_ai_requests || 0,
      icon: Brain,
      color: 'from-purple-500 to-blue-500'
    },
    {
      title: 'Servicios Utilizados',
      value: userStats.services_used || 0,
      icon: Star,
      color: 'from-green-500 to-teal-500'
    },
    {
      title: 'Créditos Utilizados',
      value: userStats.total_credits_used || 0,
      icon: TrendingUp,
      color: 'from-pink-500 to-purple-500'
    }
  ];

  return (
    <div className="min-h-screen pt-20 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <div className="flex items-center gap-6 mb-8">
            <div className="w-24 h-24 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
              <User className="w-12 h-12 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white">{userStats.full_name}</h1>
              <p className="text-gray-300 text-lg">Educador en Profe IA</p>
              <div className="flex items-center gap-4 mt-2 text-sm text-gray-400">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>Miembro desde {new Date(userStats.member_since).toLocaleDateString('es-ES', { year: 'numeric', month: 'long' })}</span>
                </div>
                {userStats.last_activity_at && (
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>Última actividad: {new Date(userStats.last_activity_at).toLocaleDateString('es-ES')}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="glass-effect card-hover">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm font-medium">{stat.title}</p>
                      <p className="text-2xl font-bold text-white">{stat.value}</p>
                    </div>
                    <div className={`w-12 h-12 bg-gradient-to-r ${stat.color} rounded-lg flex items-center justify-center`}>
                      <stat.icon className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="glass-effect">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Award className="w-6 h-6 mr-3 text-yellow-400" />
                  Estadísticas de Uso
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-slate-800/50 rounded-lg">
                  <span className="text-gray-300">Créditos Ganados</span>
                  <span className="text-green-400 font-semibold">{userStats.total_credits_earned}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-slate-800/50 rounded-lg">
                  <span className="text-gray-300">Créditos Utilizados</span>
                  <span className="text-orange-400 font-semibold">{userStats.total_credits_used}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-slate-800/50 rounded-lg">
                  <span className="text-gray-300">Eficiencia de Uso</span>
                  <span className="text-blue-400 font-semibold">
                    {userStats.total_credits_earned > 0 
                      ? Math.round((userStats.total_credits_used / userStats.total_credits_earned) * 100)
                      : 0}%
                  </span>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            <Card className="glass-effect">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Brain className="w-6 h-6 mr-3 text-purple-400" />
                  Actividad Reciente
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {userStats.favorite_service && (
                  <div className="p-3 bg-slate-800/50 rounded-lg">
                    <p className="text-gray-400 text-sm">Servicio Favorito</p>
                    <p className="text-white font-semibold capitalize">
                      {userStats.favorite_service.replace(/_/g, ' ')}
                    </p>
                  </div>
                )}
                <div className="p-3 bg-slate-800/50 rounded-lg">
                  <p className="text-gray-400 text-sm">Total de Solicitudes</p>
                  <p className="text-white font-semibold">{userStats.total_ai_requests} respuestas generadas</p>
                </div>
                <div className="p-3 bg-slate-800/50 rounded-lg">
                  <p className="text-gray-400 text-sm">Servicios Explorados</p>
                  <p className="text-white font-semibold">{userStats.services_used} de 22 disponibles</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;