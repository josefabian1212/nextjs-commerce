import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { FileText, CheckSquare, Shield, CircleDollarSign, Scale, Mail, UserX, Bot } from 'lucide-react';

const TermsOfService = () => {
    const sections = [
        {
            icon: CheckSquare,
            title: '1. Aceptación de los Términos',
            content: 'Al acceder o utilizar los servicios de Profe IA, usted acepta estar sujeto a estos Términos de Servicio y a nuestra Política de Privacidad. Si no está de acuerdo con alguna parte de los términos, no podrá acceder al servicio.'
        },
        {
            icon: Bot,
            title: '2. Descripción del Servicio',
            content: 'Profe IA proporciona un conjunto de herramientas basadas en inteligencia artificial para ayudar a los educadores. Los servicios se proporcionan "tal cual" y "según disponibilidad". Nos reservamos el derecho de modificar o descontinuar el servicio con o sin previo aviso.'
        },
        {
            icon: Shield,
            title: '3. Obligaciones del Usuario',
            content: 'Usted es responsable de su cuenta y de toda la actividad que ocurra bajo ella. Se compromete a no utilizar el servicio para ningún propósito ilegal o no autorizado. No debe, en el uso del servicio, violar ninguna ley en su jurisdicción.'
        },
        {
            icon: CircleDollarSign,
            title: '4. Pagos, Suscripciones y Reembolsos',
            content: 'Algunos de nuestros servicios requieren pago. Usted acepta proporcionar información de pago actual, completa y precisa. Las suscripciones se renuevan automáticamente a menos que se cancelen. Las políticas de reembolso se describen en nuestra página de precios y están sujetas a cambios.'
        },
        {
            icon: UserX,
            title: '5. Cancelación y Terminación',
            content: 'Usted es el único responsable de cancelar adecuadamente su cuenta. Podemos, a nuestra entera discreción, suspender o cancelar su cuenta y negarle el uso presente o futuro del servicio por cualquier motivo y en cualquier momento.'
        },
        {
            icon: Scale,
            title: '6. Ley Aplicable',
            content: 'Estos Términos de Servicio se regirán e interpretarán de acuerdo con las leyes de la jurisdicción en la que se encuentra nuestra empresa, sin tener en cuenta sus disposiciones sobre conflicto de leyes.'
        }
    ];

  return (
    <div className="min-h-screen pt-24 pb-12 bg-gradient-to-br from-slate-950 via-gray-900 to-slate-950 text-gray-200 hero-pattern">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="text-center mb-12"
        >
          <FileText className="w-20 h-20 text-purple-400 mx-auto mb-6 animate-pulse-slow" />
          <h1 className="text-5xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-indigo-500 mb-4">
            Condiciones del Servicio
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Última actualización: 20 de junio de 2025. Reglas para una comunidad segura y transparente.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
        >
          <Card className="glass-effect shadow-2xl border border-purple-800/50">
            <CardHeader>
              <CardTitle className="text-2xl text-white">Nuestros Términos y Condiciones</CardTitle>
              <CardDescription className="text-gray-300">Al utilizar Profe IA, aceptas nuestros términos y condiciones, diseñados para garantizar una experiencia segura, transparente y confiable para todos los usuarios.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8 text-gray-300 leading-relaxed">
              {sections.map((section, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.4 + index * 0.15 }}
                  className="flex items-start space-x-4"
                >
                  <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-purple-900/50 flex items-center justify-center border border-purple-700/50">
                    <section.icon className="w-6 h-6 text-purple-400" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-2">{section.title}</h3>
                    <p className="text-gray-400">{section.content}</p>
                  </div>
                </motion.div>
              ))}
              <div className="border-t border-purple-800/50 pt-6 mt-8 text-center">
                <p className="mb-4 text-lg">¿Necesitas ayuda?</p>
                <p className="text-gray-400 mb-4">Para cualquier consulta sobre nuestros términos, contáctanos.</p>
                <a href="mailto:legal@profeia.com" className="inline-flex items-center justify-center px-6 py-3 font-semibold text-white bg-purple-600 rounded-lg hover:bg-purple-700 transition-colors">
                  <Mail className="w-5 h-5 mr-2" /> legal@profeia.com
                </a>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default TermsOfService;