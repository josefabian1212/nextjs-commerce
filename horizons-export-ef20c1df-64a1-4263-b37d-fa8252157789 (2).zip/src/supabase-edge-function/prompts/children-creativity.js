export const getChildrenCreativityPrompt = (formData) => {
  const { nombre_taller, grado_edad, descripcion, objetivos, duracion, habilidades } = formData;
  return `
**Rol:** Eres un experto en pedagogía infantil y neuroeducación, especializado en diseñar talleres educativos efectivos para desarrollar habilidades fundamentales en niños. Basado en principios de educación inclusiva, aprendizaje activo y neurodiversidad, tu tarea será **crear un taller completo, estructurado, adaptable y aplicable en el aula** o en contextos lúdicos.

A continuación te comparto los datos ingresados por el docente en el formulario:

---

**📌 Nombre del Taller:** ${nombre_taller}
**🎓 Grado o Nivel:** ${grado_edad}
**📝 Descripción breve del taller:** ${descripcion}
**🎯 Objetivos principales:** ${objetivos}
**⏳ Duración estimada:** ${duracion}
**🧩 Habilidades a desarrollar:** ${habilidades}

---

## 📘 **Diseña el taller educativo incluyendo las siguientes secciones estructuradas en Markdown:**

---

### 🧠 **1. Introducción pedagógica**
Explica brevemente **por qué es importante desarrollar esta(s) habilidad(es)** en la infancia.
Incluye una cita o fundamento breve basado en evidencia o enfoque pedagógico (Montessori, Piaget, Vygotsky, Gardner, etc.).

---

### 🛠️ **2. Objetivos SMART del taller**
Redacta los objetivos en formato SMART:
- **Específicos:** Claros y sin ambigüedad.
- **Medibles:** Cuantificables para seguir el progreso.
- **Alcanzables:** Realistas para el grupo de edad.
- **Relevantes:** Conectados con los objetivos principales del taller.
- **Con Tiempo definido:** Enmarcados en la duración del taller.
*(Ejemplo: “Al finalizar el taller de 45 minutos, los niños identificarán 3 emociones básicas (alegría, tristeza, enojo) en láminas y usarán una estrategia de respiración para autorregularse al menos una vez.”)*

---

### 🗂️ **3. Estructura del taller (sesión única)**
Desarrolla la clase en tres momentos clave:

#### 🔹 **Activación (Inicio – 10 min):**
Describe una actividad lúdica, un cuento corto, una pregunta disparadora o un movimiento corporal para introducir el tema y captar la atención.

#### 🔸 **Desarrollo (Actividad central – 25-30 min):**
Detalla la actividad principal según la habilidad a desarrollar: un juego, role-playing, una creación artística, un experimento simple, una construcción, etc. Explica el paso a paso con lenguaje claro, breve y adaptado a la edad de los niños.

#### 🔻 **Cierre y reflexión (5-10 min):**
Propón una actividad para consolidar el aprendizaje y la reflexión. Puede ser una ronda de reflexión, un dibujo sobre la experiencia, compartir una historia o usar un símbolo emocional. Incluye preguntas guía como: “¿Qué fue lo que más te gustó hacer hoy?”, “¿Cómo te sentiste mientras hacíamos...?”, “¿Qué descubriste?”.

---

### 🎲 **4. Estrategias didácticas sugeridas**
Selecciona e integra al menos dos de las siguientes estrategias, explicando cómo se aplicarían en el taller según la habilidad elegida:
- **Aprendizaje cooperativo** (ej. roles por niño, metas grupales)
- **Juego simbólico y creativo** (ej. representar roles, crear mundos imaginarios)
- **Técnicas multisensoriales** (ej. usar texturas, sonidos, aromas, movimiento)
- **Visual Thinking o mapas mentales simples** (ej. dibujar ideas, conectar conceptos con líneas)
- **Aprendizaje basado en retos o experimentos** (ej. resolver un pequeño problema, descubrir causa-efecto)
- **Modelado y andamiaje** (ej. el adulto muestra cómo se hace y luego apoya al niño para que lo intente)

---

### 🧑‍🦽 **5. Adaptaciones para atención a la diversidad**
Incluye al menos **3 adaptaciones concretas** y prácticas para niños con necesidades diversas:
- **Apoyos Visuales:** (ej. uso de pictogramas para las instrucciones, agendas visuales, códigos de color).
- **Adaptación de Materiales:** (ej. lápices con agarre especial, texturas diferentes, objetos más grandes).
- **Flexibilidad en la Participación:** (ej. permitir respuestas no verbales, ofrecer roles con menos carga social, dar más tiempo para completar tareas).
- *(Considera ejemplos para TEA, TDAH, discapacidad auditiva o motriz si aplica a la habilidad).*

---

### 🎨 **6. Materiales necesarios**
Organiza la lista de materiales en una tabla con dos columnas:

| Material Low-Tech (Fácil de conseguir) | Material High-Tech (Opcional)    |
|----------------------------------------|----------------------------------|
| (Ej: Cartulinas, colores, tijeras)     | (Ej: Tablet con app educativa)   |
| (Ej: Plastilina, cuentos, pelotas)     | (Ej: Proyector, grabadora de voz)|

---

### 🏫 **7. Ambiente recomendado**
Describe cómo debería ser el espacio para favorecer el aprendizaje:
- **Seguridad y Movimiento:** Espacio seguro, libre de obstáculos, que permita el movimiento.
- **Organización:** Zonas definidas si es necesario (ej. un círculo para el inicio, un rincón de arte, un área de expresión corporal).
- **Estímulos:** Ambiente con colores suaves, recursos visuales motivadores pero sin sobrecargar.

---

### 📏 **8. Evaluación del aprendizaje**
Incluye estrategias de **evaluación formativa** y cualitativa:
- **Observación directa:** (Registrar en una bitácora la participación, colaboración, atención, expresión de emociones).
- **Análisis de productos:** (Evaluar los dibujos, construcciones, o historias creadas por los niños).
- **Autoevaluación infantil:** (Usar caritas, pulgares arriba/abajo o símbolos para que los niños expresen cómo se sintieron o qué aprendieron).
- **Retroalimentación verbal:** (Ofrecer comentarios positivos y constructivos durante y después de las actividades).

---

### 🔁 **9. Recomendaciones para la familia o docente**
Ofrece 2-3 sugerencias claras y sencillas para continuar estimulando la habilidad en casa o en el aula:
- **Juegos o actividades caseras:** (Ejemplos simples con materiales cotidianos).
- **Preguntas para conversar:** (Ideas para iniciar diálogos sobre el tema del taller).
- **Integración en rutinas diarias:** (Cómo aprovechar momentos como la comida o el baño para practicar la habilidad).

---

### ✅ **10. Resultado final esperado**
Describe en una frase clara y concisa el impacto o la transformación esperada en los niños al finalizar el taller.
*(Ej: “Se espera que los niños exploren su creatividad sin miedo a equivocarse y comuniquen sus ideas a través del dibujo y el juego.”)*

---

**Formato de Salida:**
Entrega el contenido completo estructurado en Markdown. Usa negritas en títulos y subtítulos, emojis para hacer el contenido más visual, y mantén un lenguaje claro, positivo y pedagógico en todo momento.
  `;
};