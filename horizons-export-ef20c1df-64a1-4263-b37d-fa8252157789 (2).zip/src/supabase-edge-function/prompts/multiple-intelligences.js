export const getMultipleIntelligencesPrompt = (formData) => {
  const { tema_taller, grado_nivel, duracion, objetivo_principal, inteligencia_enfocar } = formData;
  const intelligencesString = Array.isArray(inteligencia_enfocar) ? inteligencia_enfocar.join(', ') : inteligencia_enfocar;

  return `
**Rol:** Actúa como un científico experto en aplicar talleres para desarrollar Inteligencias Múltiples en los estudiantes. Eres especialista en pedagogía, con formación en programación neurolingüística avanzada y amplia experiencia en diseño de actividades escolares basadas en el modelo de Howard Gardner. Tu misión es crear una guía práctica paso a paso para implementar un taller enfocado en una o varias inteligencias múltiples, alineado con el tema, el grado y el objetivo pedagógico del docente.

La respuesta debe estar redactada en un tono claro, profesional y enfocado a docentes. Usa una estructura ordenada con títulos y subtítulos en negrita. La salida debe tener aproximadamente 4000 a 5000 caracteres.

---

## **Taller de Inteligencias Múltiples: Guía para el Docente**

**📌 Tema del Taller:** ${tema_taller}
**🎓 Grado / Nivel:** ${grado_nivel}
**⏱️ Duración:** ${duracion}
**🎯 Objetivo Principal:** ${objetivo_principal}
**🧠 Inteligencia(s) a Enfocar:** ${intelligencesString}

---

### **1. Introducción al Tema y Activación Cognitiva (5-10 min)**
*(El objetivo es despertar la curiosidad sobre "${tema_taller}" y conectar con los conocimientos previos de los estudiantes de ${grado_nivel}.)*

**Actividad Sugerida:**
[Genera una actividad de inicio creativa y multisensorial. Por ejemplo:
- **Para "El ciclo del agua":** "Inicia mostrando un vaso con hielo. Pregunta: ¿Qué es esto? ¿Qué pasará si lo dejamos al sol? ¿Y si lo calentamos mucho? Luego, pon un video corto en time-lapse que muestre la evaporación y la condensación. Esto apela a las inteligencias visual y lógico-matemática desde el principio."]
- **Para "Los planetas":** "Pon una música espacial de fondo (auditiva). Muestra imágenes impactantes de diferentes planetas (visual) y pregunta: Si pudieran viajar a uno de estos mundos, ¿cuál elegirían y por qué? (lingüística, intrapersonal)".]

---

### **2. Desarrollo del Taller según la(s) Inteligencia(s) Seleccionada(s) (30-40 min)**
*(Esta fase contiene las actividades centrales, diseñadas específicamente para estimular la(s) inteligencia(s) **${intelligencesString}**.)*

[Genera una descripción detallada de la actividad principal, adaptada a las inteligencias seleccionadas. Si hay más de una, propone estaciones de trabajo o un proyecto integrador.

- **Si se enfoca en Lingüística:** "Propón la creación de un 'Diario de una Gota de Agua'. Los estudiantes escribirán un cuento corto en primera persona, narrando el viaje de una gota a través de la evaporación, condensación, precipitación y recolección. Deberán usar adjetivos y verbos que describan cada estado."

- **Si se enfoca en Lógico-Matemática:** "Diseña un experimento simple. Los estudiantes medirán cuánta agua se evapora de un recipiente en un día. Registrarán los datos en una tabla, crearán un gráfico de barras y predecirán cuánta agua se evaporaría en una semana. Deberán identificar patrones y secuencias."

- **Si se enfoca en Espacial:** "Pide a los estudiantes que construyan una maqueta 3D del ciclo del agua usando materiales reciclados (algodón para las nubes, plástico para los ríos, etc.). Deberán representar visualmente cada etapa y la conexión entre ellas."

- **Si se enfoca en Musical:** "Divide a la clase en grupos para componer una canción o un rap sobre el ciclo del agua. Deben crear una letra que explique el proceso y un ritmo pegadizo usando instrumentos simples o percusión corporal. El coro debe repetir la idea principal."

- **Si se enfoca en Corporal-Kinestésica:** "Organiza una dramatización donde los estudiantes representen las moléculas de agua. Deberán moverse por el salón para simular la evaporación (subiendo y separándose), la condensación (juntándose en 'nubes') y la precipitación (cayendo suavemente)."

- **Si se enfoca en Interpersonal:** "Plantea un problema: 'Una comunidad se está quedando sin agua. ¿Qué soluciones pueden proponer como equipo para conservar el agua?'. Los estudiantes deberán debatir, negociar y presentar un plan de acción conjunto, asignando roles y responsabilidades."

- **Si se enfoca en Intrapersonal:** "Guía una meditación corta donde los estudiantes visualicen ser una gota de agua. Luego, pídeles que escriban en un diario personal cómo se sintieron en cada etapa del ciclo y cómo este proceso se conecta con los ciclos de su propia vida (crecimiento, cambio, etc.)."

- **Si se enfoca en Naturalista:** "Organiza una salida al patio de la escuela después de la lluvia para observar charcos, la evaporación y las plantas. Los estudiantes deberán clasificar los diferentes estados del agua que encuentren en la naturaleza y dibujar sus observaciones en un cuaderno de campo."

- **Si se enfoca en Existencial:** "Plantea preguntas profundas: ¿Por qué el agua es esencial para la vida? ¿Qué responsabilidad tenemos como humanos en el cuidado del agua? ¿Cómo sería un mundo sin agua? Organiza un círculo de diálogo para compartir reflexiones."]

---

### **3. Actividad de Aplicación / Producción (10-15 min)**
*(En esta fase, los estudiantes crean un producto tangible o realizan una acción que demuestre su comprensión, utilizando la inteligencia trabajada.)*

**Producto Final Sugerido:**
[Basado en la actividad de desarrollo, define el producto final. Ej: "Los grupos presentarán sus canciones/raps al resto de la clase", "Se expondrán las maquetas en una 'Galería del Agua'", "Los diarios de reflexión se compartirán voluntariamente en un círculo de confianza".]

---

### **4. Evaluación Formativa del Taller (5 min)**
*(La evaluación debe ser rápida, positiva y centrada en el proceso y el esfuerzo.)*

**Estrategia de Evaluación:**
[Propón una técnica de evaluación formativa coherente con la actividad.
- **Rúbrica simple:** Crea una tabla con 2-3 criterios (ej. "Participación en el grupo", "Creatividad en la maqueta", "Claridad en la explicación") y 3 niveles (logrado, en proceso, necesita apoyo).
- **Autoevaluación con Semáforo:** Los estudiantes usan tarjetas de colores (verde, amarillo, rojo) para indicar su nivel de comprensión o comodidad con la actividad.
- **Galería de Aprendizaje:** Los estudiantes caminan por el salón observando los trabajos de los demás y dejan comentarios positivos en post-its.]

---

### **5. Cierre y Reflexión Final (5 min)**
*(El objetivo es consolidar el aprendizaje y conectarlo con la vida real.)*

**Guía para el Cierre:**
- **Conexión con la Realidad:** "Pregunta al grupo: ¿En qué momentos de su día ven el ciclo del agua en acción? (ej. al hervir agua, al ver llover, al secarse la ropa)."
- **Reflexión Final:** "Termina con una frase poderosa como: 'Así como cada gota de agua es importante para el océano, cada una de sus ideas y talentos es importante para este grupo'. Agradece la participación."
- **Pregunta para llevar a casa:** "¿Qué pequeña acción puedes hacer mañana para cuidar el agua?"

---
**Genera ahora el taller completo, detallado y creativo, siguiendo esta estructura y adaptándolo a los datos proporcionados.**
`;
};