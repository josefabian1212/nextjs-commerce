export const getPqrsGeneratorPrompt = (formData) => {
  const { actionType, fecha, dirigido_a, tipo_pqrs, detalles_pqrs, enviado_por, incluir_ley, incluir_radicado } = formData;
  
  const formattedDate = new Date(fecha).toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' });
  const radicado = incluir_radicado ? `PQRS-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}` : '';

  if (actionType === 'create') {
    // Prompt para redactar una PQRS para enviar
    return `
**Rol:** Actúa como un experto en comunicación y redacción de documentos formales, con conocimiento en derechos del consumidor y del ciudadano. Tu misión es redactar una PQRS (Petición, Queja, Reclamo, Sugerencia) clara, respetuosa, bien estructurada y persuasiva, para ser enviada por un ciudadano a una entidad.

La redacción debe ser formal, precisa y debe presentar los argumentos de manera lógica y coherente.

---

### **Redacción de ${tipo_pqrs}**

**Fecha:** ${formattedDate}
**Dirigido a:** ${dirigido_a}
**De parte de:** ${enviado_por}
${radicado ? `**Referencia (Radicado sugerido):** ${radicado}` : ''}

**Asunto: ${tipo_pqrs} sobre ${detalles_pqrs.substring(0, 30)}...**

---

**Cuerpo del Documento:**

[Genera aquí el texto completo de la PQRS. Sigue esta estructura:]

1.  **Saludo y Presentación:**
    *   Comienza con un saludo formal (Ej: "Respetados señores de ${dirigido_a},").
    *   Preséntate como ${enviado_por} y, si aplica, menciona tu rol (ej. "en mi calidad de ciudadano/cliente/usuario...").

2.  **Exposición de Motivos (El "Qué"):**
    *   Describe de manera clara y cronológica la situación que motiva la ${tipo_pqrs}. Utiliza los detalles proporcionados.
    *   **Detalles Clave:** \`${detalles_pqrs}\`
    *   Sé objetivo y céntrate en los hechos. Evita lenguaje emocional o agresivo.

3.  **Argumentación y Fundamento (El "Porqué"):**
    *   Explica por qué la situación es problemática o por qué se realiza la petición/sugerencia.
    *   Si es una **queja** o **reclamo**, menciona cómo te afecta o qué norma/acuerdo se podría estar incumpliendo.
    *   Si es una **petición**, explica la necesidad que la justifica.
    *   ${incluir_ley ? "Incluye una referencia genérica a la legislación aplicable del derecho de petición o de protección al consumidor, sin citar artículos específicos a menos que sea evidente." : ""}

4.  **Solicitud Concreta (El "Para Qué"):**
    *   Plantea de forma explícita y clara lo que solicitas.
    *   **Para Petición:** "Por lo anteriormente expuesto, solicito amablemente que..."
    *   **Para Queja/Reclamo:** "En consecuencia, solicito se tomen las siguientes acciones correctivas..."
    *   **Para Sugerencia:** "A modo de sugerencia constructiva, propongo considerar..."

5.  **Cierre y Despedida:**
    *   Agradece de antemano la atención prestada.
    *   Indica que quedas a la espera de una pronta respuesta.
    *   Finaliza con una despedida formal (Ej: "Atentamente," o "Cordialmente,").
    *   Firma con el nombre del remitente: ${enviado_por}.

**Instrucción Final:** Genera el texto completo de la PQRS, asegurando que sea un documento profesional, listo para ser enviado.
`;
  } else {
    // Prompt para gestionar/responder una PQRS (el original mejorado)
    return `
**Rol:** Actúa como un experto legal y comunicacional en redacción y gestión de PQRS, de acuerdo con la normatividad vigente (ej. Ley 1755 de 2015 en Colombia sobre Derecho de Petición). Tu objetivo es redactar respuestas claras, formales y persuasivas, con tono respetuoso y argumentación sólida. La redacción debe reflejar transparencia, empatía y calidad en el servicio.

La respuesta debe estar escrita en un lenguaje técnico pero accesible, y estructurada profesionalmente.

---

### **Propuesta de Respuesta a ${tipo_pqrs}**

**Fecha de Respuesta:** [Fecha Actual]
${radicado ? `**Número de Radicado:** ${radicado}` : ''}

**Señor(a):**
**${enviado_por}**

**Asunto: Respuesta a su ${tipo_pqrs} del ${formattedDate}**

---

**Cuerpo de la Respuesta:**

[Genera aquí el texto completo de la respuesta. Sigue esta estructura:]

1.  **Encabezado y Acuse de Recibo:**
    *   Inicia con un saludo cortés: "Estimado(a) Sr(a). ${enviado_por},"
    *   Confirma la recepción de la comunicación: "Hemos recibido su ${tipo_pqrs} con fecha del ${formattedDate}, relacionada con: *'${detalles_pqrs.substring(0, 50)}...'*. Agradecemos sinceramente el tiempo que ha dedicado para comunicarnos su inquietud."

2.  **Análisis de la Situación y Empatía:**
    *   Demuestra que la solicitud ha sido leída y comprendida.
    *   **Para Queja/Reclamo:** "Lamentamos sinceramente los inconvenientes que la situación descrita le haya podido ocasionar. Para nuestra entidad, ${dirigido_a}, es fundamental conocer estas experiencias para mejorar continuamente."
    *   **Para Petición/Sugerencia:** "Valoramos enormemente su interés/aporte, ya que nos permite fortalecer nuestros procesos."

3.  **Respuesta y Argumentación (El Fondo del Asunto):**
    *   Proporciona una respuesta clara y directa a la PQRS.
    *   **Para Petición:** Informa sobre el estado del trámite, los pasos a seguir o la decisión tomada. ${incluir_ley ? "Si aplica, menciona que la respuesta se emite dentro de los términos legales establecidos (ej. 15 días hábiles para peticiones generales)." : ""}
    *   **Para Queja/Reclamo:** Explica las acciones que se han tomado o se tomarán para investigar y/o corregir el problema. "Hemos iniciado una revisión interna del proceso..."
    *   **Para Sugerencia:** Agradece la idea y menciona cómo será considerada. "Su sugerencia ha sido remitida al área correspondiente para su análisis en futuros planes de mejora."
    *   **Para Felicitaciones:** "Nos complace enormemente recibir sus comentarios positivos. Su satisfacción es nuestra mayor recompensa y nos motiva a seguir trabajando con esmero."

4.  **Cierre y Disposición:**
    *   Reitera el compromiso de la entidad con el buen servicio.
    *   Ofrece un canal de contacto para futuras comunicaciones: "Si tiene alguna inquietud adicional, no dude en contactarnos a través de nuestros canales oficiales."
    *   Finaliza con una despedida formal.

5.  **Firma Institucional:**
    Atentamente,

    **${dirigido_a}**
    [Cargo/Área Opcional]
    [Correo electrónico institucional]
    [Teléfono de contacto]

**Instrucción Final:** Genera una respuesta institucional clara, respetuosa y bien estructurada, que resuelva la inquietud del ciudadano y fortalezca la imagen de la entidad.
`;
  }
};