export const getInteligenciaArtificialPrompt = (formData) => {
  const { tema_materia, grado_nivel, duracion, objetivo_pedagogico, area_aplicacion, tipo_herramienta } = formData;
  const areaString = Array.isArray(area_aplicacion) ? area_aplicacion.join(', ') : area_aplicacion;
  const herramientaString = Array.isArray(tipo_herramienta) ? tipo_herramienta.join(', ') : tipo_herramienta;

  return `
**Rol:** Actúa como un científico, desarrollador y programador experto en Inteligencia Artificial, con formación pedagógica avanzada y experiencia en el diseño de actividades escolares mediante tecnologías emergentes. Tu misión es elaborar una guía práctica, detallada y paso a paso para integrar una herramienta de IA en el aula, en función del tema, grado y objetivos pedagógicos del docente.

Tu respuesta debe tener un tono claro, profesional y orientado a educadores. Emplea una estructura ordenada con títulos y subtítulos en negrita, y redacta contenido enriquecido. La extensión esperada es de aproximadamente 5000 caracteres.

---

## **1. Información General para la Integración**

**Tema/Materia:**
${tema_materia}

**Grado/Nivel Educativo:**
${grado_nivel}

**Duración de la Integración:**
${duracion}

**Objetivo Pedagógico Principal:**
${objetivo_pedagogico}
*(Define con claridad el resultado de aprendizaje que se espera alcanzar mediante la implementación de la IA, basándote en el objetivo proporcionado: "${objetivo_pedagogico}")*

---

## **2. Área de Aplicación de la IA en el Aula**

**Área de Aplicación Seleccionada:**
${areaString}

*(La IA se utilizará en esta área para fortalecer procesos clave de enseñanza y aprendizaje. Basado en "${areaString}", profundiza en cómo esta selección impactará la clase. Por ejemplo, si se eligió "Personalización del Aprendizaje", explica cómo se adaptará el contenido al ritmo de cada estudiante.)*

---

## **3. Herramienta de IA Seleccionada**

**Tipo de Herramienta de IA Deseada:**
${herramientaString}

**Recomendación Técnica:**
*(Basado en "${herramientaString}", proporciona recomendaciones específicas y prácticas sobre qué herramienta usar y por qué es la más adecuada para el tema "${tema_materia}" y el grado "${grado_nivel}". Por ejemplo, si se eligió "Generadores de Lecciones", recomienda ChatGPT y ofrece un prompt de ejemplo que el docente pueda usar.)*

---

## **4. Etapas para Aplicar la IA en Clase**

*(Desarrolla cada una de las siguientes etapas con detalle, ofreciendo consejos prácticos y específicos para el contexto dado.)*

**A. Preparación Docente:**
- [Detalla los pasos que el docente debe seguir para investigar y prepararse para usar la herramienta recomendada.]
- [Menciona aspectos clave sobre políticas de privacidad y compatibilidad con normativas educativas.]

**B. Planeación de la Actividad:**
- [Describe cómo identificar el segmento de la clase que será optimizado con la IA.]
- [Diseña una actividad concreta para el tema "${tema_materia}", que tenga una entrada (input), un proceso (interacción con la herramienta) y una salida (producto o reflexión).]

**C. Implementación con Estudiantes:**
- [Explica la mejor manera de introducir la herramienta a estudiantes de ${grado_nivel}, explicando su utilidad y propósito.]
- [Ofrece consejos para acompañar el uso paso a paso y promover un enfoque consciente y complementario.]

**D. Evaluación del Impacto:**
- [Sugiere cómo recoger evidencias del aprendizaje alcanzado y cómo solicitar la opinión de los estudiantes sobre la experiencia.]
- [Describe cómo valorar si la IA contribuyó efectivamente al objetivo pedagógico principal.]

---

## **5. Ejemplo de Aplicación Didáctica**

*(Crea un ejemplo de aplicación didáctica detallado y específico para el tema "${tema_materia}", el grado "${grado_nivel}" y el objetivo "${objetivo_pedagogico}", utilizando las herramientas de IA recomendadas. Sigue la estructura de Inicio, Desarrollo, Actividad y Cierre.)*

**Tema:** ${tema_materia}
**Grado:** ${grado_nivel}
**Objetivo:** ${objetivo_pedagogico}
**IA Usada:** [Herramienta recomendada]

**Inicio:** [Describe la actividad inicial.]
**Desarrollo:** [Explica la interacción con la IA.]
**Actividad:** [Detalla el producto que crearán los estudiantes.]
**Cierre:** [Describe la reflexión final.]

---

## **6. Sugerencias de Seguridad y Ética**
- [Ofrece consejos específicos sobre cómo educar a los estudiantes de ${grado_nivel} sobre el uso ético y responsable de la IA.]
- [Refuerza la importancia de verificar la protección de datos y fomentar el pensamiento crítico frente a los resultados generados por la IA.]

---

## **7. Adaptaciones e Inclusión**
- [Proporciona sugerencias concretas para adaptar el uso de la herramienta recomendada para estudiantes con diversas necesidades, asegurando que la actividad sea inclusiva.]

---
**Genera ahora la guía completa, siguiendo esta plantilla en formato Markdown.**
`;
};