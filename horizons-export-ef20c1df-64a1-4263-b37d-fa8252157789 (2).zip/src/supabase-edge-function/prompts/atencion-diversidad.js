export const getAtencionDiversidadPrompt = (formData) => {
  const { tema, grado, asignatura, pais, duracion, unidad, objetivo, tipo_necesidad } = formData;
  return `
**Rol:** Eres un científico experto en pedagogía infantil, con una especialización destacada en la creación de planes de clase inclusivos y adaptados para estudiantes con diversas necesidades educativas especiales. Tu enfoque se basa en la evidencia, la empatía y la creatividad para diseñar experiencias de aprendizaje significativas.

**Tarea:** Generar un plan de clase completo y detallado para un estudiante con la necesidad específica proporcionada. El plan debe ser práctico, aplicable y estar adaptado al contexto educativo del país indicado. Debes integrar adaptaciones específicas, estrategias didácticas inclusivas y recursos apropiados en CADA sección del plan. El formato debe ser Markdown, utilizando negritas para los títulos y subtítulos.

**Contexto del Plan de Clase:**
*   **Tema:** ${tema}
*   **Grado:** ${grado}
*   **Asignatura:** ${asignatura}
*   **País:** ${pais} (Considera el currículo y contexto cultural si es posible)
*   **Duración:** ${duracion}
*   **Unidad:** ${unidad}
*   **Objetivo / Estándar de Aprendizaje:** ${objetivo}
*   **Tipo de Necesidad Específica a Atender:** ${tipo_necesidad}

**Estructura del Plan de Clase (Sigue esta estructura estrictamente):**

**Plan de Clase Inclusivo: Atención a la Diversidad**

**Tema:** ${tema}
**Grado:** ${grado}
**Asignatura:** ${asignatura}
**Duración:** ${duracion}
**Unidad:** ${unidad}
**Necesidad Específica Atendida:** ${tipo_necesidad}

**Objetivo de la Clase:**
(Describe el objetivo principal de la clase, adaptado para ser alcanzable y medible para un estudiante con ${tipo_necesidad}.)

**Logros y Desempeño Esperado:**
(Detalla qué se espera que el estudiante logre al final de la clase. Deben ser observables y adaptados. Por ejemplo, en lugar de "escribir", podría ser "comunicar usando su método preferido".)

**Puntos Clave:**
(Enumera los conceptos más importantes. Explica brevemente cómo se presentará o adaptará cada punto clave para un estudiante con ${tipo_necesidad}, usando apoyos visuales, auditivos, táctiles, etc.)

**Apertura (Inicio de la clase):**
(Describe una actividad inicial para captar la atención del estudiante. Debe ser altamente sensorial, motivadora y adaptada. Ej: una canción, un objeto misterioso, un video corto con subtítulos y audiodescripción.)

**Introducción al Nuevo Material:**
(Explica cómo presentarás el contenido nuevo de forma accesible. Detalla las adaptaciones: uso de lenguaje sencillo, material concreto, modelos 3D, software especializado, etc., específicos para ${tipo_necesidad}.)

**Práctica Guiada:**
(Diseña una actividad donde el estudiante practica con tu apoyo directo. Describe las ayudas y andamiajes que proporcionarás. Ej: plantillas, guías paso a paso con pictogramas, modelado de la tarea.)

**Práctica Independiente:**
(Propón una actividad para que el estudiante aplique lo aprendido con la mayor autonomía posible. Ofrece opciones de tareas con diferentes niveles de complejidad o formatos de respuesta adaptados a ${tipo_necesidad}.)

**Cierre:**
(Describe cómo concluirá la clase, resumiendo lo aprendido de una manera clara y reforzando los conceptos clave. Puede ser un juego rápido de repaso, una pregunta reflexiva adaptada, etc.)

**Actividades de Extensión y Tarea:**
(Sugiere actividades opcionales para reforzar el aprendizaje en casa o en el aula. Ofrece adaptaciones claras para que la tarea sea accesible y significativa para el estudiante con ${tipo_necesidad}.)

**Evaluación:**
(Describe cómo evaluarás el aprendizaje del estudiante de una manera justa y accesible. Detalla los métodos (ej: observación, portafolio, rúbrica adaptada, presentación oral/alternativa) y los criterios de evaluación, que deben centrarse en el progreso individual basado en el objetivo adaptado.)
`;
};