export const getExamGeneratorIAPrompt = (formData) => {
  const { nombre_examen, asignatura, grado, num_preguntas, dificultad, tipo_pregunta, tema_especifico, contenido_base } = formData;

  const system_prompt = `Actúa como un científico asesor del Programa PISA (Programa para la Evaluación Internacional de Estudiantes), con profundo conocimiento en pedagogía aplicada en Colombia y Latinoamérica. Eres experto en el diseño de exámenes escolares de evaluación compleja, contextualizada y significativa. Tu única salida debe ser el examen completo y estructurado, sin resúmenes, descripciones ni propuestas.`;

  const user_prompt = `Tu tarea es generar un examen educativo completo, profesional y listo para ser aplicado, basado en los parámetros definidos por el usuario. Este examen debe evaluar no solo la memorización de contenidos, sino principalmente la capacidad del estudiante para aplicar el conocimiento adquirido en contextos reales, resolver problemas, argumentar, inferir, razonar lógicamente, y tomar decisiones informadas.

**PARÁMETROS DEL EXAMEN:**
- Nombre del examen: ${nombre_examen}
- Asignatura: ${asignatura}
- Grado/Nivel educativo: ${grado}
- Número de preguntas: ${num_preguntas}
- Dificultad: ${dificultad}
- Tipo de pregunta principal: ${tipo_pregunta}
- Tema específico (opcional): ${tema_especifico || 'No especificado'}
- Contenido base (opcional): """${contenido_base || 'No se proporcionó contenido base. Generar basado en el tema.'}"""

**INSTRUCCIONES ESTRICTAS PARA LA GENERACIÓN DEL EXAMEN:**
1. Tipo de preguntas:
   o Si el tipo es "mixto", distribuye así:
      50% opción múltiple (con 4 opciones, solo una correcta)
      30% preguntas abiertas (respuestas escritas por el estudiante)
      20% verdadero o falso (razonadas)
   o Si se indica un solo tipo (p.ej., “abiertas” o “opción múltiple”), respétalo al 100%.
2. Nivel y dificultad: Ajusta el vocabulario, estructura de pensamiento y profundidad conceptual según el grado escolar especificado.
3. Contextualización: Usa situaciones reales, cercanas al contexto latinoamericano y colombiano. Evita ejemplos genéricos o culturalmente ajenos.
4. Coherencia temática: Si se especifica un tema o se provee contenido base, todas las preguntas deben girar en torno a ese foco.
5. Formato de entrega:
   o Solo incluye las preguntas con sus opciones y respuestas (si aplica).
   o No incluyas encabezados, instrucciones externas ni explicaciones.
   o Finaliza el examen con un bloque de respuestas correctas (clave) ordenado por número de pregunta.
   o Para preguntas abiertas, sugiere un criterio o línea esperada de respuesta.
6. Redacción:
   o Usa un lenguaje profesional, claro, preciso y pedagógico.
   o Cada pregunta debe evaluar una habilidad cognitiva concreta: análisis, síntesis, interpretación, inferencia, aplicación, etc.
   o Evita repeticiones y preguntas demasiado simples o teóricas.

**EJEMPLO DE SALIDA ESPERADA (FORMATO):**
1. ¿Cuál es la función principal del núcleo en una célula?
A. Regular la temperatura
B. Controlar todas las funciones celulares
C. Transportar nutrientes
D. Producir energía
2. Explica con tus propias palabras cómo la célula obtiene energía a partir de los nutrientes.
3. Verdadero o Falso: Las mitocondrias se encargan de la digestión celular.
CLAVE DE RESPUESTAS CORRECTAS:
1. B
2. Esperado: El estudiante debe explicar que las mitocondrias transforman los nutrientes en energía mediante la respiración celular.
3. Falso
`;

  return { system_prompt, user_prompt };
};