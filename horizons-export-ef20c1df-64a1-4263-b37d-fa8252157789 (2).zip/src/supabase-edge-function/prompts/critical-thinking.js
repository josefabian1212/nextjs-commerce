export const getCriticalThinkingPrompt = (formData) => {
  const { tema_taller, grado_nivel, duracion, objetivo_principal, tipo_actividad } = formData;
  return `
**Rol:** Actúa como un científico creador de talleres de Pensamiento Crítico, con formación en pedagogía avanzada y programación neurolingüística, experto en diseñar actividades educativas orientadas a desarrollar el análisis, la argumentación y la toma de decisiones reflexiva. Tu misión es generar una guía práctica y detallada para implementar un taller efectivo de pensamiento crítico, adaptado al grado, tema y tipo de actividad seleccionada.

La respuesta debe estar redactada en un tono claro, profesional y dirigido a docentes. Usa una estructura ordenada con títulos y subtítulos en negrita. La salida debe tener aproximadamente 4000 a 5000 caracteres.

---

## **Taller de Pensamiento Crítico: Guía para el Docente**

**📌 Tema del Taller:** ${tema_taller}
**🎓 Grado / Nivel:** ${grado_nivel}
**⏱️ Duración:** ${duracion}
**🎯 Objetivo Principal:** ${objetivo_principal}
**🧩 Tipo de Actividad Principal:** ${tipo_actividad}

---

### **1. Introducción y Activación Cognitiva (5 min)**
*(El objetivo de esta fase es captar el interés y activar el pensamiento previo de los estudiantes sobre "${tema_taller}".)*

**Actividad Sugerida:**
[Genera aquí una actividad de inicio específica y creativa.
- **Si el tema es sobre redes sociales:** "Muestra dos titulares de noticias sobre el mismo evento, uno de una fuente conservadora y otro de una progresista. Pregunta: ¿Qué diferencias notan? ¿Por qué creen que existen estas diferencias?".
- **Si el tema es sobre un dilema ético:** "Presenta una situación hipotética corta y ambigua. Por ejemplo: 'Un médico tiene un solo respirador y dos pacientes que lo necesitan para sobrevivir. ¿Qué debería hacer?'. Pide una votación rápida a mano alzada sin justificación previa."
- **Si el tema es sobre ciencia:** "Muestra una imagen o un video corto de un 'mito popular' (ej. los rayos no caen dos veces en el mismo lugar) y pregunta: ¿Creen que esto es cierto? ¿Cómo podríamos saberlo con seguridad?".]

---

### **2. Explicación del Objetivo del Taller (3 min)**
*(Conecta la actividad con el propósito de la sesión de una manera clara y relevante para los estudiantes de ${grado_nivel}.)*

**Discurso Sugerido:**
"Lo que acabamos de ver/discutir es un ejemplo perfecto de por qué el pensamiento crítico es una superpotencia. Hoy no vamos a buscar respuestas correctas, vamos a aprender a hacer mejores preguntas. Nuestro objetivo es **${objetivo_principal}**. Esta habilidad no solo les servirá para aprobar ${grado_nivel}, sino para tomar mejores decisiones, desde elegir qué creer en internet hasta resolver problemas en su vida diaria."

---

### **3. Desarrollo de la Actividad Principal: ${tipo_actividad} (25-30 min)**
*(Esta es la fase central. A continuación se detalla el paso a paso para la actividad seleccionada.)*

[Genera aquí una guía detallada para la actividad "${tipo_actividad}", adaptada al tema "${tema_taller}".
- **Si es "Debates estructurados":** Define los dos equipos (A favor/En contra). Establece 3 rondas: 1) Argumento inicial (3 min por equipo), 2) Refutación (2 min por equipo), 3) Conclusión (1 min por equipo). Proporciona una lista de 2-3 preguntas guía para que preparen sus argumentos.
- **Si es "Análisis de falacias lógicas":** Proporciona un texto corto (un tuit, un comentario de un foro, un fragmento de un discurso) que contenga 2-3 falacias comunes (ej. Ad Hominem, Hombre de Paja, Falsa Dicotomía). Pide a los estudiantes que, en parejas, identifiquen la falacia, la nombren y expliquen por qué el argumento es débil.
- **Si es "Evaluación de fuentes":** Entrega a cada grupo 3 artículos sobre "${tema_taller}" de distintas fuentes (un blog, un periódico reconocido, un estudio científico). Proporciona una checklist con criterios: ¿Quién es el autor? ¿Cuál es el propósito del texto? ¿Presenta evidencia o solo opiniones? ¿El lenguaje es objetivo o emocional?
- **Si es "Discusión socrática":** Organiza al grupo en un círculo. El docente actúa como facilitador y lanza la primera pregunta abierta (ej. "¿Qué significa realmente 'ser libre' en la era digital?"). A partir de las respuestas, el docente hace repreguntas que profundicen, clarifiquen y cuestionen supuestos (ej. "¿Qué quieres decir con 'privacidad'? ¿Puedes dar un ejemplo? ¿Qué pasaría si todos pensaran así?").]

---

### **4. Reflexión y Cierre (5 min)**
*(El objetivo es consolidar el aprendizaje y fomentar la metacognición.)*

**Guía para la Reflexión:**
[Pide a los estudiantes que respondan en silencio una de las siguientes preguntas en un post-it o cuaderno, y luego comparte algunas respuestas voluntarias.]
- **Pregunta 1 (Cambio de Perspectiva):** ¿Qué idea o creencia que tenías sobre "${tema_taller}" se ha fortalecido o debilitado después de esta actividad?
- **Pregunta 2 (Transferencia de Habilidad):** ¿En qué otra situación (fuera de esta clase) podrías usar la habilidad que practicamos hoy?
- **Pregunta 3 (Autoevaluación del Proceso):** ¿Cuál fue el momento más difícil para ti durante la actividad y cómo lo superaste?

---

### **5. Evaluación del Pensamiento Crítico**
*(Sugiere un método de evaluación formativa, rápido y centrado en el proceso.)*

**Instrumento Sugerido: Rúbrica Rápida de Observación**
[Crea una tabla simple que el docente pueda usar para evaluar a los grupos o individuos durante la actividad.]

| Habilidad Observada                      | Nivel 1: Inicial                               | Nivel 2: En Desarrollo                         | Nivel 3: Consolidado                           |
| ---------------------------------------- | ---------------------------------------------- | ---------------------------------------------- | ---------------------------------------------- |
| **Claridad al Argumentar**               | Las ideas son confusas o no se conectan.       | Expresa ideas, pero necesita mejorar la estructura. | Presenta argumentos de forma lógica y clara.   |
| **Uso de Evidencia/Ejemplos**            | Se basa solo en opiniones personales.          | Menciona alguna evidencia, pero sin desarrollarla. | Respalda sus argumentos con ejemplos o datos.  |
| **Escucha y Respeto a Otras Ideas**      | Interrumpe o descalifica otras opiniones.      | Escucha, pero no integra las ideas de otros.   | Escucha activamente y responde a otras ideas.  |

---

### **6. Sugerencias de Adaptación**
- **Para grupos con menor confianza:** Usa la técnica "Think-Pair-Share". Primero piensan individualmente, luego discuten en parejas y finalmente comparten en grupo. Esto reduce la presión.
- **Para niveles avanzados (${grado_nivel}):** Introduce textos más complejos o abstractos. Pide no solo que identifiquen problemas, sino que propongan soluciones o argumentos alternativos.
- **Para estilos de aprendizaje kinestésicos:** Usa tarjetas que puedan mover y organizar, o pídeles que representen físicamente las diferentes posturas de un debate.

---
**Genera ahora el taller completo y detallado siguiendo esta estructura, basado en los datos proporcionados. El resultado debe ser aplicable, con fundamentación pedagógica y orientado a desarrollar el pensamiento crítico de forma práctica.**
`;
};