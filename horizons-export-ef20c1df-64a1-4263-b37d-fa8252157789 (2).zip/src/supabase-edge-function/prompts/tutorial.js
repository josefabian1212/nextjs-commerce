export const getTutorialPrompt = (formData) => {
  const { tema_tutorial, grade, difficulty, objective, format } = formData;
  const formatString = Array.isArray(format) ? format.join(', ') : format;

  return `
**Rol:** Actúa como un educador experto en redacción pedagógica y desarrollo de contenidos académicos, con experiencia en la creación de **tutoriales educativos claros, detallados y adaptados al nivel del estudiante**. Crea un tutorial basado en la siguiente información, teniendo en cuenta el nivel de dificultad, el grado y el objetivo de aprendizaje. La estructura debe estar organizada con **títulos y subtítulos en negrita**, usando un tono claro, amigable y didáctico. La salida debe tener aproximadamente **4000 caracteres**.

---

**📚 Tema del Tutorial:**
${tema_tutorial}

**🎓 Grado:**
${grade}

**📈 Nivel de Dificultad:**
${difficulty}

**🎯 Objetivo del Tutorial:**
${objective}

**🧾 Formato Solicitado:**
${formatString}

---

## ✍️ **Introducción al Tema**
[Presenta el tema de forma atractiva. Explica brevemente por qué es importante y cómo se relaciona con el mundo real o con otras áreas del conocimiento. Adecúa el lenguaje según el grado del estudiante: ${grade}.]

---

## 🧠 **Objetivos del Tutorial**
- [Genera una lista de 2 a 4 objetivos concretos que el estudiante logrará al finalizar el tutorial, redactados de forma clara y alcanzable, basados en el objetivo principal: "${objective}".]
- [Ejemplo: Comprender el proceso de la fotosíntesis, identificar los elementos involucrados, aplicar el conocimiento en un experimento escolar.]

---

## 🔍 **Paso a Paso del Proceso**

**Paso 1 – [Define un subtema o etapa inicial del proceso]:**
[Proporciona una explicación clara y detallada de la primera parte del contenido. Usa ejemplos o analogías si es necesario, adaptados al nivel ${difficulty}.]

**Paso 2 – [Define un subtema o etapa intermedia]:**
[Continúa desarrollando el proceso, manteniendo un orden lógico y una progresión clara en la dificultad.]

**Paso 3 – [Define un subtema o etapa avanzada]:**
[Incluye advertencias sobre errores comunes, consejos prácticos para evitar dificultades, o sugerencias para optimizar el proceso.]

**Paso 4 – [Define un subtema o etapa de verificación]:**
[Si aplica, explica cómo el estudiante puede evaluar si ha completado el paso o el proceso correctamente.]

---

## 🧰 **Materiales y Recursos Necesarios**
[Genera una lista clara y específica de los materiales, recursos digitales o físicos que se requieren para desarrollar el tutorial. Si el formato solicitado (${formatString}) lo permite, sugiere la inclusión de apoyos visuales o enlaces a recursos externos.]

---

## 💡 **Consejos Prácticos**
[Incluye entre 3 y 5 recomendaciones útiles para mejorar el aprendizaje del tema. Pueden ser técnicas de estudio, formas creativas de abordar el contenido, o ideas para hacerlo más interactivo y divertido.]

---

## 🧪 **Actividad de Aplicación (Opcional)**
[Si el tutorial lo permite (especialmente para formatos escolares), propone una actividad final para aplicar lo aprendido. Puede ser una maqueta, una presentación, un dibujo, un experimento, un cuestionario, etc.]

---

## 📊 **Evaluación Sugerida**
[Describe brevemente cómo el estudiante o el docente pueden verificar que el conocimiento fue comprendido. Puede incluir una lista de autoevaluación, una lista de cotejo simple, preguntas clave, o criterios para una rúbrica.]

---

## 🧩 **Extensión o Profundización**
[Proporciona 1 o 2 ideas para ampliar el conocimiento o conectar el tema con otras áreas del saber. Ejemplo: “Si quieres saber más sobre cómo las plantas se alimentan por la noche, investiga el proceso de respiración celular.”]

---

**Crea ahora el tutorial educativo completo, siguiendo esta plantilla en formato Markdown.**
`;
};