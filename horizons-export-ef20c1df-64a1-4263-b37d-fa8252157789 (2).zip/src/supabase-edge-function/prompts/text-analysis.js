export const getTextAnalysisPrompt = (formData) => {
  const { 
    texto_a_analizar, 
    contexto_personalizado, 
    procesamiento_basico, 
    analisis_profundo, 
    mejora_texto, 
    generacion_contenida, 
    traduccion_inteligente, 
    mapa_conceptual 
  } = formData;

  let prompt = `
**Rol:** Actúa como un científico experto en Análisis Textual, con formación avanzada en pedagogía del lenguaje y programación aplicada al procesamiento de textos. Tu misión es analizar el siguiente texto, generando insights útiles y estructurados a partir del contexto y las opciones de análisis activadas.

**Texto a Analizar:**
\`\`\`
${texto_a_analizar}
\`\`\`

**Contexto del Análisis:**
*   **Tipo de Texto y Finalidad:** ${contexto_personalizado}

---

## **Análisis Solicitado**
*(A continuación, se presentan los resultados del análisis según las opciones que seleccionaste.)*
`;

  if (procesamiento_basico && procesamiento_basico.length > 0) {
    prompt += `\n### **Procesamiento Básico**\n`;
    procesamiento_basico.forEach(opcion => {
      prompt += `*   **${opcion}:** [Genera aquí el análisis para '${opcion}']\n`;
    });
  }

  if (analisis_profundo && analisis_profundo.length > 0) {
    prompt += `\n### **Análisis Profundo**\n`;
    analisis_profundo.forEach(opcion => {
      prompt += `*   **${opcion}:** [Genera aquí el análisis para '${opcion}']\n`;
    });
  }

  if (mejora_texto && mejora_texto.length > 0) {
    prompt += `\n### **Mejora del Texto**\n`;
    mejora_texto.forEach(opcion => {
      prompt += `*   **${opcion}:** [Genera aquí el análisis para '${opcion}']\n`;
    });
  }
  
  if (generacion_contenida && generacion_contenida.length > 0) {
    prompt += `\n### **Generación Contenida**\n`;
    generacion_contenida.forEach(opcion => {
      prompt += `*   **${opcion}:** [Genera aquí el análisis para '${opcion}']\n`;
    });
  }

  if (traduccion_inteligente || mapa_conceptual) {
    prompt += `\n### **Opciones Adicionales**\n`;
    if (traduccion_inteligente) {
      prompt += `*   **Traducción inteligente (Inglés):** [Traduce el texto completo al inglés, respetando el estilo y contexto.]\n`;
    }
    if (mapa_conceptual) {
      prompt += `*   **Ideas para mapa conceptual:** [Sugiere una estructura de mapa conceptual con un nodo central, nodos principales y secundarios para representar visualmente la información del texto.]\n`;
    }
  }

  prompt += `
---
**Instrucción Final:** Analiza el texto ingresado utilizando las opciones seleccionadas. Tu análisis debe ser profundo, coherente y útil para tomar decisiones, mejorar la redacción o interpretar el contenido de manera eficaz. Adapta el lenguaje según el tipo de texto y contexto definido.
`;

  return prompt;
};