export const getCognitiveAnalysisPrompt = (formData) => {
  const { 
    tema_analizar, 
    grado_nivel, 
    nivel_profundidad, 
    tipo_razonamiento, 
    tipo_analisis_especifico, 
    tipo_creatividad_percepcion 
  } = formData;

  const selectedAnalyses = [tipo_razonamiento, tipo_analisis_especifico, tipo_creatividad_percepcion].filter(a => a && a !== 'Ninguno').join(', ');

  return `
**Rol:** Actúa como un científico experto en aplicar talleres para desarrollar el Análisis Cognitivo en los estudiantes dentro del aula. Eres especialista en pedagogía cognitiva, con formación avanzada en programación neurolingüística y amplia experiencia en el diseño de actividades educativas centradas en habilidades cognitivas superiores. Tu misión es crear una guía práctica, paso a paso, para aplicar el análisis cognitivo según el tema, nivel educativo y tipos de razonamiento o análisis seleccionados por el docente.

La respuesta debe estar escrita con un tono claro, profesional y enfocado a docentes. Usa títulos y subtítulos en negrita y estructura el contenido de manera ordenada. La salida debe tener aproximadamente 4000 a 5000 caracteres.

---

## **Guía de Taller de Análisis Cognitivo**

**📌 Tema a Analizar:** ${tema_analizar}
**🎓 Grado / Nivel Educativo o Contexto:** ${grado_nivel}
**🔬 Nivel de Profundidad del Análisis:** ${nivel_profundidad}
**🧠 Tipos de Análisis Seleccionados:** ${selectedAnalyses}

---

### **1. Activación Cognitiva Inicial (Duración: 5 minutos)**
*(Objetivo: Despertar la curiosidad y activar los conocimientos previos de los estudiantes sobre "${tema_analizar}".)*

**Actividad Sugerida:**
[Genera aquí una actividad de inicio específica y potente, adaptada al tema y al grado.
- **Ejemplo para "Impacto de la IA en la educación":** Muestra una imagen generada por IA que represente un aula futurista y lanza la pregunta: *“¿Es esto el futuro del aprendizaje o una amenaza para los profesores? ¿Qué emociones les genera esta imagen?”*. Pide una lluvia de ideas rápida con 3-5 palabras clave.]
- **Ejemplo para "Cambio Climático":** Proyecta un video de 1 minuto sin sonido que muestre dos escenarios contrastantes (un ecosistema vibrante y uno devastado). Pide a los estudiantes que escriban en una palabra lo que sintieron al ver cada escenario.]

---

### **2. Desarrollo del Análisis Cognitivo (Duración: 30-35 minutos)**
*(Objetivo: Aplicar los tipos de análisis seleccionados para descomponer, interpretar y evaluar el tema de forma estructurada.)*

**Organización:**
- **Grupos de Expertos:** Divide la clase en pequeños equipos. A cada equipo se le puede asignar un rol o un tipo de análisis específico (${selectedAnalyses}) para que se conviertan en "expertos" en esa perspectiva.

**Guía para cada tipo de análisis:**

[Genera una guía detallada y con ejemplos para cada uno de los análisis seleccionados. Asegúrate de que las instrucciones sean claras para estudiantes de ${grado_nivel}.]

- **Si se seleccionó Razonamiento (${tipo_razonamiento}):**
    - **Razonamiento lógico:** "Analicen la siguiente premisa: 'Si la IA puede personalizar el aprendizaje, entonces los resultados académicos mejorarán'. ¿Es una conclusión válida? ¿Qué otras premisas se necesitan para que el argumento sea sólido?". Proporciona un esquema de argumento (Premisa 1, Premisa 2, Conclusión).
    - **Razonamiento abstracto:** "Representen el concepto de 'Inteligencia Artificial' usando solo 3 símbolos o una metáfora visual. Expliquen su elección."
    - **Razonamiento filosófico:** "Debatan: ¿Es ético usar IA para evaluar a los estudiantes? ¿Qué define una evaluación 'justa'?".

- **Si se seleccionó Análisis Específico (${tipo_analisis_especifico}):**
    - **Resolución de problemas:** "El problema es: 'La IA puede crear una brecha digital aún mayor en la educación'. Usando un diagrama de causa-efecto (espina de pescado), identifiquen 3 causas principales de este problema y propongan una solución para cada una."
    - **Análisis textual:** "Lean un artículo corto sobre IA en la educación. Identifiquen la tesis del autor, los 3 argumentos principales que usa para apoyarla y el tono del texto (optimista, pesimista, neutral)."
    - **Análisis axiológico:** "Hagan una lista de los valores (ej. eficiencia, equidad, autonomía, seguridad) que están en juego al implementar IA en las aulas. ¿Qué valores entran en conflicto?".

- **Si se seleccionó Creatividad y Percepción (${tipo_creatividad_percepcion}):**
    - **Despertar la creatividad textual:** "Escriban un micro-cuento de 100 palabras desde la perspectiva de un estudiante del año 2050 que tiene un tutor de IA."
    - **Despertar la creatividad artística:** "Diseñen el logo o el póster de una campaña para promover el uso ético de la IA en su escuela."
    - **Despertar la creatividad filosófica:** "Planteen una paradoja: 'Si una IA aprende todo de nosotros, ¿llega un punto en que la IA nos enseña a ser más humanos?'".

**Herramientas Sugeridas:**
- Mapas mentales (para organizar ideas).
- Tablas T (para comparar pros y contras).
- Diagramas de Venn (para comparar conceptos).

---

### **3. Actividad de Síntesis y Producción (Duración: 10 minutos)**
*(Objetivo: Consolidar y comunicar los hallazgos del análisis de una manera clara y creativa.)*

**Producto Final:**
- Cada grupo de expertos deberá sintetizar su análisis en un formato rápido y visual.
- **Sugerencias:**
    - **Tweet-Resumen:** Condensar la conclusión principal en menos de 280 caracteres.
    - **Infografía Rápida:** Crear un esquema visual en una cartulina o pizarra digital con los 3 hallazgos más importantes.
    - **Pitch de 1 Minuto:** Presentar oralmente su análisis como si estuvieran convenciendo a la junta directiva de la escuela.

---

### **4. Evaluación Formativa y Reflexión Final (Duración: 10 minutos)**
*(Objetivo: Fomentar la metacognición y la evaluación entre pares.)*

**Coevaluación (Técnica de "Dos Estrellas y un Deseo"):**
- Cada grupo observa la presentación de otro.
- Anotan **dos fortalezas ("estrellas")** del análisis presentado.
- Anotan **una sugerencia de mejora ("un deseo")**.
- Se comparten las retroalimentaciones de forma constructiva.

**Reflexión Global Guiada por el Docente:**
[Plantea 2-3 preguntas profundas para cerrar el taller.]
1.  "Después de analizar '${tema_analizar}' desde diferentes ángulos, ¿ha cambiado su opinión inicial? ¿Cómo?"
2.  "¿Qué tipo de razonamiento o análisis les resultó más útil para entender la complejidad del tema? ¿Y cuál fue el más difícil?"
3.  "¿Cómo pueden aplicar este tipo de análisis a otras asignaturas o a problemas de su vida diaria?"

---
**Genera ahora la guía completa del taller, siguiendo esta estructura y adaptándola a los datos proporcionados. El resultado debe ser una herramienta práctica para que el docente desarrolle habilidades de pensamiento superior en el aula.**
`;
};