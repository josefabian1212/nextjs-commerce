export const getPodcastPrompt = (formData) => {
    const { titulo, tema_central, objetivo, formato, duracion, publico, tono, tipo } = formData;
    return `
**Rol:** Actúa como un experto en producción de pódcasts, con dominio en guionismo, comunicación efectiva y narrativas de alto impacto. Tu objetivo es crear un **guion completo y profesional** para un episodio de pódcast, adaptado al tono, estilo, público y objetivo seleccionados.

---

### 📋 Datos entregados por el creador del episodio:

- **🎙️ Título del Episodio:** ${titulo}
- **📌 Tema Central:** ${tema_central}
- **🎯 Objetivo del episodio:** ${objetivo}
- **🎧 Formato de presentación:** ${formato}
- **⏱️ Duración Estimada:** ${duracion}
- **👥 Público Objetivo:** ${publico}
- **🎭 Tono:** ${tono}
- **🔖 Tipo de pódcast:** ${tipo}

---

## 🧠 Instrucciones para la generación del guion:

1.  Crea un **guion profesional completo** de aproximadamente 3000 caracteres, estructurado en Markdown y adaptado al tono, formato y tipo indicado.

2.  Estructura el episodio en partes claras con subtítulos en negrita. Incluye:
    -   Introducción impactante
    -   Desarrollo temático (3 o más bloques según formato)
    -   Preguntas clave (si es entrevista)
    -   Llamado a la acción o reflexión final

3.  Integra elementos de **narración persuasiva o educativa** según el objetivo:
    -   Usa ejemplos, metáforas, anécdotas o datos reales.
    -   Aplica pausas y transiciones naturales (“¿Y si te dijera que…?”, “Ahora bien…”).

4.  Usa un lenguaje adecuado para el público objetivo.
    -   Si es infantil, usa frases sencillas.
    -   Si es profesional, usa un lenguaje técnico pero claro.

5.  Incluye un **cierre emocional o memorable**, que invite a reflexionar, compartir o actuar.

---

## 📝 Formato esperado:

**🎙️ Título del Episodio:**
${titulo}

---

**🔍 Introducción:**
[Genera una frase de entrada que capture la atención. Presenta el tema y por qué es relevante para el oyente, conectando con el público objetivo: ${publico}.]

---

**🧩 Desarrollo del Episodio:**

**Bloque 1 – [Define un subtema relevante]:**
[Desarrolla el primer argumento, ejemplo, historia o dato. Mantén el tono ${tono}.]

**Bloque 2 – [Define un segundo subtema]:**
[Profundiza en el tema o presenta una perspectiva diferente. Si el formato es ${formato}, adáptalo aquí (ej. si es conversacional, simula un diálogo). Puede incluir una analogía, storytelling o un contrapunto.]

**Bloque 3 – [Define un tercer subtema]:**
[Ofrece conclusiones intermedias, cierra el hilo argumental principal o crea una transición hacia el final del episodio.]

---

**🎯 Si es una Entrevista:**

**Preguntas sugeridas para el invitado:**
1.  [Genera una pregunta abierta e interesante para iniciar]
2.  [Genera una pregunta que profundice en un aspecto clave del tema]
3.  [Genera una pregunta que invite a la reflexión o a compartir una experiencia personal]
*(Las preguntas deben provocar reflexión o revelación del experto, adecuadas para el tema "${tema_central}")*

---

**📣 Cierre del Episodio:**
[Crea un mensaje final persuasivo, emotivo o provocador, según el tono ${tono}. Incluye un llamado a la acción claro y directo relacionado con el objetivo: ${objetivo} (Ej: “Suscríbete”, “Comparte tu opinión”, “Reflexiona sobre esto”).]

---

**🔗 Frase de despedida opcional:**
[Genera una frase de despedida memorable y coherente con el tipo de pódcast: ${tipo}.]

---
**Consideraciones finales:** No excedas los 3000 caracteres. Mantén el tono constante. Estructura de forma clara, fluida y profesional. La salida debe ser completamente en formato Markdown.
`;
};