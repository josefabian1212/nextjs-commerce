export const getEducationalProjectPrompt = (formData) => {
    const {
        nombre_proyecto,
        problema_detectado,
        justificacion,
        delimitacion,
        verbo_objetivo_general,
        objetivo_general,
        objetivos_especificos,
        actividades,
        presupuesto,
        moneda,
        fecha_inicio,
        fecha_fin,
        instrumentos_evaluacion,
    } = formData;

    const system_prompt = `Actúa como una experta multidisciplinaria en innovación educativa, análisis de datos, investigación pedagógica y aplicación social, para guiar al usuario en la creación de un proyecto educativo robusto y viable. Tu respuesta debe ser un documento profesional y estructurado con más de 3000 caracteres.`;

    const user_prompt = `
A partir de la siguiente información, genera un documento de proyecto educativo completo, profesional y listo para descargar o editar. Sigue la estructura y formato Markdown proporcionados.

**INFORMACIÓN DEL FORMULARIO:**
- **Nombre del Proyecto:** ${nombre_proyecto}
- **Problema o Necesidad Detectada:** ${problema_detectado}
- **Justificación:** ${justificacion}
- **Delimitación:** ${delimitacion || 'No especificada'}
- **Objetivo General:** ${verbo_objetivo_general || ''} ${objetivo_general}
- **Objetivos Específicos:** ${objetivos_especificos && objetivos_especificos.length > 0 ? objetivos_especificos.map(o => `- ${o.texto}`).join('\n') : 'No especificados'}
- **Actividades Principales:** ${actividades && actividades.length > 0 ? actividades.map(a => `- ${a.nombre} (Responsable: ${a.responsable}, Duración: ${a.duracion})`).join('\n') : 'No especificadas'}
- **Presupuesto Aproximado:** ${presupuesto || 'No especificado'} ${moneda || 'USD'}
- **Fechas:** Inicio: ${fecha_inicio || 'No especificada'}, Fin: ${fecha_fin || 'No especificada'}
- **Instrumentos de Evaluación:** ${instrumentos_evaluacion && instrumentos_evaluacion.length > 0 ? instrumentos_evaluacion.join(', ') : 'No especificados'}

**ESTRUCTURA DEL DOCUMENTO DE SALIDA (FORMATO MARKDOWN):**

# Proyecto: ${nombre_proyecto}

## 1. Introducción
### Contexto
(Describe el contexto general donde se enmarca el proyecto. Amplía la información proporcionada sobre el problema para dar una visión completa del entorno.)

### Problema Detectado
(Reformula y detalla el problema o necesidad detectada. Explica su impacto y por qué es importante abordarlo.)

## 2. Justificación
### Relevancia del Proyecto
(Expande la justificación proporcionada. Explica por qué este proyecto es importante, necesario y pertinente en el contexto actual.)

### Marco Normativo y de Referencia
(Sugiere un marco legal o institucional relevante. Por ejemplo, "Este proyecto se alinea con la Ley General de Educación en su artículo X..." o "Se basa en los principios del Proyecto Educativo Institucional (PEI) 2024...". Menciona su alineación con ODS si es pertinente, como ODS 4: Educación de Calidad.)

## 3. Diagnóstico
(Elabora una breve sección de diagnóstico. Sugiere métodos para recolectar datos cualitativos y cuantitativos. Por ejemplo, "Para validar la necesidad, se sugiere realizar una encuesta inicial a los estudiantes y una sesión de grupo focal con los docentes.")

## 4. Objetivos del Proyecto
### Objetivo General
**${verbo_objetivo_general || ''} ${objetivo_general}**

### Objetivos Específicos y Metas SMART
(Toma los objetivos específicos proporcionados y transfórmalos en metas SMART. Si no se proporcionaron, crea 3 objetivos SMART basados en el objetivo general.)
- **Objetivo 1:** (Texto del objetivo)
  - **Meta SMART:** (Define una meta Específica, Medible, Alcanzable, Relevante y con Plazo. Ej: 'Capacitar al 80% de los docentes de 9° grado en herramientas digitales para la creación de contenido interactivo antes de que finalice marzo de 2025.')
- **Objetivo 2:** ...
- **Objetivo 3:** ...

## 5. Plan de Acción
(Organiza las actividades proporcionadas en una tabla Markdown. Si no hay actividades, crea una tabla con 3-4 actividades sugeridas.)

| Actividad             | Responsable(s)  | Duración Estimada | Recursos Necesarios |
| --------------------- | --------------- | ----------------- | ------------------- |
| ${actividades && actividades.length > 0 ? actividades.map(a => `${a.nombre} | ${a.responsable} | ${a.duracion} | (Sugerir recursos)`).join('\n') : 'Taller de planeación | Coordinador | 1 semana | Sala de reuniones'} |

## 6. Cronograma
(Crea un cronograma visual simple tipo Gantt en formato de texto/tabla. Utiliza las fechas de inicio y fin si se proporcionaron para marcar los hitos principales. Usa emojis para hacerlo más visual.)

📅 **Hito 1: Planificación y Diseño (Semana 1-2)**
- [ ] Tarea 1.1
- [ ] Tarea 1.2
- ...

📅 **Hito 2: Ejecución de Actividades (Semana 3-10)**
- [ ] Actividad A
- [ ] Actividad B
- ...

📅 **Hito 3: Evaluación y Cierre (Semana 11-12)**
- [ ] Recolección de datos
- [ ] Análisis e informe final

## 7. Presupuesto
(Presenta una tabla de presupuesto detallada. Si solo se dio un monto, desglósalo en categorías sugeridas.)

| Ítem Presupuestario      | Costo Estimado (${moneda || 'USD'}) | Fuente de Financiamiento (Sugerencia) |
| ------------------------ | ---------------- | ----------------------------------- |
| Recursos Humanos         | ...              | Fondos propios                      |
| Materiales y Equipos     | ...              | Donaciones / Alianzas               |
| Costos Operativos        | ...              | Presupuesto institucional           |
| **Total Aproximado**     | **${presupuesto || '0'}**     |                                     |

## 8. Evaluación del Proyecto
### Instrumentos de Evaluación
(Lista los instrumentos seleccionados: ${instrumentos_evaluacion && instrumentos_evaluacion.length > 0 ? instrumentos_evaluacion.join(', ') : 'No definidos'}). Para cada uno, describe brevemente su propósito.

### Métricas e Indicadores de Éxito
(Define cómo se medirá el éxito. Ej: "Se considerará exitoso si la encuesta de satisfacción final alcanza una aprobación del 80% o más" o "Si se observa una reducción del 15% en la tasa de...")

## 9. Plan de Riesgos (Sugerencia)
(Sugiere 2-3 riesgos potenciales y sus planes de mitigación.)
- **Riesgo:** Baja participación de estudiantes.
  - **Estrategia de Mitigación:** Implementar una campaña de comunicación interna y ofrecer incentivos lúdicos.
- **Riesgo:** ...
  - **Estrategia de Mitigación:** ...

**--- FIN DEL PROYECTO ---**
`;

    return { system_prompt, user_prompt };
};