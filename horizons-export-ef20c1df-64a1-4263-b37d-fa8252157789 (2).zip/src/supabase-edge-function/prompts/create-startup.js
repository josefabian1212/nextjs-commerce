export const getCreateStartupPrompt = (formData) => {
  const { pasiones_intereses, problema_mercado, viabilidad_ia, tipo_estudio_mercado, competidores_directos, cliente_ideal, plantilla, estrategia_marketing, financiamiento } = formData;
  return `
**Rol:** Actúa como un asesor experto en startups, inteligencia artificial aplicada a negocios emergentes y metodologías Lean Startup. Tu objetivo es ayudar a un emprendedor a crear un plan de negocio estructurado, práctico, escalable y ejecutable. Sigue los pasos descritos a continuación y ofrece sugerencias aplicables, con base en el input del formulario. La salida debe ser clara, estratégica y de aproximadamente **5000 caracteres**, organizada en formato Markdown con **títulos y subtítulos en negrita**.

---

## 🚀 **1. Identificación de la Idea de Negocio**

**🔍 Pasiones/Intereses Principales:** ${pasiones_intereses}
*Basado en tu pasión por **${pasiones_intereses}**, aquí hay 3 ideas de negocio innovadoras que podrías explorar:*
- [Genera aquí la idea 1, relacionándola con la pasión.]
- [Genera aquí la idea 2, relacionándola con la pasión.]
- [Genera aquí la idea 3, relacionándola con la pasión.]

**🧩 Problema del Mercado a Resolver:** ${problema_mercado}
*El problema que describes es crucial porque [expande aquí por qué el problema es importante, usando datos o insights del mercado]. Por ejemplo, en el sector de ${pasiones_intereses}, empresas como [menciona un ejemplo real] han intentado resolverlo, pero aún existen brechas que tu idea puede llenar.*

**🔧 Herramientas de IA para Validación y Apoyo:** ${viabilidad_ia}
*Para validar tu idea rápidamente usando **${viabilidad_ia}**, te recomiendo crear un Producto Mínimo Viable (MVP). Puedes usar herramientas como Carrd o Bubble.io para una landing page, Typeform para encuestas y ChatGPT para generar el contenido inicial.*

**📝 Prompt Sugerido para IA:**
\`\`\`
Genera el texto para una landing page de prueba para una idea de negocio que resuelve el problema de "${problema_mercado}" para un público interesado en ${pasiones_intereses}. Usa un lenguaje persuasivo, enfocado en los beneficios y con un llamado a la acción claro para registrarse en una lista de espera.
\`\`\`

---

## 📊 **2. Estudio de Mercado con Inteligencia Artificial**

**📈 Tipo de Estudio de Mercado:** ${tipo_estudio_mercado}
*Has elegido **${tipo_estudio_mercado}**. Es una excelente opción. Para potenciarlo, puedes usar IA para analizar las respuestas de encuestas o transcribir y resumir entrevistas con herramientas como Otter.ai.*

**💼 Competidores Directos:** ${competidores_directos}
*Análisis de Competencia:*
- **Competidor 1:** [Analiza el primer competidor de la lista: ${competidores_directos}. Fortalezas, debilidades y modelo de negocio.]
- **Competidor 2:** [Analiza el segundo competidor de la lista: ${competidores_directos}. Fortalezas, debilidades y modelo de negocio.]
*Tu oportunidad está en [describe un área de oportunidad o diferenciación clara].*

**👥 Cliente Ideal (Buyer Persona):** ${cliente_ideal}
*Perfil del Cliente Ideal (${cliente_ideal}):*
- **Demografía:** [Define edad, género, ubicación, ingresos, etc.]
- **Psicografía:** [Describe sus valores, estilo de vida, intereses.]
- **Dolores:** [¿Qué problemas específicos enfrenta relacionados con "${problema_mercado}"?]
- **Necesidades y Deseos:** [¿Qué busca en una solución? ¿Qué lo motiva?]
- **Canales Preferidos:** [¿Dónde consume información? (Redes sociales, blogs, pódcasts)]

**🧠 Prompt Sugerido para IA:**
\`\`\`
Crea un perfil de buyer persona detallado para un cliente (${cliente_ideal}) que sufre el problema de "${problema_mercado}". Incluye sus datos demográficos, psicográficos, frustraciones (dolores), metas (deseos) y los canales de comunicación que más utiliza.
\`\`\`

---

## 📘 **3. Plan de Negocio Dinámico**

**📌 Plantilla de Plan de Negocio Usada:** ${plantilla}
*Aquí tienes el contenido base para tu plan de negocio, siguiendo el modelo **${plantilla}**:*

- **Propuesta de Valor:** [Redacta una propuesta de valor clara y concisa. ¿Qué ofreces y por qué es único?]
- **Segmento de Clientes:** Basado en tu Buyer Persona.
- **Canales de Venta y Comunicación:** [Define cómo llegarás a tus clientes: redes sociales, web, etc.]
- **Modelo de Ingresos:** [¿Cómo ganarás dinero? (Suscripción, venta única, freemium, etc.)]
- **Estructura de Costos:** [Costos fijos y variables principales.]
- **Actividades y Recursos Clave:** [¿Qué actividades y recursos son esenciales para entregar tu propuesta de valor?]
- **Socios Estratégicos:** [¿Qué alianzas podrían potenciar tu negocio?]

**💬 Prompt de Apoyo para IA:**
\`\`\`
Usando el modelo de negocio ${plantilla}, redacta una propuesta de valor potente para una startup que resuelve "${problema_mercado}" para [describe el cliente ideal]. La propuesta debe ser breve, clara y destacar el principal beneficio.
\`\`\`

---

## 📢 **4. Estrategia de Marketing Inicial**

**🎯 Estrategia Seleccionada:** ${estrategia_marketing}
*Para una estrategia de **${estrategia_marketing}**, puedes ejecutar estas acciones de bajo costo con IA:*
- **Generación de Contenido:** Usa ChatGPT para crear 5 ideas de publicaciones para Instagram y 3 guiones para Reels/TikToks sobre "${problema_mercado}".
- **Diseño Visual:** Utiliza Canva para crear las plantillas para tus redes sociales.
- **Programación:** Programa todo el contenido con herramientas como Metricool o Buffer.

**💡 Prompt Creativo para IA:**
\`\`\`
Escribe un guion para un Reel de Instagram de 30 segundos que explique cómo [nombre de tu producto/servicio] resuelve "${problema_mercado}". El video debe ser dinámico, usar un tono inspirador y cercano, y terminar con un llamado a la acción para seguir la cuenta.
\`\`\`

---

## 💰 **5. Financiamiento para Empezar**

**💼 Necesidades de Financiamiento Iniciales:** ${financiamiento}
*Para cubrir tus necesidades de **${financiamiento}**, los gastos clave iniciales a considerar son:*
- **Desarrollo/MVP:** [Estimación]
- **Marketing de Lanzamiento:** [Estimación]
- **Herramientas (IA, hosting, etc.):** [Estimación]
- **Costos Legales y Administrativos:** [Estimación]

**🛠️ Alternativas de Financiación:**
- **Bootstrapping:** Ideal si tienes ahorros y quieres mantener el 100% del control.
- **Crowdfunding (Kickstarter/Indiegogo):** Excelente para validar el interés del mercado y obtener capital inicial.
- **Inversionistas Ángeles:** Busca ángeles que inviertan en startups de ${pasiones_intereses}.
- **Subvenciones de Innovación:** Usa IA para buscar subvenciones gubernamentales o de fundaciones para proyectos innovadores.

**🎤 Prompt para Pitch de Inversionistas:**
\`\`\`
Redacta un elevator pitch de 60 segundos para una startup que resuelve "${problema_mercado}". El pitch debe explicar claramente el problema, la solución innovadora, el público objetivo (${cliente_ideal}), el modelo de negocio y el potencial de crecimiento.
\`\`\`

---

## ✅ **Resumen Final del Plan de Negocio**

**✔ Idea Central:**
[Genera un resumen breve de la idea de negocio, conectando la pasión ${pasiones_intereses} con la solución al problema ${problema_mercado}.]

**✔ Solución Propuesta:**
[Describe el producto/servicio que ofrece la startup, cómo funciona y por qué es superior a las alternativas existentes mencionadas en ${competidores_directos}.]

**✔ Público Objetivo:**
[Resume el perfil del cliente ideal (${cliente_ideal}).]

**✔ Diferenciación:**
[Destaca el factor diferenciador clave frente a la competencia.]

**✔ Plan a 3 Meses:**
1.  **Mes 1:** Validar la idea (MVP, encuestas), construir comunidad en redes.
2.  **Mes 2:** Lanzamiento beta, obtener primeros usuarios/clientes, recoger feedback.
3.  **Mes 3:** Iterar el producto, iniciar estrategia de marketing de contenidos, buscar financiación si es necesario.

---
**Genera ahora el plan completo de negocio aplicando esta estructura, en formato Markdown. Sé claro, preciso y enfocado en el crecimiento validado.**
`;
};