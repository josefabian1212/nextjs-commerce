export const getUnitTopicsPrompt = (formData) => {
  const { grade, asignatura, topic, numero_clases, estandar } = formData;
  return `
**Rol:** Actúa como un especialista en diseño curricular, experto en planificación educativa por unidades didácticas. Tu tarea es generar un **plan detallado de unidad**, dividido por clases, con base en la siguiente información del formulario. Cada clase debe tener objetivos, contenidos, actividades y evaluación sugerida. La unidad debe estar alineada a los estándares educativos del grado, país y asignatura. Usa un tono técnico-pedagógico claro, bien organizado, con **títulos y subtítulos en negrita**.

La salida debe tener aproximadamente **5000 caracteres**, estructurada de forma clara, en formato **Markdown** y fácilmente editable para docentes. Usa ejemplos, recursos didácticos sugeridos y aplica metodologías activas.

---

**🎓 Grado:** ${grade}
**📚 Asignatura:** ${asignatura}
**📌 Tema Principal de la Unidad:** ${topic}
**📆 Número de Clases:** ${numero_clases}
**🎯 Estándar Educativo:** ${estandar}

---

## 🧱 **Estructura de la Unidad Didáctica**

**🧩 Unidad o Componente:**
[Infiere y propone un nombre para la unidad que agrupe las clases bajo un enfoque común, coherente con el tema principal: "${topic}".]

**🎯 Competencias Específicas a Desarrollar:**
- [Genera 2–4 competencias relacionadas con la asignatura "${asignatura}", el grado "${grade}" y el tema "${topic}".]
- [Ejemplo: Resolver problemas utilizando ecuaciones lineales con una o más incógnitas.]

**🔎 Ejes Temáticos:**
[Identifica de 1 a 3 grandes áreas o ejes que organizan el contenido de la unidad.]
- Ejemplo: Álgebra, Modelación matemática, Resolución de problemas.

**📖 Contenidos Temáticos:**
[Genera un listado específico de los contenidos que serán desarrollados durante la unidad, basándote en el tema principal.]
- Ejemplo: Concepto de ecuación, Propiedades de la igualdad, Resolución de ecuaciones, etc.

**📈 Indicadores de Desempeño Esperados:**
[Propón indicadores observables que permitan medir el aprendizaje del estándar "${estandar}".]
- Ejemplo: Identifica ecuaciones lineales en contextos reales, Resuelve ecuaciones aplicando propiedades, etc.

---

## 📆 **Distribución por Clases (${numero_clases} clases)**

[A continuación, desarrolla el plan para cada una de las ${numero_clases} clases. Asegúrate de que la progresión sea lógica y cubra todos los contenidos temáticos.]

**📗 Clase 1: [Define un título para la Clase 1, ej: Introducción al Tema]**
- **Objetivo:** [Redacta un objetivo específico para esta clase.]
- **Contenidos:** [Detalla los contenidos específicos para esta clase.]
- **Actividad:** [Describe una actividad de inicio, desarrollo y cierre. Sugiere metodologías activas.]
- **Evaluación:** [Propón un método de evaluación formativa para esta clase.]

**📘 Clase 2: [Define un título para la Clase 2, ej: Desarrollo de Conceptos Clave]**
- **Objetivo:** [Redacta un objetivo específico para esta clase.]
- **Contenidos:** [Detalla los contenidos específicos para esta clase.]
- **Actividad:** [Describe una actividad de inicio, desarrollo y cierre.]
- **Evaluación:** [Propón un método de evaluación formativa.]

**(Continúa generando la estructura para las ${numero_clases} clases solicitadas, manteniendo la progresión y coherencia...)**

**📕 Clase ${numero_clases}: [Define un título para la última clase, ej: Aplicación y Cierre]**
- **Objetivo:** [Redacta un objetivo de síntesis o aplicación.]
- **Contenidos:** [Detalla los contenidos de cierre o aplicación.]
- **Actividad:** [Describe una actividad que integre lo aprendido, como un mini-proyecto o un caso práctico.]
- **Evaluación:** [Propón un método de evaluación sumativa o de proyecto.]

---

## 🧠 **Conceptos Clave**
[Genera una lista de los conceptos fundamentales que se abordarán en toda la unidad.]
- Ecuación
- Igualdad
- Incógnita
- etc.

---

## 🧾 **Metodología Sugerida**
[Sugiere 3-4 metodologías activas apropiadas para el tema y el grado.]
- Aprendizaje basado en problemas
- Trabajo cooperativo
- Aula invertida
- Gamificación

---

**Genera ahora el plan completo de unidad con las clases desarrolladas, usando esta plantilla.**
`;
};