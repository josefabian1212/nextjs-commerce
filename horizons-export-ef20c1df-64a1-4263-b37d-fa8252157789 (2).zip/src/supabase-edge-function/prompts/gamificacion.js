export const getGamificacionPrompt = (formData) => {
  const { tema_contenido, grado_nivel, duracion, objetivo_aprendizaje, elementos_juego, tipo_interaccion } = formData;
  const elementosString = Array.isArray(elementos_juego) ? elementos_juego.join(', ') : elementos_juego;

  return `
**Rol:** Actúa como un experto en Gamificación Educativa y Diseño Instruccional, con experiencia en pedagogía activa y motivación escolar. Tu tarea es **transformar una lección tradicional en una experiencia gamificada motivadora**, diseñada para captar la atención, fomentar la participación y mejorar el aprendizaje de los estudiantes. Ten en cuenta el nivel educativo, el contenido curricular y las mejores prácticas de gamificación basada en evidencia.

La salida debe tener una extensión aproximada de **5000 caracteres**, estar bien estructurada, estar redactada en un tono profesional, claro y aplicable por cualquier docente.

---

## 🧠 **1. Información General del Diseño Gamificado**

**📘 Tema/Contenido de la Lección:**
${tema_contenido}

**🎓 Grado/Nivel Educativo:**
${grado_nivel}

**⏱️ Duración de la Actividad Gamificada:**
${duracion}

**🎯 Objetivo de Aprendizaje Principal:**
${objetivo_aprendizaje}

---

## **2. Elementos de Gamificación Seleccionados**

**🎲 Elementos de Juego a Incluir:**
${elementosString}

**🤝 Tipo de Interacción Preferida:**
${tipo_interaccion}

---

## **3. Fases de la Actividad Gamificada en el Aula**

### **🔔 A. Introducción y Contexto Narrativo**
[Genera una narrativa envolvente o una misión inicial para introducir la lección sobre "${tema_contenido}". Preséntala como una aventura emocionante para estudiantes de ${grado_nivel}. Si aplica, sugiere roles o avatares que puedan adoptar.]

### **🎯 B. Definición de la Misión o Desafío**
[Define claramente el reto principal de la actividad. Por ejemplo: "Tu misión será...". Divide la misión en niveles o fases de complejidad creciente, alineadas con el objetivo de aprendizaje: "${objetivo_aprendizaje}".]

### **🔄 C. Desarrollo del Juego Educativo**
[Diseña las actividades centrales que los estudiantes realizarán. Deben estar alineadas al currículo y al tema "${tema_contenido}". Integra los elementos de gamificación seleccionados (${elementosString}) de forma natural. Por ejemplo, si se seleccionaron "Puntos" y "Misiones", describe cómo se ganarán y qué misiones deberán completar.]

### **🏆 D. Retroalimentación, Puntuación y Clasificación**
[Explica cómo se dará retroalimentación a los estudiantes. Describe cómo se mostrará el avance (ej. una barra de progreso). Si el tipo de interacción es "${tipo_interaccion}" y permite competición, detalla cómo funcionará el leaderboard (individual o por equipos).]

### **🎁 E. Recompensas y Desbloqueo**
[Detalla el sistema de recompensas. ¿Qué se desbloqueará al cumplir misiones o alcanzar hitos? Ofrece ideas de premios simbólicos (digitales o físicos) que sean motivadores para estudiantes de ${grado_nivel}.]

---

## 🧰 **4. Recursos y Herramientas Sugeridas**

[Sugiere herramientas tecnológicas y recursos físicos apropiados para llevar a cabo esta actividad gamificada. Recomienda herramientas específicas como Kahoot, Genially, Canva, etc., y cómo usarlas. Incluye también prompts de ejemplo para IA (ChatGPT, DALL·E) que el docente podría usar para preparar materiales.]

---

## 📈 **5. Evaluación y Reflexión Final**

**📊 Evaluación Formativa:**
[Propón métodos de evaluación formativa que se integren con la gamificación. Por ejemplo, una rúbrica basada en el desempeño en la misión, autoevaluación usando símbolos del juego, etc.]

**💬 Cierre Reflexivo:**
[Diseña un espacio final para la reflexión. Incluye preguntas guía para que los estudiantes compartan qué aprendieron, qué desafíos disfrutaron más y cómo se sintieron aprendiendo de esta manera.]

---

## 🌱 **6. Recomendaciones Pedagógicas del Experto**

[Ofrece 3-4 consejos clave para el docente que implementará esta actividad. Las recomendaciones deben enfocarse en equilibrar el juego con el aprendizaje, mantener la inclusión, y fomentar la metacognición.]

---

**Genera el diseño gamificado completo siguiendo esta estructura, aplicando el tema, nivel y elementos seleccionados por el usuario. El resultado debe ser claro, práctico y aplicable directamente en el aula.**
`;
};