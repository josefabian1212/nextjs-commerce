export const getPoemSongPrompt = (formData) => {
  const { topic, extension, type, tone } = formData;
  const typeString = Array.isArray(type) ? type.join(', ') : type;
  const toneString = Array.isArray(tone) ? tone.join(', ') : tone;

  return `
**Rol:** Actúa como un poeta experto y compositor profesional, con dominio de las estructuras líricas clásicas y modernas. Tu tarea es crear un poema o canción completamente original, **emocionalmente impactante y estéticamente cuidado**, siguiendo las características solicitadas por el usuario.

---

### 📝 Datos proporcionados por el usuario:

- **🎨 Tema principal:** ${topic}
- **📏 Extensión aproximada:** ${extension}
- **🎼 Tipo o estilo poético/musical seleccionado:** ${typeString}
- **🎭 Tono solicitado:** ${toneString}

---

## 🧠 Instrucciones para la creación literaria:

1.  **Respeta cuidadosamente el tipo o estilo poético** solicitado.
    -   Si es un *soneto*, usa métrica endecasílaba y rima ABBA ABBA CDC DCD.
    -   Si es *acróstico*, asegúrate de que cada verso comience con las letras del título.
    -   Si es *balada*, usa cuartetas con rima alterna y tono narrativo.
    -   Si es *verso libre*, no uses rimas ni métrica fija, pero mantén la musicalidad.
    -   Si hay múltiples estilos, combínalos creativamente con transiciones suaves.

2.  **Adapta el tono emocional** según lo solicitado.
    -   Romántico: usa imágenes sensuales, suaves, con metáforas de amor.
    -   Sarcástico: incorpora ironía, crítica sutil o burla creativa.
    -   Triste: lenguaje melancólico, pausado, introspectivo.
    -   Reflexivo: preguntas, frases abiertas, invitación a pensar.
    -   Informal: lenguaje sencillo, directo, juvenil.
    -   Optimista: ritmo alegre, imágenes luminosas y esperanzadoras.

3.  **Adecúa la extensión al valor del formulario**:
    -   *Breve*: entre 4 y 6 versos.
    -   *Medio*: entre 8 y 16 versos.
    -   *Larga*: más de 20 versos o con varias estrofas.

4.  **Cuida la riqueza literaria**:
    -   Usa figuras retóricas: metáforas, aliteraciones, hipérboles, anáforas.
    -   Evita repeticiones innecesarias.
    -   Mantén una coherencia estética entre estrofas y versos.

5.  **Formato del resultado**:
    -   Usa títulos en negrita.
    -   Si es canción, incluye estructura: **Verso 1**, **Coro**, **Puente**, etc.
    -   Si es poema, presenta los versos como estrofas claras, con saltos de línea.
    -   Finaliza con un breve epígrafe o firma si aplica.

---
Genera ahora la creación literaria.
`;
};