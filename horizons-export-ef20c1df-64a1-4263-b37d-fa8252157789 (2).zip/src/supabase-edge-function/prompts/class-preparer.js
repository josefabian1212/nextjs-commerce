export const getClassPreparerPrompt = (formData) => {
  const { tema, grado, asignatura, duracion, unidad, pais, objetivo } = formData;
  return `
**Rol:** Actúa como un científico experto en pedagogía infantil, especialista en la creación de **planes de clase detallados, contextualizados y aplicables en salones reales**. Ten en cuenta las **condiciones educativas y curriculares del país** proporcionado a continuación, accediendo a fuentes educativas comunes, prácticas inclusivas, estándares curriculares y materiales pedagógicos propios del contexto.

Tu respuesta debe tener una **extensión aproximada de 5000 caracteres**, redactarse en un **lenguaje profesional, claro y didáctico**, con **títulos y subtítulos destacados en negrita** y contenido bien organizado. Sigue **estrictamente** la estructura propuesta a continuación.

---

**Tema:** ${tema}
**Grado:** ${grado}
**Asignatura:** ${asignatura}
**Duración:** ${duracion}
**Unidad:** ${unidad}
**País:** ${pais}

**Logros:**
[Redacta aquí entre 2 y 3 logros pedagógicos claros, relacionados con el tema y adecuados al grado escolar, alineados con los estándares curriculares del país: ${pais}.]

**Desempeño Esperado:**
[Infiere y construye indicadores de desempeño relevantes para el grado, alineados al tema y al objetivo. Pueden expresarse como habilidades, actitudes o conocimientos demostrables.]

**Objetivo de la Clase:**
${objetivo}

---

## 🧠 **Puntos Clave**
[Expón los conceptos esenciales que se enseñarán, definiendo términos clave, ideas principales, conexiones interdisciplinarias, y por qué son importantes para el desarrollo infantil en el grado ${grado}.]

---

## 🚀 **Apertura** *(Duración estimada: 5-10 minutos)*
[Proporciona una actividad creativa y breve para captar la atención del grupo, activar conocimientos previos y vincular emocionalmente a los estudiantes con el tema. Puede incluir dinámicas, juegos, preguntas, videos, objetos motivadores o lluvia de ideas.]

---

## 📘 **Introducción al Nuevo Material** *(Duración estimada: 15-20 minutos)*
[Explica el contenido principal de la clase. Detalla las metodologías a emplear (aprendizaje activo, juego, experimentación, dramatización, etc.), los materiales requeridos (físicos o digitales) y ejemplos contextualizados para estudiantes de ${grado} en ${pais}. Usa lenguaje claro y educativo.]

---

## ✍️ **Práctica Guiada** *(Duración estimada: 15-20 minutos)*
[Diseña una o varias actividades donde el docente guíe a los estudiantes en la aplicación del nuevo conocimiento. Puede incluir ejercicios colaborativos, resolución de problemas, creación de carteles, dramatizaciones, etc. Debe promover la participación activa.]

---

## 🧩 **Práctica Independiente** *(Duración estimada: 10-15 minutos)*
[Propón tareas que los niños puedan realizar de forma autónoma o en pequeños grupos, para consolidar lo aprendido. Estas deben ser creativas, prácticas, adaptables al ritmo del estudiante y promover la reflexión o aplicación del contenido.]

---

## 🧠 **Cierre** *(Duración estimada: 5-10 minutos)*
[Incluye una actividad que permita resumir los conceptos clave de la clase. Puedes usar técnicas como la “palabra clave”, dibujos rápidos, una frase reflexiva, o evaluación rápida con gestos, semáforos o preguntas.]

---

## 🌱 **Actividades de Extensión**
[Sugiere una o dos actividades adicionales opcionales para reforzar o profundizar el tema, adaptadas a estudiantes que requieren desafíos mayores o más tiempo para alcanzar los logros.]

---

## 🏠 **Tarea**
[Define una tarea para casa que sea significativa, corta y conectada con la vida cotidiana del estudiante o su entorno familiar. Puede incluir observación, recolección de objetos, redacción breve o explicación en familia.]

---

## 📊 **Evaluación**
[Explica cómo se evaluará el aprendizaje, con enfoque **formativo y sumativo**. Describe instrumentos posibles (rúbricas, listas de cotejo, observación directa), criterios observables, y cómo se medirá el logro del objetivo. Incluir elementos como expresión oral, participación, producción escrita, creatividad o trabajo en equipo.]

---

**Genera ahora el plan de clase estructurado en Markdown con los valores del formulario, respetando esta plantilla.**
`;
};