export const getNeuroeducacionPrompt = (formData) => {
  const { tema, grado, duracion, estilo_aprendizaje, nivel_atencional, confianza, emociones, pilares_trabajar } = formData;
  return `
**Rol:** Actúa como un científico experto en Neuroeducación, con formación avanzada en programación neurolingüística y pedagogía, especializado en el diseño de actividades escolares basadas en cómo aprende el cerebro. Tu misión es crear una guía práctica, clara y paso a paso para aplicar los principios de la Neuroeducación en el aula, adaptada al tema, grado, emociones predominantes y estilo de aprendizaje de los estudiantes.

La respuesta debe tener aproximadamente 4000–5000 caracteres. Usa títulos y subtítulos en negrita. El contenido debe estar bien estructurado, con un enfoque científico, pedagógico y aplicable para docentes en contextos reales.

---

## **Plan Neuroeducativo: Aplicación en el Aula**

**Tema:** ${tema}
**Grado:** ${grado}
**Duración:** ${duracion}
**Estilo de Aprendizaje Predominante:** ${estilo_aprendizaje}
**Nivel Atencional Promedio:** ${nivel_atencional}/10
**Nivel de Confianza Promedio:** ${confianza}/10
**Emoción Frecuente Predominante:** ${emociones}
**Pilar Neuroeducativo a Trabajar:** ${pilares_trabajar}

---

### **1. Activación Emocional (Inicio de Clase - 5-10 min)**
*(Considerando que la emoción predominante es la **${emociones}** y el pilar a trabajar es la **${pilares_trabajar}**, esta es la estrategia de inicio recomendada para conectar con el grupo y preparar el cerebro para aprender sobre **${tema}**.)*

[Genera aquí una actividad de inicio detallada.
- **Si la emoción es positiva (Alegría, Interés):** Diseña una actividad que canalice esa energía, como una pregunta provocadora, un juego rápido, o un video corto y sorprendente sobre el tema.
- **Si la emoción es negativa (Ansiedad, Miedo, Tristeza):** Diseña una actividad calmante y de conexión, como una técnica de respiración guiada, una dinámica de confianza grupal, o una historia corta que genere empatía y seguridad antes de introducir el tema.]

---

### **2. Estrategias para Captar y Mantener la Atención**
*(Para un nivel atencional de **${nivel_atencional}/10** y un pilar de **${pilares_trabajar}**, las siguientes estrategias son clave durante los ${duracion} de la clase.)*

- **Estímulos Multisensoriales:** [Sugiere 2-3 estímulos específicos para el tema "${tema}" que se alineen con el estilo de aprendizaje "${estilo_aprendizaje}". Ej: un video timelapse de una planta creciendo, el sonido de un bosque, tocar hojas reales.]
- **Ciclos Atencionales (Regla de los 15 min):** [Divide la clase de ${duracion} en bloques. Describe qué tipo de cambio de dinámica se hará en cada transición. Ej: "Min 0-15: Introducción y video. Min 15-30: Actividad kinestésica. Min 30-45: Trabajo en grupos pequeños..."]
- **Pausa Cerebral (Brain Break):** [Propón una actividad corta (1-2 min) para hacer a mitad de la clase, que no esté relacionada con el tema, para oxigenar el cerebro. Ej: un juego de coordinación, estiramientos, etc.]
- **Foco en el Pilar (${pilares_trabajar}):** [Si el pilar es "Atención", añade un juego específico de concentración. Si es otro pilar, explica cómo esta estructura atencional lo apoya.]

---

### **3. Actividades Adaptadas al Estilo de Aprendizaje (${estilo_aprendizaje})**
*(El núcleo de la clase se centrará en el estilo de aprendizaje predominante. A continuación, se detalla la actividad principal.)*

[Genera una descripción detallada de la actividad central de la clase, basada en el estilo de aprendizaje seleccionado:
- **Visual:** Detalla cómo crear un mapa conceptual, una infografía, o un dibujo del proceso de "${tema}".
- **Auditivo:** Describe cómo se podría usar una explicación narrada (storytelling), una canción o un debate sobre "${tema}".
- **Kinestésico:** Explica paso a paso una dramatización, un experimento práctico, o la construcción de un modelo relacionado con "${tema}".
- **Lector/Escritor:** Proporciona una guía para una lectura estructurada, la creación de un resumen, o el llenado de un organizador gráfico sobre "${tema}".]

---

### **4. Potenciación de la Memoria y la Confianza**
*(Para consolidar el aprendizaje de **${tema}** y fortalecer una confianza de **${confianza}/10**, se usarán las siguientes técnicas.)*

- **Anclaje en Conocimientos Previos:** [Sugiere 2-3 preguntas para conectar "${tema}" con algo que los estudiantes de ${grado} ya sepan. Ej: "¿En qué se parece una planta a nosotros? ¿Ambos necesitamos 'comer'?"]
- **Narrativa (Storytelling):** [Crea una historia corta y memorable que explique el concepto de "${tema}". La historia debe ser el vehículo para la memoria a largo plazo.]
- **Repetición Espaciada:** [Sugiere cómo hacer un breve repaso del concepto clave en al menos dos momentos diferentes de la clase.]
- **Fomento de la Confianza:** [Propón una estrategia específica para aumentar la confianza. Ej: celebrar los errores como oportunidades, empezar con preguntas fáciles para asegurar aciertos iniciales, usar refuerzo positivo verbal.]
- **Foco en el Pilar (${pilares_trabajar}):** [Si el pilar es "Memoria", añade una técnica de mnemotecnia o una asociación visual fuerte.]

---

### **5. Fomento de la Metacognición (Cierre de la Clase - 10 min)**
*(Para cerrar el ciclo de aprendizaje y trabajar el pilar de la **${pilares_trabajar}**, finalizaremos con una reflexión estructurada.)*

- **Técnica de Cierre:** [Describe una técnica de cierre específica. Ej: "Boleto de Salida", "3-2-1", o una "Ronda de Reflexión".]
- **Preguntas Guía:**
  1.  **¿Qué fue lo más sorprendente que aprendiste hoy sobre ${tema}?**
  2.  **Dibuja un emoji que represente cómo te sentiste durante la actividad principal. ¿Por qué elegiste ese emoji?**
  3.  **¿En qué otra parte de tu vida o en qué otra asignatura podrías usar lo que aprendiste hoy?**
- **Foco en el Pilar (${pilares_trabajar}):** [Si el pilar es "Metacognición", enfatiza la importancia de estas preguntas para que el estudiante sea consciente de su propio proceso de aprendizaje.]

---

### **Evaluación Emocional y Cognitiva del Aprendizaje**
- **Instrumento Sugerido:** [Propón un instrumento sencillo para evaluar. Ej: una mini-rúbrica con 2 criterios (comprensión del concepto y participación) y 3 niveles (logrado, en proceso, necesita apoyo), combinada con una escala de emoticonos para la parte emocional.]
- **Observación Docente:** [Indica qué debe observar el docente: el lenguaje corporal, el tipo de preguntas que hacen los estudiantes, el nivel de colaboración, etc.]

---
**Genera ahora el plan neuroeducativo completo, siguiendo esta plantilla y adaptándolo a los datos proporcionados.**
`;
};