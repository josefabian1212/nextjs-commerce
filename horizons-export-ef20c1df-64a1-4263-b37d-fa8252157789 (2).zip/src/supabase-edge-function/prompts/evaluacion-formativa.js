export const getEvaluacionFormativaPrompt = (formData) => {
  const { tema_contenido, grado_nivel, duracion, objetivo_aprendizaje, tipo_retroalimentacion, estrategia_evaluacion } = formData;
  return `
**Rol:** Actúa como un experto en Evaluación Formativa y Diseño Instruccional, especializado en crear estrategias de evaluación auténticas y significativas que promueven el aprendizaje continuo. Tu tarea es diseñar un plan completo para una actividad de evaluación formativa, basado en la información proporcionada por el docente.

La salida debe ser clara, práctica, y estar redactada en un tono profesional y aplicable. La extensión aproximada es de 5000 caracteres.

---

## 📝 **1. Información General de la Actividad de Evaluación**

**📘 Tema/Contenido a Evaluar:**
${tema_contenido}

**🎓 Grado/Nivel Educativo:**
${grado_nivel}

**⏱️ Duración Estimada de la Actividad:**
${duracion}

**🎯 Objetivo de Aprendizaje a Evaluar:**
${objetivo_aprendizaje}

---

## **2. Estrategia y Enfoque de la Evaluación**

**📊 Estrategia de Evaluación Formativa Seleccionada:**
**${estrategia_evaluacion}**

**💬 Tipo de Retroalimentación Deseada:**
**${tipo_retroalimentacion}**

*(Basado en la estrategia "${estrategia_evaluacion}" y el tipo de feedback "${tipo_retroalimentacion}", explica brevemente por qué esta combinación es efectiva para evaluar el objetivo "${objetivo_aprendizaje}" en estudiantes de ${grado_nivel}.)*

---

## **3. Diseño de la Actividad de Evaluación (Paso a Paso)**

### **🚀 A. Preparación y Presentación (Inicio)**
- **Introducción (5 min):** [Describe cómo el docente introducirá la actividad. Debe ser claro, motivador y explicar el propósito de la evaluación sin generar ansiedad. Por ejemplo, "Hoy vamos a jugar a ser detectives del conocimiento para ver cuánto hemos aprendido sobre ${tema_contenido}".]
- **Instrucciones Claras:** [Redacta las instrucciones paso a paso para los estudiantes, asegurándote de que sean fáciles de entender para el grado ${grado_nivel}.]

### **✍️ B. Ejecución de la Actividad (Desarrollo)**
- **Tarea Principal:** [Diseña la actividad central basada en la estrategia "${estrategia_evaluacion}". Por ejemplo, si es "Boleto de Salida", crea 2-3 preguntas clave. Si es "Think-Pair-Share", define el problema a discutir. Si es "Observación y Anecdotario", detalla qué comportamientos o habilidades se observarán.]
- **Materiales Necesarios:** [Lista los materiales requeridos, tanto para el docente como para los estudiantes (ej. tarjetas, pizarra, post-its, etc.).]

### **🔄 C. Recopilación de Evidencias y Retroalimentación (Cierre)**
- **Método de Recopilación:** [Explica cómo se recogerá la información. Ej: recoger las tarjetas, tomar notas en el anecdotario, escuchar las conversaciones de los grupos.]
- **Aplicación del Feedback:** [Proporciona ejemplos concretos de cómo dar la retroalimentación del tipo "${tipo_retroalimentacion}". Por ejemplo, si es "Descriptiva", ofrece frases modelo como "Noté que lograste identificar las partes del cuento, ¿qué pasaría si ahora intentas describir el escenario?". Si es "Constructiva", "Buen intento al sumar las fracciones, recuerda que necesitamos un denominador común. ¿Cómo podríamos encontrarlo?".]

---

## **4. Instrumento de Evaluación Sugerido**

*(Crea un instrumento simple y práctico que el docente pueda usar. Adapta el instrumento a la estrategia seleccionada.)*

**Ejemplo para "${estrategia_evaluacion}":**

**[Nombre del Instrumento, ej: Rúbrica Simple de Observación]**

| Criterio a Evaluar                               | Nivel Inicial                                       | Nivel en Proceso                                       | Nivel Logrado                                           |
| ------------------------------------------------ | ----------------------------------------------------- | ------------------------------------------------------ | ------------------------------------------------------- |
| **[Criterio 1, basado en el objetivo]**          | [Descripción del desempeño inicial]                    | [Descripción del desempeño en progreso]                 | [Descripción del desempeño esperado]                    |
| **[Criterio 2, ej. Colaboración si aplica]**      | [Descripción del desempeño inicial]                    | [Descripción del desempeño en progreso]                 | [Descripción del desempeño esperado]                    |
| **[Criterio 3, ej. Uso del vocabulario clave]**  | [Descripción del desempeño inicial]                    | [Descripción del desempeño en progreso]                 | [Descripción del desempeño esperado]                    |

**Notas del Docente:**
[Espacio para anotaciones rápidas durante la observación.]

---

## **5. Pasos Siguientes y Toma de Decisiones Pedagógicas**

- **Análisis de Resultados:** [Guía al docente sobre cómo interpretar la información recopilada. ¿Qué patrones emergen? ¿Qué conceptos necesitan ser reforzados?]
- **Acciones a Seguir:** [Sugiere acciones concretas basadas en los posibles resultados. Por ejemplo: "Si la mayoría de los estudiantes muestra dificultades en [concepto X], se recomienda realizar una mini-lección de refuerzo al día siguiente." o "Si un grupo de estudiantes demuestra un dominio avanzado, se les puede ofrecer un desafío de extensión.".]
- **Comunicación con los Estudiantes:** [Aconseja cómo comunicar los resultados generales al grupo de una manera positiva y motivadora, enfocándose en el crecimiento y el aprendizaje.]

---
**Genera ahora el plan de evaluación formativa completo, siguiendo esta estructura y adaptándolo a los datos proporcionados.**
`;
};