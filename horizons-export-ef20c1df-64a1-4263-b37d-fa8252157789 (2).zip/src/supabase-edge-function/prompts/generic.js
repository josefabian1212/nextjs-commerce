export const getGenerateArticlePrompt = (formData) => {
  const { tema_principal, tipo_articulo, tono_articulo, audiencia_objetivo, longitud_aproximada } = formData;
  return `**Rol:** Eres un experto en creación de contenido y redacción de artículos.

  **Tarea:** Escribe un artículo detallado y bien estructurado sobre el tema proporcionado, siguiendo las especificaciones de tipo, tono, audiencia y longitud.

  **Detalles:**
  *   **Tema Principal:** ${tema_principal}
  *   **Tipo de Artículo:** ${tipo_articulo}
  *   **Tono:** ${tono_articulo}
  *   **Audiencia Objetivo:** ${audiencia_objetivo}
  *   **Longitud Aproximada:** ${longitud_aproximada}

  **Instrucciones:**
  1.  El artículo debe ser original y estar bien investigado.
  2.  Utiliza un lenguaje claro y adecuado para la audiencia objetivo.
  3.  Estructura el artículo con un título atractivo, una introducción, un cuerpo con varios párrafos o secciones, y una conclusión sólida.
  4.  Asegúrate de que el tono sea consistente en todo el artículo.
  5.  El contenido debe ser coherente y relevante para el tema principal.`;
};

export const getPedagogicalWorkshopPrompt = (formData) => {
  const { tema, grado, objetivo_principal, duracion, tipo_actividad } = formData;
  return `**Rol:** Eres un pedagogo experto en diseño de talleres educativos y dinámicas de grupo.
  
  **Tarea:** Diseña un plan detallado para un taller pedagógico, basado en la información proporcionada. El plan debe ser práctico, atractivo y centrado en el estudiante.
  
  **Información del Taller:**
  * **Tema:** ${tema}
  * **Grado/Nivel:** ${grado}
  * **Objetivo Principal:** ${objetivo_principal}
  * **Duración:** ${duracion}
  * **Tipo de Actividad Principal:** ${tipo_actividad}
  
  **Estructura del Plan del Taller (Sigue este formato):**
  
  **Título del Taller:**
  
  **1. Resumen y Objetivos:**
     - **Resumen:** (Breve descripción del taller)
     - **Objetivos de Aprendizaje:** (Lista de 2-3 objetivos específicos que los estudiantes alcanzarán)
  
  **2. Materiales y Preparación:**
     - (Lista de todos los materiales necesarios para el taller)
     - (Instrucciones de preparación para el docente antes de iniciar)
  
  **3. Desarrollo del Taller (Paso a Paso):**
     - **a. Actividad Rompehielos / Introducción (10% de la duración):** (Describe una actividad corta y atractiva para iniciar y presentar el tema)
     - **b. Presentación del Contenido / Conceptos Clave (25% de la duración):** (Explica cómo se presentará la información principal. Sugiere métodos interactivos)
     - **c. Actividad Práctica Principal (Tipo: ${tipo_actividad}) (50% de la duración):** (Describe la actividad central del taller paso a paso. Debe ser coherente con el tipo de actividad seleccionado)
     - **d. Discusión y Reflexión (10% de la duración):** (Plantea preguntas para guiar una discusión grupal sobre lo aprendido)
  
  **4. Cierre y Evaluación Formativa (5% de la duración):**
     - (Describe una actividad corta para resumir y evaluar la comprensión de los estudiantes. Ej: un boleto de salida, una palabra clave, etc.)`;
};