export const getMathAnalysisPrompt = (formData) => {
  const { grade, asignatura, tema, problema_base, dificultad, formato_salida } = formData;
  return `
**Rol:** Actúa como un matemático puro, especializado en la creación de problemas matemáticos y en la aplicación de talleres prácticos para desarrollar el análisis matemático en los estudiantes dentro del aula escolar. Eres experto en pedagogía matemática, con formación profunda en resolución de problemas y en la creación de guías didácticas aplicables. Tu misión es diseñar una guía práctica paso a paso para aplicar problemas matemáticos según el grado, tema y nivel de dificultad, promoviendo el pensamiento lógico y analítico en los estudiantes.

La respuesta debe estar redactada con un tono profesional, claro y orientado a docentes. Usa títulos y subtítulos en negrita y mantén una estructura ordenada. La salida debe tener entre 4000 y 5000 caracteres.

---

## **Guía de Taller de Análisis Matemático**

**Grado:** ${grade}
**Asignatura:** ${asignatura}
**Tema:** ${tema}
**Dificultad:** ${dificultad}
**Formato de Salida:** ${formato_salida}

---

### **1. Introducción Didáctica al Tema (Duración: 10 minutos)**
*(Objetivo: Conectar el concepto de "${tema}" con la realidad de los estudiantes de ${grade} y activar su curiosidad.)*

**Actividad Sugerida:**
[Genera aquí una actividad de inicio específica y contextualizada.
- **Para "Ecuaciones lineales":** "Imagina que tienes una caja de chocolates con una cantidad desconocida de piezas. Si te digo que después de comerte 5 te quedan 16, ¿cómo podrías saber cuántos había al principio? ¡Eso es exactamente lo que hacemos al resolver ecuaciones! Hoy vamos a convertirnos en detectives de números."
- **Para "Geometría espacial":** "Muestra objetos cotidianos (una caja, una pelota, una pirámide de juguete). ¿Sabían que las matemáticas nos ayudan a entender el espacio que ocupan estos objetos y cuánta pintura necesitaríamos para cubrirlos? Hoy exploraremos las formas en 3D."
- **Recurso Visual:** Proyecta un esquema simple en la pizarra que relacione el problema base "${problema_base}" con una situación visual o gráfica.]

---

### **2. Presentación del Problema Matemático (Duración: 5 minutos)**
*(Objetivo: Plantear un problema claro y adaptado al formato "${formato_salida}" y la dificultad "${dificultad}".)*

**Problema Principal:**
[Genera aquí el problema matemático adaptado.
- **Si el formato es "Problema verbal":** "Crea un enunciado contextualizado basado en '${problema_base}'. Ejemplo para '3x - 5 = 16' y dificultad '${dificultad}': *'Ana está ahorrando para comprar un videojuego. Cada día guarda la misma cantidad de dinero. Después de 3 días, gasta 5€ en un helado y le quedan 16€. ¿Cuánto dinero guarda Ana cada día?'*"
- **Si el formato es "Opción múltiple":** "Presenta el problema y 4 opciones: una correcta y tres distractores creíbles. Los distractores deben basarse en errores comunes (ej. sumar en lugar de restar, olvidar un paso)."
- **Si el formato es "Resolución paso a paso":** "Presenta el problema base de forma clara y directa: '${problema_base}'."
]

---

### **3. Resolución Guiada del Problema (Duración: 15-20 minutos)**
*(Objetivo: Modelar el proceso de pensamiento y la resolución paso a paso, fomentando la participación.)*

**Solución Detallada:**
[Explica la solución completa del problema generado anteriormente.
1.  **Análisis del problema:** ¿Qué nos piden? ¿Qué datos tenemos?
2.  **Paso 1:** [Describe el primer paso lógico. Ej: "Para despejar la incógnita 'x', primero debemos mover el término que no la acompaña. El '-5' pasa al otro lado sumando."]
    *   \`3x = 16 + 5\`
    *   \`3x = 21\`
3.  **Paso 2:** [Describe el segundo paso. Ej: "Ahora, el '3' que está multiplicando a 'x' pasa al otro lado dividiendo."]
    *   \`x = 21 / 3\`
    *   \`x = 7\`
4.  **Verificación:** [Explica cómo comprobar el resultado. Ej: "Sustituimos 'x' por 7 en la ecuación original: 3(7) - 5 = 21 - 5 = 16. ¡El resultado es correcto!"]

**Pregunta guía para la clase:** "¿Qué creen que deberíamos hacer ahora? ¿Por qué?"

---

### **4. Actividad de Aplicación en Grupos o Individual (Duración: 15 minutos)**
*(Objetivo: Dar a los estudiantes la oportunidad de practicar la habilidad con autonomía.)*

**Problemas Adicionales:**
[Genera 2-3 problemas nuevos con el mismo formato y dificultad, pero variando los datos o el contexto.]
- **Problema 1 (similar):** [Genera un problema.]
- **Problema 2 (con un pequeño giro):** [Genera un problema.]
- **Problema 3 (contextualizado):** [Genera un problema verbal si no fue el formato principal.]

---

### **5. Evaluación Formativa y Cierre Reflexivo (Duración: 10 minutos)**
*(Objetivo: Revisar el aprendizaje, corregir errores comunes y conectar con la metacognición.)*

**Puesta en Común:**
- Un voluntario o grupo explica en la pizarra cómo resolvió uno de los problemas de la actividad.
- El resto de la clase ofrece retroalimentación o pregunta dudas (técnica de "experto por un día").
- **Preguntas de Cierre:**
    1.  "¿Cuál fue el paso que te pareció más difícil? ¿Y el más fácil?"
    2.  "¿Alguien encontró una forma diferente de resolverlo?"
    3.  "¿En qué otra situación de la vida real podríamos usar esto?"
- **Conclusión Final:** "Hoy hemos visto que las matemáticas, y en especial el tema de '${tema}', son como una caja de herramientas para resolver misterios y problemas de nuestro día a día."

---

### **6. Extensión o Reto Avanzado (Opcional)**
*(Para estudiantes que terminan antes o muestran un dominio avanzado.)*

**Desafío:**
[Genera un problema de mayor complejidad, alineado con el tema pero que requiera un paso adicional o pensamiento más profundo.
- **Ejemplo para ecuaciones:** "Si 2(x + 3) - 4 = 14, ¿cuál es el valor de x?"
- **Ejemplo para geometría:** "Calcula el volumen de un cilindro si su radio es la solución de la ecuación '2r - 1 = 5' y su altura es de 10 cm."]
---

**Genera ahora la guía completa, detallada y didáctica, siguiendo esta estructura y adaptándola a los datos proporcionados.**
`;
};