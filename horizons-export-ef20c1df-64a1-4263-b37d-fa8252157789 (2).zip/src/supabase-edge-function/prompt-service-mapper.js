import { getClassPreparerPrompt } from './prompts/class-preparer.js';
import { getUnitTopicsPrompt } from './prompts/unit-topics.js';
import { getCreateStartupPrompt } from './prompts/create-startup.js';
import { getAtencionDiversidadPrompt } from './prompts/atencion-diversidad.js';
import { getChildrenCreativityPrompt } from './prompts/children-creativity.js';
import { getPoemSongPrompt } from './prompts/poem-song.js';
import { getPodcastPrompt } from './prompts/podcast.js';
import { getTutorialPrompt } from './prompts/tutorial.js';
import { getGamificacionPrompt } from './prompts/gamificacion.js';
import { getInteligenciaArtificialPrompt } from './prompts/inteligencia-artificial.js';
import { getEvaluacionFormativaPrompt } from './prompts/evaluacion-formativa.js';
import { getNeuroeducacionPrompt } from './prompts/neuroeducation.js';
import { getCriticalThinkingPrompt } from './prompts/critical-thinking.js';
import { getMultipleIntelligencesPrompt } from './prompts/multiple-intelligences.js';
import { getTextAnalysisPrompt } from './prompts/text-analysis.js';
import { getCognitiveAnalysisPrompt } from './prompts/cognitive-analysis.js';
import { getMathAnalysisPrompt } from './prompts/math-analysis.js';
import { getExamGeneratorIAPrompt } from './prompts/exam-generator-ia.js';
import { getPqrsGeneratorPrompt } from './prompts/pqrs-generator.js';
import { getEducationalProjectPrompt } from './prompts/educational-project.js';
import { getGenerateArticlePrompt, getPedagogicalWorkshopPrompt } from './prompts/generic.js';


export const getPromptForService = (serviceType, formData) => {
  const serviceMap = {
    'class-preparer': getClassPreparerPrompt,
    'unit-topics': getUnitTopicsPrompt,
    'create-startup': getCreateStartupPrompt,
    'atencion-diversidad': getAtencionDiversidadPrompt,
    'children-creativity': getChildrenCreativityPrompt,
    'poems-songs': getPoemSongPrompt,
    'podcast-generator': getPodcastPrompt,
    'tutorial-generator': getTutorialPrompt,
    'gamificacion': getGamificacionPrompt,
    'inteligencia-artificial': getInteligenciaArtificialPrompt,
    'evaluacion-formativa': getEvaluacionFormativaPrompt,
    'neuroeducation': getNeuroeducacionPrompt,
    'critical-thinking': getCriticalThinkingPrompt,
    'multiple-intelligences': getMultipleIntelligencesPrompt,
    'text-analysis': getTextAnalysisPrompt,
    'cognitive-analysis': getCognitiveAnalysisPrompt,
    'math-analysis': getMathAnalysisPrompt,
    'exam-generator-ia': getExamGeneratorIAPrompt,
    'pqrs-generator': getPqrsGeneratorPrompt,
    'educational-projects': getEducationalProjectPrompt,
    'generate-article': getGenerateArticlePrompt,
    'pedagogical-workshops': getPedagogicalWorkshopPrompt
  };

  const promptFunction = serviceMap[serviceType];

  if (promptFunction) {
    const { system_prompt, user_prompt } = promptFunction(formData);
    let model, temperature, max_tokens;

    if (serviceType === 'exam-generator-ia') {
        model = 'gpt-4o';
        temperature = 0.5;
        max_tokens = 4096;
    } else {
        model = 'gpt-4-turbo';
        temperature = 0.7;
        max_tokens = 4096;
    }
    
    return { system_prompt, user_prompt, model, temperature, max_tokens };
  }

  const default_system_prompt = `Eres un asistente de IA servicial.`;
  const default_user_prompt = `Por favor, responde a la siguiente consulta basada en estos datos: ${JSON.stringify(formData)}`;
  return { system_prompt: default_system_prompt, user_prompt: default_user_prompt, model: 'gpt-4-turbo', temperature: 0.7, max_tokens: 2048 };
};