import { corsHeaders } from "./cors.ts";
import { OpenAI } from "https://deno.land/x/openai/mod.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const openai = new OpenAI(Deno.env.get("OPENAI_API_KEY"));
const supabaseAdmin = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

// Fuentes confiables
const trustedSources = [
  { name: "Ministerio de Educación Colombia", url: "https://www.colombiaaprende.edu.co/contenidos-para-aprender" },
  { name: "Khan Academy en Español", url: "https://es.khanacademy.org/" },
  { name: "YouTube Educación", url: "https://www.youtube.com/channel/UC3yA8nD5uYriD3gQfgRwNEA" },
  { name: "Biblioteca Digital Mundial", url: "https://www.wdl.org/es/" },
];

async function searchInDatabase(query, filters) {
  let dbQuery = supabaseAdmin.from('recursos_en_linea').select('*');

  // Aplicar filtros
  if (filters.level) dbQuery = dbQuery.eq('nivel_educativo', filters.level);
  if (filters.subject) dbQuery = dbQuery.eq('asignatura', filters.subject);
  if (filters.type) dbQuery = dbQuery.eq('tipo_recurso', filters.type);
  if (filters.format) dbQuery = dbQuery.eq('formato', filters.format);
  if (filters.language) dbQuery = dbQuery.eq('idioma', filters.language);
  
  // Búsqueda por palabra clave en título, descripción y palabras clave
  dbQuery = dbQuery.textSearch('titulo', `'${query}'`, { type: 'websearch' });
  
  const { data, error } = await dbQuery.limit(10);
  
  if (error) {
    console.error("Error en búsqueda en DB:", error);
    return [];
  }
  return data;
}

async function generateSearchResultsWithAI(query, filters) {
  // Este es un mock. En un escenario real, aquí iría la lógica de web scraping.
  // Por ahora, generaremos resultados simulados basados en las fuentes confiables.
  
  const prompt = `
    Actúa como un bibliotecario experto y motor de búsqueda educativo.
    El usuario está buscando: "${query}".
    Filtros aplicados: ${JSON.stringify(filters)}.

    Genera una lista de 5 recursos educativos ficticios pero realistas y de alta calidad que coincidan con la búsqueda.
    Los recursos deben provenir de estas fuentes: ${trustedSources.map(s => s.name).join(', ')}.
    Para cada recurso, proporciona: titulo, descripcion (breve, 1-2 frases), fuente, tipo_recurso, formato, y un enlace (URL) de ejemplo basado en la fuente.
    
    Formatea la respuesta como un array de objetos JSON. Ejemplo de formato:
    [
      {
        "titulo": "Guía interactiva del Sistema Solar",
        "descripcion": "Una guía completa con videos y actividades para entender los planetas y el sistema solar.",
        "url": "https://es.khanacademy.org/science/sistemasolar-guia",
        "tipo_recurso": "Guía Pedagógica",
        "formato": "Interactivo",
        "fuente": "Khan Academy en Español"
      }
    ]
  `;
  
  const completion = await openai.chat.completions.create({
    model: "gpt-4-turbo",
    messages: [{ role: "user", content: prompt }],
    response_format: { type: "json_object" },
    temperature: 0.5,
  });

  try {
    const resultText = completion.choices[0].message.content;
    const jsonResult = JSON.parse(resultText);
    // El prompt pide un array, pero el modelo puede envolverlo en un objeto.
    return Array.isArray(jsonResult) ? jsonResult : jsonResult.resources || [];
  } catch (e) {
    console.error("Error al parsear la respuesta de OpenAI:", e);
    return [];
  }
}

async function saveNewResources(resources, userId) {
    const resourcesToInsert = resources.map(res => ({
        titulo: res.titulo,
        descripcion: res.descripcion,
        url: res.url,
        tipo_recurso: res.tipo_recurso,
        formato: res.formato,
        fuente: res.fuente,
        nivel_educativo: res.nivel_educativo, // Puede ser null si la IA no lo infiere
        asignatura: res.asignatura, // Puede ser null
        idioma: res.idioma, // Puede ser null
        palabras_clave: res.palabras_clave, // Puede ser null
        creado_por: userId,
    }));

    const { data, error } = await supabaseAdmin
        .from('recursos_en_linea')
        .insert(resourcesToInsert)
        .select();

    if (error) {
        console.error("Error guardando nuevos recursos:", error);
        return []; // Devolver array vacío si falla la inserción
    }
    return data;
}

Deno.serve(async (req) => {
  // Manejo de la solicitud pre-vuelo (preflight) CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { query, filters } = await req.json();
    const authHeader = req.headers.get('Authorization');
    
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Falta la cabecera de autenticación' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' }});
    }

    const jwt = authHeader.replace('Bearer ', '');
    const { data: { user } } = await supabaseAdmin.auth.getUser(jwt);

    if (!user) {
      return new Response(JSON.stringify({ error: 'Usuario no autenticado' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' }});
    }

    // 1. Buscar en la base de datos
    let dbResults = await searchInDatabase(query, filters);

    // 2. Si no hay suficientes resultados, buscar con IA (simulación de web scraping)
    if (dbResults.length < 5) {
      const aiResultsRaw = await generateSearchResultsWithAI(query, filters);
      
      // 3. Guardar los nuevos resultados en la base de datos
      if(aiResultsRaw.length > 0) {
        const newResources = await saveNewResources(aiResultsRaw, user.id);
        dbResults = [...dbResults, ...newResources];
      }
    }
    
    // Eliminar duplicados por URL
    const uniqueResults = Array.from(new Map(dbResults.map(item => [item['url'], item])).values());

    return new Response(JSON.stringify({ resources: uniqueResults }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error en la función Edge:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});