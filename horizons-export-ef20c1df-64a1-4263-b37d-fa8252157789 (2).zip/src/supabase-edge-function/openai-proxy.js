import { corsHeaders } from "./cors.ts";
import { OpenAI } from "https://deno.land/x/openai@v4.52.7/mod.ts";
import { getPromptForService } from "./prompt-service-mapper.js";

const openai = new OpenAI({
  apiKey: Deno.env.get("OPENAI_API_KEY"),
});

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { serviceType, formData } = await req.json();

    if (!serviceType || !formData) {
      return new Response(JSON.stringify({ error: "serviceType and formData are required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { system_prompt, user_prompt, model, temperature, max_tokens } = getPromptForService(serviceType, formData);

    if (!system_prompt || !user_prompt) {
      return new Response(JSON.stringify({ error: `No prompt configured for serviceType: ${serviceType}` }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const completion = await openai.chat.completions.create({
        model: model || "gpt-4-turbo",
        messages: [
          { role: "system", content: system_prompt },
          { role: "user", content: user_prompt }
        ],
        temperature: temperature || 0.7,
        max_tokens: max_tokens || 4096,
    });

    const responseContent = completion.choices[0].message.content;
    
    let responsePayload = {
        content: responseContent,
        dbRecord: null
    };

    if (serviceType === 'exam-generator-ia') {
        responsePayload.dbRecord = {
            nombre: formData.nombre_examen,
            asignatura: formData.asignatura,
            nivel_grado: formData.grado,
            examen_generado: { content: responseContent },
            creado_por: formData.userId,
        };
    }

    return new Response(JSON.stringify(responsePayload), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("Error in OpenAI proxy:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});